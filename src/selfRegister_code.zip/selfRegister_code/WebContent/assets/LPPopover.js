/*!
 * Built by LeasePlan AU
 * version: v1.0.0
 * Author: Wei Tao
 * Date: Aug 2017
 */

sap.ui.define([], function () {
    "use strict";

    var LPPopover = function () {
    	
    };
    
    /**
     * Returns object of fragment of popover and initialise Message
     * @returns {object}
     */
    LPPopover.prototype.loadPopover = function () {
    	(!this._oPopover) && (function(){
    		this._oPopover = new sap.ui.xmlfragment("com.lp.selfRegister.fragments.Popover", this);
    		this._PopoverMessage= sap.ui.getCore().byId('lpCustomerHelp');
			}).call(this);
    	return this._oPopover;
    };
   
    
    LPPopover.prototype.setMessage  = function(message){
    	this._PopoverMessage.setText(message);
    };
    
    
    LPPopover.prototype.getPopover = function() {
    	
    	return this._oPopover;
    };
    
    LPPopover.prototype.destroyPopover = function() {
    	if (this._oPopover) {
			this._oPopover.destroy();
			this._oPopover = null;
		}
    }
  
    
    return LPPopover;
});