/*!
 * Built by LeasePlan AU
 * version: v1.0.0
 * Author: Wei Tao
 * Date: Aug 2017
 */

jQuery.sap.declare("assets.LPReCapcha");
function reCapchaCallback() {
   // invoke server side validation 
    callPortalService("",validateRecaptchaCallback,this);
   // validateRecaptchaCallback();
};


function callPortalService (oUserData,oCallback,oCallbackObject) {
	var sURL = "/portalService/validateRecaptcha",
		oAjax = {
			method      : "POST",
			contentType : "application/json",
			dataType    : "json",
			data:    JSON.stringify(oUserData)  
		};

		$.ajax(sURL, oAjax).done(function(responseData) {
			oCallback.call (oCallbackObject,responseData,"success");
		}).fail(function(XMLHttpRequest, textStatus) {
			oCallback.call (oCallbackObject , {message : textStatus, statusCode : XMLHttpRequest.status, statusText : XMLHttpRequest.statusText, responseText : XMLHttpRequest.responseText},"failed");
		});
};

function validateRecaptchaCallback(data,stage) {
   //  if (stage ==="validateRecaptcha")
	sap.ui.controller("com.lp.selfRegister.controller.initialReg.InitialRegister").validateRecaptchaCallback(sap.ui.getCore().AppContext.context);
};
