/*!
 * Built by LeasePlan AU
 * version: v1.0.0
 * Author: Wei Tao
 * Date: Aug 2017
 */

sap.ui.define([ 
	'sap/ui/model/json/JSONModel',
	], function (JSONModel) {

	"use strict";

    /**
     * initialize  when instance has been constructed
     */
	var PortalService = function () {
	
	};
    
	/**
	 * configuration of portal service in terms of status as response from service 
	 * @private
	 * @returns {object}
	 */

	PortalService.prototype._getServiceInfo = { 
   		serviceURL :function(){
						var sURL = "";
						this._host ="";
						this._host ="http://lpausap1003.ap.leaseplancorp.net:58000";
						switch(this.service) {
							case "initialiseUser" :  // call initialise User Service  from registration initial module
								sURL = this._host + "/portalService/initialiseUser";
								break;
							case "verifyInitialUser":  // call verifyInitialUser Service from registration verify module
								sURL = this._host + "/portalService/verifyInitialUser";
								break;
							case "getCustomerNum" :  // call checkEmail Service  from registration complete module
								sURL = this._host + "/portalService/checkEmail";
								break;
							case "verifyCustNum" :// call customerNumber validation from  complete register module 
								sURL = this._host + "/portalService/checkCustomerNumber";
								break; 		
							case "validateWorkEmail" :  // call validate work email Service  from registration complete module
								sURL = this._host + "/portalService/validateWorkEmail";
								break;
							case "createDriver" :  // call registerCustomer Service  from registration complete module
								sURL = this._host + "/portalService/registerCustomer";
								break;
							case "registerSession" :  // call registerSession Service  from self verify stage
								sURL = this._host + "/portalService/registerSession";
								break;
							case "checkEncryptToken" :  // call checkEncryptToken Service  from initial of complete stage
								sURL = this._host + "/portalService/checkEncryptToken";
								break;
							case "verifyAddress" :  // call verifyAddress Service  from initial of complete stage
								sURL = this._host + "/portalService/verifyAddress";
								break;	
							case "verifyToken" : // call verifyToken service
								sURL = this._host + "/portalService/verifyToken";
								break;
							case "updatePassword" : //  call updatePassword service 
								sURL = this._host + "/portalService/updatePassword";
								break;
							case "verifyEmail" :  // call verifyEmail service  from verfy user module
								sURL = this._host + "/portalService/verifyEmailActivation";
								break;
				}
						return sURL;
					},

		 serviceStatus: function(){
						var sStatus = "";
						switch(this.service) {
							case "initialiseUser" :   //  call initialise User Service  at self registration inital stage
								sStatus = "initialiseUser";
								break;
							case "verifyInitialUser": // call verifyInitialUser service  at verify code stage
								sStatus = "verifyInitialUser";
								break;
							case "getCustomerNum" :   //  call checkEmail  Service  at self registration complete stage
								sStatus = "getCustomerNum";
								break;
							case "verifyCustNum" :  // call customerNumber validation 
								sStatus = "verifyCustNum";
								break;
							case "validateWorkEmail" :   // call validate work email Service  from registration complete module
								sStatus = "validateWorkEmail";
								break;
							case "createDriver" :   //  call registerCustomer User Service  at self registration complete stage
								sStatus = "createDriver";
								break;
						    case "registerSession" :   //  call registerSession User Service at self verify stage
								sStatus = "registerSession";
								break;
							case "checkEncryptToken" :   // call checkEncryptToken Service  from initial of complete stage
								sStatus = "checkEncryptToken";
								break;
							case "verifyAddress" :   // call verifyAddress Service  from  complete stage
								sStatus = "verifyAddress";
								break;	
							case "verifyToken" : // call verifyToken service
								sStatus = "loading";
								break;
							case "updatePassword" : //  call updatePassword service 
								sStatus = "updatePassword";
								break;
							case "verifyEmail" :  // call verifyEmail service
								sStatus = "verifyEmail";
								break;
						}
						return sStatus;
						},
		 service: ""				
   	};

    /**
     * configuration of portal service message in terms of status as response from the service 
     * @returns {object}
     */
 	PortalService.prototype.getMessage = {
    	getEmailMessage:function(){
  		var sReslut = "";
			switch(this.status) {
			case "ACTIVED" : // check if email has been activated
				sReslut = "Passoword reseting link has been sent out ,please check your email.";
				break;
			case "NONVERIFIED" : //  check if email has not been verified 
				sReslut = "your email has not been verified yet when you registered , verification link has been sent out.";
				break;
			case "NONREGISTER" :  // check if email is still not registered 
				sReslut = "your email has not been registerd yet, please try the correct one or register with it alternatively";
				break;
			case "SERVICEBLOCK" :  // Call service failed
				sReslut = "There is either network or remote servcie down issue, please try it again later or contact with Leaseplan.";
				break;
			case "DEFAULT" :  // Call service Responsed  will update later on 
				sReslut = "DEFALUT";
				break;	
			}
			return sReslut;
		 },
		 
	   getPasswordMessage:function(){
		  		var sReslut = "";
					switch(this.status) {
					case "TOKENINVALIDATE" : // token invalidate 
						sReslut = {message: "Due to token expried or invalid , your password can't be updated please contract leaseplan adminstrator.",icon:"images/reject.png"};
						break;
					case "SERVICEBLOCK" : // Call service failed
						sReslut = {message: "There is either network or remote servcie down issue, please try it again later or contact with Leaseplan.",icon:"images/reject.png"};
						break;
					case "UPDATESUCCESS" :  // pass word updated successfully
						sReslut = {message: "Your password has been updated successfully. You will be redirected to Leaseplan Online now.",icon:"images/checkMark.png"};
						break;
					case "UPDATEFAILED" :  // pass word updated failed (web service call successfully)
						sReslut = {message: "Due to token expried or invalid , your password can't be updated please contract leaseplan adminstrator.",icon:"images/reject.png"};
						break;
					}
					return sReslut;
				 },
		 
        status:""
	};
  
	
 	/**
	 * Returns  JSON response data from portal service 
	 * @param  sService,oUserData,oCallback,oCallbackObject 
	 * @returns success callback with loading data / error if failed will call back with loading failed  
	*/
	PortalService.prototype.callPortalService = function(sService,oUserData,oCallback,oCallbackObject) {
		this._getServiceInfo.service = sService;
		var sURL = this._getServiceInfo.serviceURL(),
			sServieStatus = this._getServiceInfo.serviceStatus(),
			oAjax = {
				method      : "POST",
				contentType : "application/json",
				dataType    : "json",
				data:    JSON.stringify(oUserData)  
			};

			$.ajax(sURL, oAjax).done(function(responseData) {
				oCallback.call (oCallbackObject,responseData,sServieStatus);
			}).fail(function(XMLHttpRequest, textStatus) {
				oCallback.call (oCallbackObject , {message : textStatus, statusCode : XMLHttpRequest.status, statusText : XMLHttpRequest.statusText, responseText : XMLHttpRequest.responseText},"failed");
			});

	};

	return PortalService;

});