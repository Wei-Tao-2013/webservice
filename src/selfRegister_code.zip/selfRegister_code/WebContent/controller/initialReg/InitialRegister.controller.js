/*!
 * Built by LeasePlan AU
 * version: v1.0.0
 * Author: Wei Tao
 * Date: Aug 2017
 */
sap.ui.define(["sap/ui/core/mvc/Controller",
	"sap/m/MessageToast",
	"sap/ui/model/SimpleType",
	"sap/ui/model/ValidateException",
	"com/lp/selfRegister/model/SelfRegisterModels",
	"com/lp/selfRegister/assets/Validator",
	"com/lp/selfRegister/assets/PortalService",
	"com/lp/selfRegister/assets/LPMessage"
	
], function(Controller, MessageToast, SimpleType, ValidateException, SelfRegisterModels,Validator,Webservice,LPMessage) {
	"use strict";
	return Controller.extend("com.lp.selfRegister.controller.initialReg.InitialRegister", {
		INPUT_VALUE_STATE_ERROR: "Error",
		INPUT_VALUE_STATE_NONE: "None",
		PATTERN_ALPHABET: /^[a-zA-Z]+$/,
		PATTERN_EMAIL: /^\w+[\w-+\.]*\@\w+([-\.]\w+)*\.[a-zA-Z]{2,}$/,
		cSelfRegForm: "selfRegisterFormElements",
	
		onInit: function() {
			var oComponent = this.getOwnerComponent();
			this._router = oComponent.getRouter();
			this._router.getRoute("InitialRegister").attachPatternMatched(this._routePatternMatched, this);
			this._selfRegisterModels = new SelfRegisterModels();
			this._oModel = this._selfRegisterModels.createInitSelfRegModel();
    		// binding elements value in xml template to completeRegModel of as one of model in selfRegisterModels
    		this.getView().setModel(this._oModel, "registerModel").bindElement("/").setBindingContext(new sap.ui.model.Context(this._oModel, "/"));

    		// attach handlers for validation errors
			sap.ui.getCore().attachValidationError(function(evt) {
				var control = evt.getParameter("element");
				if (control && control.setValueState) {
					control.setValueState("Error");
				}
			});
		
			sap.ui.getCore().attachValidationSuccess(function(evt) {
				var control = evt.getParameter("element");
				if (control && control.setValueState) {
					control.setValueState("None");
				}
			});
			this._getLPMessage().quickhelp(this.getView().byId('lpEmailAddress'),"This will be your user name.");
			ga('send', 'pageview','initialPage');
			
			$(".lp_googleRecaptcha").show();
			$(".grecaptcha-badge").css("bottom","70px"); 
			
			/*  var onloadCallback = function() {
		          grecaptcha.render('submit', {
		            'sitekey' : 'your_site_key',
		            'callback' : onSubmit
		          });
		        };
		        
		        */
		        
			sap.ui.getCore().AppContext.context = this;
		},
		
		_routePatternMatched: function (oEvent) {
			var queryArray = oEvent.mParameters.arguments['?query'];
			this._customerNumber = queryArray ===undefined ? "":queryArray.registration_number;
		},
		
		
	
		_onOpenDialog: function (oEvent) {
			// instantiate dialog
			if (!this._dialog) {
				this._dialog = sap.ui.xmlfragment("com.lp.selfRegister.fragments.BusyDialog", this);
			/*	this._dialog.setTitle("Creating your login");
				this._dialog.setText("Loading...");*/
				this.getView().addDependent(this._dialog);
			}
			// open dialog
			jQuery.sap.syncStyleClass("sapUiSizeCompact", this.getView(), this._dialog);
			this._dialog.open();
 		},
 		
 	
 		
		onDialogClosed: function (oEvent) {
		 	jQuery.sap.clearDelayedCall(this._timeout);
 		},
		
		submitDetails: function(oEvent) {
	
			if (this._getValidator().validate(this.getView().byId(this.cSelfRegForm))) {
				 grecaptcha.execute();
			/*	var userData = {},
				viewData = this.getView().oModels.registerModel.oData;
				userData.fName = viewData.firstName;
				userData.lName = viewData.lastName;
				userData.customerNumber = this._customerNumber;
				userData.email =  viewData.email;
				userData.password =  viewData.password;
				var userCred = {
								"firstName" : userData.fName ,
								"lastName" : userData.lName,
								"emailAddress" : userData.email,
								"password": userData.password,
								"customerNumber": userData.customerNumber
						}
				
				this._onOpenDialog();
				this._timeout = jQuery.sap.delayedCall(500, this, function () {
					this._getWebService().callPortalService("initialiseUser",userCred,this.sendUserData,this);
				});
	*/
			}
		},

		validateRecaptchaCallback: function(obj){
			var that = obj;	
			var userData = {},
			viewData = that.getView().oModels.registerModel.oData;
			userData.fName = viewData.firstName;
			userData.lName = viewData.lastName;
			userData.customerNumber = that._customerNumber;
			userData.email =  viewData.email;
			userData.password =  viewData.password;
			var userCred = {
							"firstName" : userData.fName ,
							"lastName" : userData.lName,
							"emailAddress" : userData.email,
							"password": userData.password,
							"customerNumber": userData.customerNumber
					}
			
			that._onOpenDialog();
			that._timeout = jQuery.sap.delayedCall(500, that, function () {
				that._getWebService().callPortalService("initialiseUser",userCred,that.sendUserData,that);
			});
		},
		
		
		navPortal: function(){
			window.location.replace("/irj/portal");	
		},
	
		typeEmail: SimpleType.extend("email", {
			formatValue: function(oValue) {
				return oValue;
			},
			parseValue: function(oValue) {
				//parsing step takes place before validating step, value can be altered
				return oValue;
			},
			validateValue: function(oValue) {
				var mailregex = /^\w+[\w-+\.]*\@\w+([-\.]\w+)*\.[a-zA-Z]{2,}$/;
				if (!oValue.match(mailregex)) {
					throw new ValidateException("'" + oValue + "' is not a valid email address");
				}
				if (oValue.length >50 ){
					throw new ValidateException("'" + oValue + "' exceeds maximum length allowed");
				}
			}
		}),

		typeName: SimpleType.extend("name", {
			formatValue: function(oValue) {
				return oValue;
			},
			parseValue: function(oValue) {
				return oValue;
			},
			validateValue: function(oValue) {
				var regex = /^[a-zA-Z]+$/;
				if (!oValue.match(regex)) {
					throw new ValidateException("'" + oValue + "' is not a valid name");
				}
				
			}
		}),

		typePassword: SimpleType.extend("password", {
			formatValue: function(oValue) {
				return oValue;
			},
			parseValue: function(oValue) {
				return oValue;
			},
			validateValue: (function(oValue) {
				var sPatternImpermissiblePassword = "^(?!(?=.*[@](?=.*[\.])))",
					sPatternMixedCaseAplaNumeric = "(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])",
					sPatternSpecialCahrecters = "(?=.*[!@#\$%\^&\*]{0,})",
					sPatternLength = "(?=.{8,14}$)";
				this.password = oValue;
				var passwordRegex = new RegExp(sPatternImpermissiblePassword + sPatternMixedCaseAplaNumeric + sPatternSpecialCahrecters +
					sPatternLength);

				if (!oValue.match(passwordRegex)) {
					throw new ValidateException("Password must contain 8-14 mixed case alphabets and numbers");
				}
			}).bind(this)
		}),
		
		/**
		* define password confirm validation
		*/
		passwordConfirmed: SimpleType.extend("Password",{
			formatValue: function(oValue) {
				return oValue;
			},
			parseValue: function(oValue) {
				return oValue;
			},
			validateValue: (function(oValue) {
			    var password = this.password;
				if (oValue !== password) {
					throw new ValidateException("Re entered Password does not match");
				}
				
			}).bind(this)
		}),

		
		sendUserData: function(data,stage) {
			// busy indicator close
	    	this._dialog && this._dialog.close();
	    	$(".lpCompleteRegister").hide();	
	    	$(".lp_googleRecaptcha").hide();
	 		if (stage==="initialiseUser") {
				if (data.returnUME ==="created"){
					this._getLPMessage().loadSystemMessage().open();
					this._getLPMessage().setMessageType(true);
					this._getLPMessage().setMessage("Almost there! We have sent you an email to verify your account. Please click on the link in the email to complete your registration.");
					ga('send', 'pageview','initialUserCreated');
				}else if (data.returnUME ==="registered"){
					this._getLPMessage().loadSystemMessage().open();
					this._getLPMessage().setMessageType(false);
					this._getLPMessage().setMessage("Whoops! Looks like you might already be in our system, please contact LeasePlan on 132 572 to confirm your registration.");
				}else if (data.returnUME ==="false"){
					// all other scenarios failed to initialise new user on portal or failed process in CRM 
					this._getLPMessage().loadSystemMessage().open();
					this._getLPMessage().setMessageType(false);
					this._getLPMessage().setMessage("Whoops! Something went wrong. Please try again or contact LeasePlan on 132 572 if the issue continues.");
				}
			
			}else {
				 ///system error as web service down
				 this._getLPMessage().loadSystemMessage().open();
				 this._getLPMessage().setMessageType(false);
		    	 this._getLPMessage().setMessage(this._getLPMessage().callLeasePlan());
		    	 console.log("There are technical issues occured with message are " +  JSON.stringify(data));
			}
		},

		/**
		* Construct portal service instance 
		* @private
		* @return {object} 
		*/
        _getWebService : function() {
            if  (!this._webservice){
            	 this._webservice = new Webservice();
            }
            return this._webservice;
        },
        
    	/**
		* Construct form Validator instance 
		* @private
		* @return {object} 
		*/
        _getValidator : function() {
            if  (!this._validator){
            	   this._validator  = new Validator();
            }
            return this._validator;
        },
        
        /**
		* Construct form LPMessage instance 
		* @private
		* @return {object} 
		*/

        _getLPMessage : function() {
            if  (!this._LPMessage){
            	   this._LPMessage  = new LPMessage();
            }
            return this._LPMessage;
        },
       
		_getSelfRegForm: function() {
			return sap.ui.getCore().byId(this.cSelfRegForm);
		},

	});
});