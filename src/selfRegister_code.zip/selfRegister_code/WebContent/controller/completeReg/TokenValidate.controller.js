/*!
 * Built by LeasePlan AU
 * version: v1.0.0
 * Author: Wei Tao
 * Date: Aug 2017
 */
sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"com/lp/selfRegister/assets/PortalService",
	"com/lp/selfRegister/assets/Validator",
	"com/lp/selfRegister/assets/LPMessage",
	"com/lp/selfRegister/model/SelfRegisterModels"

], function(Controller,Webservice,Validator,LPMessage,SelfRegisterModels) {
	"use strict";
	return Controller.extend("com.lp.selfRegister.controller.completeReg.TokenValidate", {
		
		onInit: function() {
			var oComponent = this.getOwnerComponent();
    		this._router = oComponent.getRouter();
    		this._router.getRoute("TokenValidate").attachPatternMatched(this._routePatternMatched, this);
    		this._selfRegisterModels = new SelfRegisterModels();
    		this._oModel = this._selfRegisterModels.createCompleteRegModel();
    		// binding elements value in xml template to completeRegModel of as one of model in selfRegisterModels
    		this.getView().setModel(this._oModel, "completeRegModel").bindElement("/").setBindingContext(new sap.ui.model.Context(this._oModel, "/"));
    		
    		sap.ui.getCore().attachValidationError(function(evt) {
				var control = evt.getParameter("element");
				if (control && control.setValueState) {
					control.setValueState("Error");
				}
			});
    		
			sap.ui.getCore().attachValidationSuccess(function(evt) {
				var control = evt.getParameter("element");
				if (control && control.setValueState) {
					control.setValueState("None");
				}
			});
		},

		_routePatternMatched: function (oEvent) {
			this._lastName =   oEvent.mParameters.arguments['?query'].l;
			this._firstName = oEvent.mParameters.arguments['?query'].f;
	    	this._emailAddress=  oEvent.mParameters.arguments['?query'].e;
	    	this._verifyCodeFlag = oEvent.mParameters.arguments['?query'].c;
	    	this._customerNumber = oEvent.mParameters.arguments['?query'].CustN;
	    	this._oModel.oData.firstName = this._firstName;
			this._oModel.oData.lastName = this._lastName;
			this._oModel.oData.emailAddress = this._emailAddress;
			this._oModel.oData.verifyCodeFlag = this._verifyCodeFlag;
			this._oModel.oData.customerNumber = this._customerNumber;
			this._sessionCheck();
		},
	    
		_sessionCheck: function(){
			var JSONObject = {
					"emailAddress": this._emailAddress
		    };
	       this._getWebService().callPortalService("checkEncryptToken",JSONObject,this._initialpage,this);
		},
	
		_initialpage : function(data,stage){
		  if (stage==="checkEncryptToken"){
        	if (data.returnUME==="true"){
				if (data.groupType ==="pendingGroup"){
					this._getLPMessage().loadSystemMessage().open();
					this._getLPMessage().setMessageType(false);
					this._getLPMessage().setMessage("Your registeration application is still in process of approval. please wait untill you receive the confirmation via email alternatively please contact LeasePlan for further enquiries.");
					return false;
				}else if (data.groupType === "approvalGroup"){
					this._getLPMessage().loadSystemMessage().open();
						this._getLPMessage().setMessageType(false);
					this._getLPMessage().setMessage("Your registeration application has been completed, please logon on portal.");
					return false;
				}else {
						if (this._verifyCodeFlag === "true"){
							sap.ui.getCore().setModel(this._oModel, "completeRegModel"); // application level  model setting;
							this._router.getTargets().display("WorkEmail");	
						}else {
						sap.ui.getCore().setModel(this._oModel, "completeRegModel"); // application level  model setting;
						this._router.getTargets().display("EnterCustNum");	
						}
				}
			} else {
				this._getLPMessage().loadSystemMessage().open();
				this._getLPMessage().setMessageType(false);
				this._getLPMessage().setMessage("Your session has expired, please sign in again.");
				/// set cookie to store customer number and status of process
				return false;
				}	
			} else{
                 ///system error as web service down
				(function(){
 					this._getLPMessage().loadSystemMessage().open();
 					this._getLPMessage().setMessageType(false);
 					this._getLPMessage().setMessage(this._getLPMessage().callLeasePlan());
		    	}).call(this);
			}
		},
		
		/**
		* Construct portal service instance 
		* @private
		* @return {object} 
		*/
        _getWebService : function() {
            if  (!this._webservice){
            	 this._webservice = new Webservice();
            }
            return this._webservice;
        },
        
    	/**
		* Construct form Validator instance 
		* @private
		* @return {object} 
		*/
        _getValidator : function() {
            if  (!this._validator){
            	   this._validator  = new Validator();
            }
            return this._validator;
        },

		/**
		* Construct form LPMessage instance 
		* @private
		* @return {object} 
		*/
        _getLPMessage : function() {
            if  (!this._LPMessage){
            	   this._LPMessage  = new LPMessage();
            }
            return this._LPMessage;
        }
	});
});