/*!
 * Built by LeasePlan AU
 * version: v1.0.0
 * Author: Wei Tao
 * Date: Aug 2017
 */
sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/m/MessagePopover",
	"sap/m/MessagePopoverItem",
	'sap/ui/model/json/JSONModel',
	"com/lp/selfRegister/assets/PortalService",
	"sap/ui/model/ValidateException",
	"sap/ui/model/SimpleType",
	"com/lp/selfRegister/assets/Validator",
	"com/lp/selfRegister/model/SelfRegisterModels",
	"com/lp/selfRegister/assets/LPMessage",
	"com/lp/selfRegister/assets/LPPopover"

], function(Controller,MessagePopover,MessagePopoverItem , JSONModel, Webservice,ValidateException,SimpleType,Validator,SelfRegisterModels,LPMessage,LPPopover) {
	"use strict";
	return Controller.extend("com.lp.selfRegister.controller.completeReg.WorkEmail", {
		onInit: function() {
			var oComponent = this.getOwnerComponent();
    		this._router = oComponent.getRouter();
    		this._selfRegisterModels = new SelfRegisterModels();    		
    		// binding elements value in xml template to completeRegModel of as one of model in selfRegisterModels
    		this._oModel = this._selfRegisterModels.createCompleteRegModel();
    		this.getView().setModel(this._oModel, "completeRegModel").bindElement("/").setBindingContext(new sap.ui.model.Context(this._oModel, "/"));
		    // initialise oData 
   			this._oModel.oData =  sap.ui.getCore().getModel("completeRegModel").oData;
			this._sendVerifyCode = this.byId("sendVerifyCode");
			this._verifyCode   = this.byId("verifyCode");
			this._workEmail = this.byId("workEmail");
			this._codeTxt = 	this.byId("codeTxt");
			this._customerMessage = this.byId("customerMessage");
			this._sendCodeBtn =  this.byId("sendCodeBtn");
			this._verifyCodeBtn = this.byId("verifyCodeBtn");
			this._titleMessage = this.byId("titleMessage");
	
			sap.ui.getCore().attachValidationError(function(evt) {
				var control = evt.getParameter("element");
				if (control && control.setValueState) {
					control.setValueState("Error");
				}
			});
			
			sap.ui.getCore().attachValidationSuccess(function(evt) {
				var control = evt.getParameter("element");
				if (control && control.setValueState) {
					control.setValueState("None");
				}
			});
			
			if (this._oModel.oData.verifyCodeFlag ==="true") {
				this._renderVerifyCodeInputPage();
			}else{
				this._process ="sendCode"; // identify if it is sending code via work email (sendCode) or veify code stage (verifyCode)
				this._titleMessage.setText("Information Required");
				this._customerMessage.setText('Your company requires the use of a work email address to register.');
			}
			
			ga('send', 'pageview','workEmailPage');
			
		},
		
		_onOpenDialog: function (oEvent) {
			// instantiate dialog
			if (!this._dialog) {
				this._dialog = sap.ui.xmlfragment("com.lp.selfRegister.fragments.BusyDialog", this);
				this.getView().addDependent(this._dialog);
			}
			// open dialog
			jQuery.sap.syncStyleClass("sapUiSizeCompact", this.getView(), this._dialog);
			this._dialog.open();
 		},
		
		onDialogClosed: function (oEvent) {
		 	jQuery.sap.clearDelayedCall(this._timeout);
 			
		},
		
		sendVerifyCode : function(){
			this._workEmail.setValueState("None");
		  	this._getValidator().validate(this._workEmail);
			if (this._workEmail.getValueState() === "Error" || this._workEmail.getValue() ==="") {
				this._workEmail.focus();
			} else {
				var workEmailData = {
					"workEmail" :  this._oModel.oData.workEmail,
					"emailAddress" : this._oModel.oData.emailAddress ,
					"resgistrationURL": window.location.href + "&c=true&CustN="+this._oModel.oData.customerNumber, 
					"firstName":this._oModel.oData.firstName ,
					"lastName" :this._oModel.oData.lastName , 
					"verIndicator" : "false",
					"customerNumber" :this._oModel.oData.customerNumber	
				   };
				
				///  busy indicator loading
				this._onOpenDialog();
				this._timeout = jQuery.sap.delayedCall(1000, this, function () {
					this._getWebService().callPortalService("validateWorkEmail",workEmailData,this._verifyCodeInputPage,this);
				});
				
			}
		},
			
		verifyCode : function() {
			  this._codeTxt.setValueState("None");
			  this._getValidator().validate(this._codeTxt);
				  if (this._codeTxt.getValueState() === "Error" || this._codeTxt.getValue() ==="") {
						this._codeTxt.focus();
						//this._codeTxt.fireSuggest();	
					} else {
						var workEmailData = {
							"workEmail" :  this._oModel.oData.workEmail,
							"emailAddress" : this._oModel.oData.emailAddress ,
							"refNumber" : this._oModel.oData.refNumber,
							"resgistrationURL": window.location.href, 
							"firstName":this._oModel.oData.firstName ,
							"lastName" :this._oModel.oData.lastName , 
							"verIndicator" : "true",
							"customerNumber" :this._oModel.oData.customerNumber	
						};
						///  busy indicator loading
						this._onOpenDialog();
						this._timeout = jQuery.sap.delayedCall(1000, this, function () {
							this._getWebService().callPortalService("validateWorkEmail",workEmailData,this._verifyCodeCheckPage,this);
						});
					}

		},

	    _verifyCodeInputPage : function (data,stage){
	    	// busy indicator close
	    	this._workEmail.setValueState("None");
	    	this._dialog && this._dialog.close();
	    	if (stage==="validateWorkEmail") {
				if(data.returnCRM === "true"){
					this._process ="verifyCode";
					this._titleMessage.setText("Verification Code");
					this._customerMessage.setText('A verification code has been sent to the email ' + this._oModel.oData.workEmail +'. Please enter the verification code below.');
					this._workEmail.setVisible(false)
					this._codeTxt.setVisible(true);
					this._sendCodeBtn.setVisible(false);
					this._verifyCodeBtn.setVisible(true);
					
				}else{
					//Do not navigate and display error message
					this._workEmail.focus();
					this._workEmail.setValueState('Error').setValueStateText(data.errReason);
				}
			}else{
				   ///system error as web service down
				 (function(){
					 this._getLPMessage().loadSystemMessage().open();
					 this._getLPMessage().setMessageType(false);
					 this._getLPMessage().setMessage(this._getLPMessage().callLeasePlan());
				 }).call(this);
			}
		},
       
		_renderVerifyCodeInputPage : function(){
			this._process ="verifyCode";
			this._customerMessage.setText('A verification code has been sent to the email ' + this._oModel.oData.workEmail +'. Please enter the verification code below.');
			this._workEmail.setVisible(false)
			this._codeTxt.setVisible(true)
			this._sendCodeBtn.setVisible(false);
			this._verifyCodeBtn.setVisible(true);
		},

		_verifyCodeCheckPage : function (data,stage){
			this._dialog && this._dialog.close();
		    if (stage==="validateWorkEmail") {
		    	 sap.ui.getCore().setModel(this._oModel, "completeRegModel"); // application level  model setting;
		    	 if(data.returnCRM === "true"){
					 if (data.errCode ==="004") { // duplicate user
		    			 this._oModel.oData.duplicate ="true";
						 this._oModel.oData.customerData = data.customerData;
					 }
					 this._oModel.oData.googleAPI = data.googleAPI;
					 this._oModel.oData.mandatory = data.mandatory;
		    		this._router.getTargets().display("CompleteRegister");	
		    		
				}else{
					 if (data.errCode ==="003") { // Internet user exist, Please call LP
						 (function(){
							 this._getLPMessage().loadSystemMessage().open();
							 this._getLPMessage().setMessageType(false)
							 this._getLPMessage().setMessage(data.errReason);
						 }).call(this);
					 }else{
						this._codeTxt.setValueState('Error').setValueStateText('The verification code entered is incorrect, please try again.');
						//this._codeTxt.fireSuggest();
					 }
				}
			}else{
				   ///system error as web service down
				 (function(){
					 this._getLPMessage().loadSystemMessage().open();
					 this._getLPMessage().setMessageType(false);
					 this._getLPMessage().setMessage(this._getLPMessage().callLeasePlan());
				 }).call(this);
			}
		},
	
		/**
		* Construct portal service instance 
		* @private
		* @return {object} 
		*/
        _getWebService : function() {
            if  (!this._webservice){
            	 this._webservice = new Webservice();
            }
            return this._webservice;
        },
       
        /**
		* Construct form Validator instance 
		* @private
		* @return {object} 
		*/
        _getValidator : function() {
            if  (!this._validator){
            	   this._validator  = new Validator();
            }
            return this._validator;

        },
        
        onExit: function() {
        	 this._getLPPopover().destroyPopover();
		},

		getInfo: function(evt) {
			 this._getLPPopover().loadPopover();
			 this._getLPPopover().setMessage("The verification code is that you received in your work email " + this._oModel.oData.workEmail );
			 var oInput = evt.getSource();
				jQuery.sap.delayedCall(0, this, function() {
					 this._getLPPopover().getPopover().openBy(oInput);
				});
		},
        
		
		getEmailInfo: function(evt) {
			 this._getLPPopover().loadPopover();
			 this._getLPPopover().setMessage("The email is that you received in your work email " + this._oModel.oData.workEmail );
			 var oInput = evt.getSource();
				jQuery.sap.delayedCall(0, this, function() {
					 this._getLPPopover().getPopover().openBy(oInput);
				});
		},
		
    	/**
		* Construct form LPMessage instance 
		* @private
		* @return {object} 
		*/
        _getLPMessage : function() {
            if  (!this._LPMessage){
            	   this._LPMessage  = new LPMessage();
            }
            return this._LPMessage;
        },
        
        handleWizardCancel: function() {
        	if (this._process ==="sendCode"){
        		this._router.getTargets().display("EnterCustNum");
			}else{
         		this._process ="sendCode";
				this._customerMessage.setText('We determined that your company only allows you to register with your work Email. Please enter your work email below.');
				//this._sendVerifyCode.setVisible(true);
				this._workEmail.setVisible(true)
				//this._verifyCode.setVisible(false);
				this._codeTxt.setVisible(false);
				this._sendCodeBtn.setVisible(true);
				this._verifyCodeBtn.setVisible(false);
			}
        },
        
        /**
		* Construct form LPPopover instance 
		* @private
		* @return {object} 
		*/
        _getLPPopover : function() {
            if  (!this._LPPopover){
            	   this._LPPopover  = new LPPopover();
            }
            return this._LPPopover;
        },
        
        /**
		* define email format and regex 
		*/
		typeEmail: SimpleType.extend("workEmail", {
			formatValue: function(oValue) {
				return oValue;
			},
			parseValue: function(oValue) {
				return oValue;
			},
			validateValue: function(oValue) {
				var mailregex = /^\w+[\w-+\.]*\@\w+([-\.]\w+)*\.[a-zA-Z]{2,}$/;
				if (!oValue.match(mailregex)) {
					throw new ValidateException("'" + oValue + "' is not a valid email address");
				}
			}
		}),

		/**
		* define typeInput format and regex 
		*/
		typeInput: SimpleType.extend("codeTxt", {
			formatValue: function(oValue) {
				return oValue;
			},
			parseValue: function(oValue) {
				return oValue;
			},
			validateValue: function(oValue) {
			   if (!oValue) {
					throw new ValidateException("Please enter your validation code ");
				}
			}
		})
	
	});

});