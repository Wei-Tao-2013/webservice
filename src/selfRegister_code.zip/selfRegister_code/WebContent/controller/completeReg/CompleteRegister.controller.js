/*!
 * Built by LeasePlan AU
 * version: v1.0.0
 * Author: Wei Tao
 * Date: Aug 2017
 */
sap.ui.define([
	'sap/ui/core/mvc/Controller',
	'sap/ui/model/json/JSONModel',
	"sap/m/MessageBox",
	"com/lp/selfRegister/assets/Validator",
	"com/lp/selfRegister/assets/PortalService",
	"sap/ui/model/ValidateException",
	"sap/ui/model/SimpleType",
	"com/lp/selfRegister/assets/LPMessage",
	"com/lp/selfRegister/assets/LPPopover"

], function(Controller, JSONModel, MessageBox,Validator,Webservice,ValidateException,SimpleType,LPMessage,LPPopover) {
	//"use strict";

	return Controller.extend("com.lp.selfRegister.controller.completeReg.CompleteRegister", {

		onInit: function () {
			var oComponent = this.getOwnerComponent();
    		this._router = oComponent.getRouter();
			sap.ui.getCore().attachValidationError(function(evt) {
				var control = evt.getParameter("element");
				if (control && control.setValueState) {
					control.setValueState("Error");
				}
			});
			sap.ui.getCore().attachValidationSuccess(function(evt) {
				var control = evt.getParameter("element");
				if (control && control.setValueState) {
					control.setValueState("None");
				}
			});
			this._wizard = this.getView().byId("CompleteSelfRegistrationWizard");
			this._oNavContainer = this.getView().byId("wizardNavContainer");
			this._oWizardContentPage = this.getView().byId("wizardContentPage");
			this._oWizardReviewPage = sap.ui.xmlfragment("com.lp.selfRegister.fragments.completeReg.ReviewPage", this);
			this._oWizardConfirmPage = sap.ui.xmlfragment("com.lp.selfRegister.fragments.completeReg.CompleteConfirm", this);
		 	this._oNavContainer.addPage(this._oWizardReviewPage);
	    	this._oNavContainer.addPage(this._oWizardConfirmPage);
	    	this._titleArr = [
				               {name : "Mr", value: "0002"},
				               {name : "Miss", value: "0006"},
				               {name : "Mrs", value: "0005"},
				               {name : "Dr", value: "DR"}
				           ];
			this.model = new sap.ui.model.json.JSONModel();
			this.model.setData({});
			this.getView().setModel(this.model);
    		sap.ui.getCore().setModel(this.model, "applicationModel");
			// Aggregation data from  completeRegModel
			this.model.setProperty("/firstName", sap.ui.getCore().getModel("completeRegModel").getProperty("/firstName"));
			this.model.setProperty("/lastName", sap.ui.getCore().getModel("completeRegModel").getProperty("/lastName"));
			this.model.setProperty("/emailAddress", sap.ui.getCore().getModel("completeRegModel").getProperty("/emailAddress"));
			this.model.setProperty("/customerNumber", sap.ui.getCore().getModel("completeRegModel").getProperty("/customerNumber"));
			this.model.setProperty("/workEmail", sap.ui.getCore().getModel("completeRegModel").getProperty("/workEmail"));
			this.model.setProperty("/title", "Mr");
			//this.model.setProperty("/licenceType", "Car");
			this.model.setProperty("/postState", "VIC");
			this.model.setProperty("/licenceRegion", "");
			this.model.setProperty("/driverLicence", "");
			this.model.setProperty("/phoneNumber", "");
			this.model.setProperty("/mobileNumber", "");
			this._mandatory = sap.ui.getCore().getModel("completeRegModel").getProperty("/mandatory") ==="true";
		    this._duplicate = sap.ui.getCore().getModel("completeRegModel").getProperty("/duplicate") ==="true";
		    // indicator of googleApi false means turn off true means turn on
		    this._googleApi = sap.ui.getCore().getModel("completeRegModel").getProperty("/googleAPI") === "true";
		   // this._mandatory = false;
		    this.model.setProperty("/mandatory", sap.ui.getCore().getModel("completeRegModel").getProperty("/mandatory"));
		    if (this._duplicate){
		    	this._customerData = sap.ui.getCore().getModel("completeRegModel").getProperty("/customerData");
		    	this.model.setProperty("/driverLicence", this._customerData.driverLicence);
		    	this.model.setProperty("/employeeNumber", this._customerData.employeeNumber);
		    	this.model.setProperty("/pre_formatted_address", this._customerData.fullAddress);
		    	// postal address
		    	this.model.setProperty("/streetName", this._customerData.streetName);
		    	this.model.setProperty("/streetNumber", this._customerData.streetNumber);
		    	this.model.setProperty("/postCode", this._customerData.postalCode);
		    	this.model.setProperty("/suburb", this._customerData.suburb);
		    	this.model.setProperty("/postState", this._customerData.state);
		    	
		    	this.model.setProperty("/fullAddress", this._customerData.fullAddress);
		    	this.model.setProperty("/licenceRegion", this._customerData.licenceRegion);
		    	//this.model.setProperty("/dateBirth", this._calendarConvert(this._customerData.dateofBirth));
		    	this.model.setProperty("/dateBirth", this._customerData.dateofBirth ==="0000-00-00" ? "":this._customerData.dateofBirth);
		    	this.model.setProperty("/title", this._titleConvert(this._customerData.title,"name"));
		    	this.model.setProperty("/phoneNumber", this._customerData.telephoneNumber);
		    	this.model.setProperty("/mobileNumber", this._customerData.mobileNumber);
		    }
		    //initialise properties  
		    this.getView().byId("lbDriverLicence").setRequired(this._mandatory );
		    this.getView().byId("driverLicence").setRequired(this._mandatory);
		    this.getView().byId("lbState").setRequired(this._mandatory);
		    this._initiliseFirstStep();
			this._userData ={};
			this._injectBanner();
			this._getLPMessage().quickhelp(this.getView().byId('fullAddress'),"Where the car will be garaged.");
			
			
			this._formElementImage  = sap.ui.getCore().byId('lpConfirmImg');
		    this._formElementStatus  = sap.ui.getCore().byId('customerStatus');
		    this._formContainerMsg  = sap.ui.getCore().byId('lpCustomerMessageForm');
		    this._formElementMsg  = sap.ui.getCore().byId('lpCustomerMessage');
			
			
			
			ga('send', 'pageview','startCompleteRegister');
		},
		
		onDialogClosed: function (oEvent) {
		 	jQuery.sap.clearDelayedCall(this._timeout);
 			
		},
		
		setLicenceTypeFromSegmented: function(evt) {
			var licenceType = evt.mParameters.button.getText();
		    this.model.setProperty("/licenceType", licenceType);
		},

		onAfterRendering: function() {
			this._injectBanner();
			// fallback of Google api turning down.
			this.getView().byId('fallBackAddress').setVisible(!this._googleApi);
			this.getView().byId('fullAddress').setVisible(this._googleApi);
			this.getView().byId('lbFullAddress').setVisible(this._googleApi);
			this.getView().byId('googleAddressCbx').setVisible(this._googleApi);
			var that = this;
			this.getView().byId('fullAddress').onkeyup = function(oEvent){
			(this.getValue().trim() ==="") && (function(){
				this.setValueState(sap.ui.core.ValueState.Error);
				that._basicInfoValidationAll();
			}).call(this);
				that.model.setProperty("/formatted_address", this.getValue());
			};
		},
	   
	   checkAdditionInfo: function(evt) {
			if( !this._getValidator().validate(evt)){
				this._wizard.invalidateStep(this.getView().byId("AdditionalInfo"));
			}else {
				this._additionalInfoValidationAll();  
			}
	   },
	   
	   checkStateChange: function(){
	   },

	   handleChangeDate: function(evt){
		if(evt.mParameters.valid){
				evt.oSource.setValueState(sap.ui.core.ValueState.None);
				this.model.setProperty("/dateBirth", evt.mParameters.value);
			}else{
				evt.oSource.setValueState(sap.ui.core.ValueState.Error);
			}
				this._basicInfoValidationAll();
	   },
		   
	   handleChangeFallBack: function(evt){
		  if( !this._getValidator().validate(evt)){
				this._wizard.invalidateStep(this.getView().byId("BasicInfo"));
		  }else {
		   this._basicInfoValidationAll();
		  }
	   },	   
	   
	   basicInfoValidation : function(){
	   },
	   // basic info check
	   basicInfoComplete : function() {
	   },
       
	   additionalInfoValidation : function () {
		 	this._wizard.validateStep(this.getView().byId("AdditionalInfo"));
		 //	this._wizard._nextButton.setText("Next Step >");
		},
	   // additional Complete check
	   additionalInfoComplete : function () {
		  // this._additionalInfoValidationAll();
	   },

	   optionalStepActivation: function() {
	   },
	   
	   optionalStepCompletion: function () {
           /// just leave it at this stage
	   },

	   tickBox: function(evt) {
		  this._googleApioffSelected =  evt.mParameters.selected;
		//  this._googleApi =  !this._googleApioffSelected;
		  this.byId("fallBackErrorMessage").setVisible(false);
		  this.getView().byId('fallBackAddress').setVisible(this._googleApioffSelected);
		  this.getView().byId('fullAddress').setVisible(!this._googleApioffSelected);
		  this.getView().byId('lbFullAddress').setVisible(!this._googleApioffSelected);
		  this._basicInfoValidationAll();
	   
	   },

	   //google geo call
		completeAddress: function() {
			var that = this,
				oModle = new sap.ui.model.json.JSONModel(),
			    addressInput = this.byId("fullAddress").getValue(),
			    addUrl = "https://maps.googleapis.com/maps/api/geocode/json?address=" + addressInput + "&components=country:AU&key=AIzaSyB-W0s81dBYgPLFIhPLrI7wv-vmJJPYTbg";
			   $.ajax({
				headers: {
					'Accept': 'application/json'
				},
				url: addUrl,
				type: "GET",
				jsonpCallback: "getJSON",
				dataType: "json",
				success: function(data, status, xhr) {
					that.model.setProperty("/results", data.results);
					that.model.setProperty("/status", data.status);
					if (that.model.getProperty("/pre_formatted_address") !== that.model.getProperty("/formatted_address") /*||  that.model.getProperty("/pre_formatted_address") === undefined*/ ){
						that.byId("fullAddress").setValueState(sap.ui.core.ValueState.Error);
					}else {
						that.byId("fullAddress").setValueState(sap.ui.core.ValueState.None);
					}
					that._basicInfoValidationAll();
				},
				error: function(predictions, status, jqXHR, error) {
					that.byId("fullAddress").setValueState(sap.ui.core.ValueState.Error);
				}
			});
		},
		
		onAddressSelected: function(evt) {
			var selectedPath = evt.getParameters().selectedItem.getBindingContext().getPath(),
				itemNumber = selectedPath.slice(9),
				result =  evt.getParameters().selectedItem.getBindingContext().getModel().getData().results[itemNumber],
				getAddComp = result.address_components,
				formatted_address = result.formatted_address,
				strObject ="",
				strObjectAll ="",
				addCompName ="",
				jsonData = {addressData:null};
			
			for (var i = 0; i < getAddComp.length; i++) {
				addCompName = getAddComp[i].types[0].replace(/_/g,"");
				strObject = addCompName + "Long";
				strObject = "\"" + strObject+  "\" : " +  "\"" + getAddComp[i].long_name + "\"";
				strObject =  strObject  +  ", " +   "\"" + addCompName + "Short" + "\" : \"" +   getAddComp[i].short_name + "\",";
				strObjectAll = strObjectAll + strObject;
			}
			
			strObjectAll = "{" + strObjectAll.slice(0, -1) + "}";
			var obj = JSON.parse(strObjectAll);
			this.model.setProperty("/userData",obj);
			this.model.setProperty("/formatted_address",formatted_address);
			this.model.setProperty("/pre_formatted_address",formatted_address);
			// validate address 
			this.byId("fullAddress").setValueState(sap.ui.core.ValueState.None);
			this._basicInfoValidationAll();
		},

	    wizardCompletedHandler : function () {
			this._addressValidation(); 
		},
		
		backToWizardContent : function () {
			this._oNavContainer.backToPage(this._oWizardContentPage.getId());
			this._injectBanner();
		},
		
		editStepOne : function () {
			this._handleNavigationToStep(0);
		},
		editStepTwo : function () {
			this._handleNavigationToStep(1);
		},
		editStepThree : function () {
			this._handleNavigationToStep(2);
		},

	   _onOpenDialog: function (oEvent) {
			// instantiate dialog
			if (!this._dialog) {
				this._dialog = sap.ui.xmlfragment("com.lp.selfRegister.fragments.BusyDialog", this);
				this.getView().addDependent(this._dialog);
			}
			// open dialog
			jQuery.sap.syncStyleClass("sapUiSizeCompact", this.getView(), this._dialog);
			this._dialog.open();
		},
		
		_calendarConvert: function(inputDate){
			if (inputDate && inputDate.length === 10){
				return inputDate.slice(8,10) +"/" + inputDate.slice(5,7) +"/"+ inputDate.slice(2,4);
			} else {
				return null;
			}
		},
		
		_titleConvert: function(inputValue,outputValue){
		  var filterArray = this._titleArr.filter((function(item){
				if (outputValue === "name"){
					if (item.value === inputValue) {
					return item;
					}
				}else{
					if(item.name === inputValue) {
					return item;
					}
				}
			}));
			if (filterArray.length > 0){  
				return outputValue ==="value" ? filterArray[0].value: filterArray[0].name;
			}else {
				return "";
			}
		},
	
		// in case of data populated from existing customer
		_initiliseFirstStep: function(){
		
			if (this._duplicate){
			   if (this.model.getProperty("/fullAddress") && this.model.getProperty("/dateBirth") ){
					this._wizard.validateStep(this.getView().byId("BasicInfo"));
					//this._wizard._nextButton.setText("Next Step >");
			   }
			}
		},
	
		/*inject company logo as there is nowhere to attach it via UI5 framework so far */
		_injectBanner: function() {
			if ($(".selfRegister_lp_banner_complete").length === 0 ){
				if (sap.ui.getCore().getModel("device").oData.system.phone){
	/*		$('<div class="selfRegister_lp_banner_complete"><img src="../selfRegister/images/leaseplan_logo.png" class="selfRegister_lp_logo_mobile" ></div>').insertBefore(".sapMWizardHeader");
	*/						
				}else{
			$('<div class="selfRegister_lp_banner_complete"><img src="../selfRegister/images/leaseplan_logo.png" class="selfRegister_lp_logo" ></div>').insertBefore(".sapMWizardHeader");
		}
				}
		},

		_additionalInfoValidationAll : function (){
			var rtv = true;
			if (this._mandatory ||   this.model.getProperty("/driverLicence") !==""){  // check mandatory fields
				if (this.model.getProperty("/licenceRegion") === "") {
					//this.byId("licenceRegion").setValueState(sap.ui.core.ValueState.Error);
					this.byId("licenceRegion").addStyleClass("SelectError");
					this._wizard.invalidateStep(this.getView().byId("AdditionalInfo"));
					rtv = false;
				}else {
					this.byId("licenceRegion").removeStyleClass("SelectError");
				}
			}else{
				this.byId("licenceRegion").removeStyleClass("SelectError");
				
			}
			if (this._getValidator().validate(this.getView().byId("additionalForm")) ){
					rtv = true && rtv ;
					rtv ?  this._wizard.validateStep(this.getView().byId("AdditionalInfo")): this._wizard.invalidateStep(this.getView().byId("AdditionalInfo"));
				}else {
					this._wizard.invalidateStep(this.getView().byId("AdditionalInfo"));
						rtv = false;
				}
			return rtv;
		}, 
		
		_basicInfoValidationAll : function (){
			 if (this._basicInfoFieldsCheck()){
				 this._wizard.validateStep(this.getView().byId("BasicInfo"));
			 }else {
				 this._wizard.invalidateStep(this.getView().byId("BasicInfo"));
			 }
			 //this._wizard._nextButton.setText("Next Step >");
		},
		
		_basicInfoFieldsCheck: function () {
			var oData = this.getView().getModel().getData();
			if (this._googleApi &&  !this._googleApioffSelected) {
				if (this.byId("fullAddress").getValue() ===""){
					this.byId("fullAddress").setValueState(sap.ui.core.ValueState.Error);
				}
				
				if (this.byId('fullAddress').getValueState() === sap.ui.core.ValueState.Error ||
					this.byId('dateBirth').getValueState() === sap.ui.core.ValueState.Error || oData.dateBirth === undefined || oData.dateBirth  ==="") {
					 return false;
				}else {
					return true;
				}
			} else {  // in case of google turn down
				if (this.byId('dateBirth').getValueState() === sap.ui.core.ValueState.Error || oData.dateBirth === undefined || oData.dateBirth  ==="" ||!this._getValidator().validate(this.getView().byId("fallBackAddress")) ){
					return false
				}else {
					return true;
				}
			}
		},
      	
		_assembleFallBackAddress: function() {
			var  JSONObject = {
				"streetnumberLong":  this.model.getProperty("/streetNumber").trim(),
				"streetnumberShort":  this.model.getProperty("/streetNumber").trim(),
				"postalcodeLong":   this.model.getProperty("/postCode").trim(),
				"postalcodeShort":   this.model.getProperty("/postCode").trim(),
				"localityLong":   this.model.getProperty("/suburb").trim(), //suburb
				"localityShort":   this.model.getProperty("/suburb").trim(), //suburb
				"routeLong":   this.model.getProperty("/streetName").trim(),   //street name
				"routeShort":   this.model.getProperty("/streetName").trim(),   //street name
				"administrativearealevel1Long":   this.model.getProperty("/postState").trim(),  //state
				"administrativearealevel1Short":   this.model.getProperty("/postState").trim(),  //state
				"countryLong":  "Australia",  //country
				"countryShort":  "AU",  //country
			};

			this.model.setProperty("/pre_formatted_address",this.model.getProperty("/streetNumber") + " "+ this.model.getProperty("/streetName")+", "+ this.model.getProperty("/suburb")+
			" "+ this.model.getProperty("/postState") +" "+ this.model.getProperty("/postCode")+", "+ "Australia");
			this.model.setProperty("/userDataFallBack",JSONObject);
		},
		
		// call back end (CRM) to check address 
		_addressValidation : function () {
		   var oData = this.getView().getModel().getData(),
			    addressData =  oData.userData;
		
		   if (!this._googleApi  || this._googleApioffSelected){
			   this._assembleFallBackAddress();
			   addressData  =  oData.userDataFallBack ;
			   	this._userData.googleIndicator = "false"; // data from google (true) or manual input (false) 
			  }else {
				  this._userData.googleIndicator = "true"; // data from google (true) or manual input (false)   
			  }
		    // call webservice to check data
			// busy indicator loading
			this._onOpenDialog();
			this._userData.resiAddress = addressData; // need to be check 
			this._userData.emailAddress = this.model.getProperty("/emailAddress");
			this._timeout = jQuery.sap.delayedCall(500, this, function (){
				this._getWebService().callPortalService("verifyAddress",this._userData,this._navgateReviewPage,this);
			});
		  return true;
		}, 
		
		_navgateReviewPage : function(data, stage) {
		 // busy indicator close
	    	this._dialog && this._dialog.close();
	    	if (stage==="verifyAddress") {
				if ( data.returnCRM === "true") {
					if (this._basicInfoFieldsCheck()){
						// check addtional info 
						if(!this._additionalInfoValidationAll()){
							(function fnAfterNavigate () {
								this._wizard.goToStep(this._wizard.getSteps()[1]);   // navigate to step2
								this._oNavContainer.detachAfterNavigate(fnAfterNavigate);
							}).call(this);
							this.backToWizardContent();
							return false;
						}
						(!this._googleApi  || this._googleApioffSelected) || this.model.setProperty("/pre_formatted_address", this.getView().byId('fullAddress').getValue());
					    this._oNavContainer.to(this._oWizardReviewPage);
						return true;
					}else {
						(function fnAfterNavigate () {
							this._wizard.goToStep(this._wizard.getSteps()[0]); // navigate to step1
							this._oNavContainer.detachAfterNavigate(fnAfterNavigate);
						}).call(this);
						//this._oNavContainer.attachAfterNavigate(fnAfterNavigate);
						this.backToWizardContent();
						return false;
					}
				} else {
					(function fnAfterNavigate () {
						this._wizard.goToStep(this._wizard.getSteps()[0]); // navigate to step1
						this._oNavContainer.detachAfterNavigate(fnAfterNavigate);
					}).call(this);
					//this._oNavContainer.attachAfterNavigate(fnAfterNavigate);
					
					  if (data.returnUME ==="false"){  // session lost 
						    this._getLPMessage().loadSystemMessage().open();
							this._getLPMessage().setMessageType(false);
							this._getLPMessage().setMessage("Your session has expired, please sign in again.");
						  
					  }else{
						  if (!this._googleApi  || this._googleApioffSelected) { 
							  	this.byId("fallBackErrorMessage").setVisible(true);
						  }else{
								this.byId("fullAddress").setValueState(sap.ui.core.ValueState.Error);
						  }
					  }
					this.backToWizardContent();
					return false;
				}
	   	}else{
				   ///system error as web service down
	   		   	 (function(){
					 this._getLPMessage().loadSystemMessage().open();
					 this._getLPMessage().setMessageType(false);
					 this._getLPMessage().setMessage(this._getLPMessage().callLeasePlan());
				 }).call(this);
			}
		},
	
		/**
		* Construct form validator instance 
		* @private
		* @return {object} 
		*/
         _getValidator : function() {
            if  (!this._validator){
            	   this._validator  = new Validator();
            }
            return this._validator;
        },

  		/**
		* 
		* @private
		* @return {object} 
		*/
		_handleNavigationToStep : function (iStepNumber) {
			var that = this,
				pageTitle = that._wizard.getProgressStep().mProperties.title;
			if (pageTitle === "Basic Info") {  // go back to entry 
				this._router.getTargets().display("EnterCustNum");
			}else{
				function fnAfterNavigate () {
					that._wizard.goToStep(that._wizard.getSteps()[iStepNumber]);
					that._oNavContainer.detachAfterNavigate(fnAfterNavigate);
				}
				this._oNavContainer.attachAfterNavigate(fnAfterNavigate);
				this.backToWizardContent();
			}
		},
		
		/**
		* 
		* @private
		* @return {object} 
		*/
		_handleMessageBoxOpen : function (sMessage, sMessageBoxType) {
			var that = this;
			MessageBox[sMessageBoxType](sMessage, {
				actions: [MessageBox.Action.YES, MessageBox.Action.NO],
				onClose: function (oAction) {
					if (oAction === MessageBox.Action.YES) {
						that._handleNavigationToStep(0);
						that._wizard.discardProgress(that._wizard.getSteps()[0]);
					}
				},
			});
		},
		
		/**
		* @private
		* @return {object} 
		*/
	
		_handleMessageBoxOpenSubmit : function (sMessage, sMessageBoxType) {
			var that = this;
			MessageBox[sMessageBoxType](sMessage, {
				title:"Confirm Registration",
				actions: [MessageBox.Action.YES, MessageBox.Action.NO],
				onClose: function (oAction) {
					if (oAction === MessageBox.Action.YES) {
						///  busy indicator loading
						that._onOpenDialog();
						that._timeout = jQuery.sap.delayedCall(1000, this, function () {
							that._getWebService().callPortalService("createDriver",that._assemblePostData(that.getView().getModel().getData()),that._navigationToConfirmPage,that);
						});
					}
				},
			});
		},
        
  		/**
		* @private
		* @return {object} 
		*/
		_assemblePostData : function(oData) {
			var mydate = new Date(oData.dateBirth),
			    varYear = mydate.getFullYear(),
			    varMonth = mydate.getMonth() + 1,
			    varDate = mydate.getDate();
			  if (!this._googleApi  || this._googleApioffSelected)  {
					oData.userDataFallBack && (this._userData.resiAddress = oData.userDataFallBack);
			  }else {
					oData.userData && (this._userData.resiAddress = oData.userData);
			  }
			this._userData.customerNumber = oData.customerNumber;
			this._userData.firstName = oData.firstName;
			this._userData.lastName  = oData.lastName;
			this._userData.title = this._titleConvert(oData.title,"value");
			this._userData.dateofBirth = ""+ varYear + ("0"+varMonth).slice(-2) + ("0"+ varDate).slice(-2);
			this._userData.emailAddress = oData.emailAddress;
			this._userData.driverLicence = oData.driverLicence;
			this._userData.licenceType = oData.licenceType;
			this._userData.workEmail = oData.workEmail;
			this._userData.employeeNumber = oData.employeeNumber;
			this._userData.telephoneNumber = oData.phoneNumber;
			this._userData.mobileNumber = oData.mobileNumber;
			this._userData.licenceRegion = oData.licenceRegion;
			return this._userData;
		},

  		/**
		* @private
		* @return {object} 
		*/
		_navigationToConfirmPage : function(data,stage){
			// busy indicator close
			this._dialog && this._dialog.close();
			this._showGoPortalLink = false;
			ga('send', 'pageview','submitCompleteRegister');
			if (stage ==="createDriver") {
				if(data.returnUME === "true"){
					if (data.returnCRM ==="true"){
						if (data.appStatus === "COMPLETE") {
							//redirect to portal home page
							this._imageSrc = "../../selfRegister/images/checkMark.png";
							this._txtStatus = data.errReason; //"Done and Approved!"; 
							this._showGoPortalLink = true;
							this._txtCustomerMsg = "";
							/*	jQuery.sap.delayedCall(5000, this, function() {
							window.location.replace("/irj/portal");
							});*/
							
						}else if (data.appStatus === "PENDING") {
							this._imageSrc = "../../selfRegister/images/checkMark.png";
							this._txtStatus = data.errReason; // "Done and awaiting approval!";
							this._txtCustomerMsg = "";
						}

					}else{   // CRM false
						this._imageSrc = "../../selfRegister/images/reject.png";
						this._txtStatus = "Whoops! Something went wrong. Please try again or contact LeasePlan and quote error code " + data.errReason + " on 132 572 if the issue continues."; 
						this._txtCustomerMsg = "";
					}

				}else{
					this._imageSrc = "../../selfRegister/images/reject.png";
					this._txtStatus = "Whoops! Something went wrong. Please try again or contact LeasePlan on 132 572 if the issue continues."; 
					this._txtCustomerMsg = ""; 
				}
				this._renderComfirmPage();

			} else {
				///system error as web service down
				this._imageSrc = "../../selfRegister/images/reject.png";
				this._txtStatus = "";
				this._txtCustomerMsg = "LeasePlan Online is temporarily unavailable, please try again later or call 132 572."; 
				this._renderComfirmPage();
			}
			this._oNavContainer.to(this._oWizardConfirmPage);
    	},
    	

    	_renderComfirmPage : function(){
    		this._formElementImage.setSrc(this._imageSrc);
    		this._formElementStatus.setText(this._txtStatus);
    		this._formContainerMsg.setVisible(this._showGoPortalLink);
    		this._formElementMsg.setText(this._txtCustomerMsg);
		},

	   /**
		* 
		* @private
		* @return {object} 
		*/
		_goToPortal : function(){
			window.location.replace("/irj/portal");	
		},
		
	 	/**
		* @private
		* @return {object} 
		*/
	
		NavToPortal: function(){
			this._goToPortal();
		},
	   
		 /**
		* Construct portal service instance 
		* @private
		* @return {object} 
		*/
		 _getWebService : function() {
	        if  (!this._webservice){
	        	 this._webservice = new Webservice();
	        }
	        return this._webservice;
	    },
      
        /**
		* Construct form LPMessage instance 
		* @private
		* @return {object} 
		*/
        _getLPMessage : function() {
            if  (!this._LPMessage){
            	   this._LPMessage  = new LPMessage();
            }
            return this._LPMessage;
        },
		_setEmptyValue : function (sPath) {
			this.model.setProperty(sPath, "n/a");
		},
	    onExit: function() {
	    	 this._getLPPopover().destroyPopover();
		},
		getInfo: function(evt) {
			 this._getLPPopover().loadPopover();
			 this._getLPPopover().setMessage("The verification code is that you received in your work email " + this._oModel.oData.workEmail );
		 var oInput = evt.getSource();
			jQuery.sap.delayedCall(0, this, function() {
				 this._getLPPopover().getPopover().openBy(oInput);
			});
	   },
	   
	    handleWizardCancel : function () {
			this._handleMessageBoxOpen("Are you sure you want to cancel your registration?", "warning");
		},

		handleWizardSubmit : function () {
			this._handleMessageBoxOpenSubmit("Are you sure you want to submit your registration?", "confirm");
		},

		productWeighStateFormatter: function (val) {
			return isNaN(val) ? "Error" : "None";
		},
		
		 /**
		* define typeInput format and regex 
		*/
		typeInputPhone: SimpleType.extend("phoneNumber", {
			formatValue: function(oValue) {
				return oValue;
			},
			parseValue: function(oValue) {
				return oValue;
			},
			validateValue: function(oValue) {
				var reg = /^\d+$/;
				if (oValue){
				if (!oValue.match(reg)) {
						throw new ValidateException(oValue+" is not correct, please enter your mobile phone code in digital numbers ");
					}
				}else {
					
					if (sap.ui.getCore().getModel("applicationModel").getProperty("/mobileNumber") ==="") {
						throw new ValidateException("Please enter your phone number.");
					}
				}
			 
			}
		}),
		
		 /**
		* define typeInput format and regex 
		*/
		typeInputMobile: SimpleType.extend("mobileNumber", {
			formatValue: function(oValue) {
				return oValue;
			},
			parseValue: function(oValue) {
				return oValue;
			},
			validateValue: function(oValue) {
				var reg = /^\d+$/;
				if (oValue){
				if (!oValue.match(reg)) {
						throw new ValidateException(oValue+ " is not correct , please enter your mobile phone code in digital numbers ");
					}
				}else{
					
					/*if (sap.ui.getCore().getModel("applicationModel").getProperty("/phoneNumber") ==="") {
						throw new ValidateException("Please at least leave one contact number.");
					}*/
				}
			 
			}
		}),
		
		/**
		* validate fall back Address 
		*/
        typeInput: SimpleType.extend("input",{
			formatValue: function(oValue) {
				return oValue;
			},
			parseValue: function(oValue) {
				return oValue;
			},
			validateValue: (function(oValue) {
				if (!oValue) {
					throw new ValidateException("Required field.");
				}
			}).bind(this)
		}),
		
		/**
		* validate DriverLicence
		*/
		
		typeInputDiverLicence: SimpleType.extend("input",{
			formatValue: function(oValue) {
				return oValue;
			},
			parseValue: function(oValue) {
				return oValue;
			},
			validateValue: (function(oValue) {
			    var mandatory = sap.ui.getCore().getModel("applicationModel").getProperty("/mandatory") ==="true";
				if (!oValue && (mandatory || sap.ui.getCore().getModel("applicationModel").getProperty("/licenceRegion") !=="")) {
					throw new ValidateException("Please enter driver licence.");
				}
			}).bind(this)
		}),
		
		
		/**
		* validate fall back Address 
		*/
        typeInputPostCode: SimpleType.extend("postcode",{
			formatValue: function(oValue) {
				return oValue;
			},
			parseValue: function(oValue) {
				return oValue;
			},
			validateValue: function(oValue) {
				var reg = /^\d+$/;
				if (!oValue) {
					throw new ValidateException("Required field.");
				}
			
			   if (!oValue.match(reg)) {
						throw new ValidateException(oValue+ " is not correct , please enter your post code in digital numbers ");
					}
				
			}
		}),
		
				
		discardProgress: function () {
			this._wizard.discardProgress(this.getView().byId("BasicInfo"));
			var clearContent = function (content) {
				for (var i = 0; i < content.length ; i++) {
					if (content[i].setValue) {
						content[i].setValue("");
					}

					if (content[i].getContent) {
						clearContent(content[i].getContent());
					}
				}
			};
			clearContent(this._wizard.getSteps());
		}
	});

//	return WizardController;
});
