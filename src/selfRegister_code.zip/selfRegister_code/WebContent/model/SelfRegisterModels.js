/*!
 * Built by LeasePlan AU
 * version: v1.0.0
 * Author: Wei Tao
 * Date: Aug 2017
 */
sap.ui.define([ 
	'sap/ui/model/json/JSONModel',
    "sap/ui/Device",
    "sap/ui/model/resource/ResourceModel"
	], function (JSONModel,Device,ResourceModel) {
	
	"use strict";
    
    /**
     * initialize data model when instance has been constructed
     */
	var selfRegisterModels = function () {

		this._passwordRestData = {
			userId:"",
			token: "",
			password: "",
			passwordConfirmed: ""
		};
		
		this._emailData = {
			emailAddress:""
		};

		this._initSelfReg= {
			firstName: "",
			lastName: "",
			email: "",
			customerNumber:"",
			password: "",
			confirmPassword: ""
		};

		this._completeReg =  
		{
			firstName: "",
			lastName: "",
			customerNumber: "",
			emailAddress: "",
			workEmail:"",
			refNumber:"",
			verifyCodeFlag:"",
			duplicate:"false",
			googleApi:"false",
			mandatory:"true"
		};

		this._verifyCode = {
			emailAddress :"",
			firstName :"",
			lasteName :"",
			verifyCode:""
		};
	};
	 
	/**
	* return instance of passowrdReset data as JSONModel
	* @return {object} JSONModel
	*/
	selfRegisterModels.prototype.createPasswordResetDataModel = function() {
		return new JSONModel(this._passwordRestData);
	};
	
	/**
	* return instance of email data as JSONModel
	* @return {object} JSONModel
	*/
	selfRegisterModels.prototype.createEmailDataModel = function() {
		return new JSONModel(this._emailData);
	};
	
	selfRegisterModels.prototype.createDeviceModel= function () {
		var oModel = new JSONModel(Device);
		    oModel.setDefaultBindingMode("OneWay");
		return oModel;
	};
	
	selfRegisterModels.prototype.createResourceModel=function (sBundleName) {
		return new ResourceModel({
			"bundleName": sBundleName
		});
	};
	
	/**
	* return instance of initialReg data as JSONModel
	* @return {object} JSONModel
	*/
	selfRegisterModels.prototype.createInitSelfRegModel = function () {
		return new JSONModel(this._initSelfReg);
	};

	/**
	* return instance of VerifyCode data as JSONModel
	* @return {object} JSONModel
	*/
	selfRegisterModels.prototype.createVerifyCodeModel = function () {
		return new JSONModel(this._verifyCode);
	};

	/**
	* return instance of completeReg data as JSONModel
	* @return {object} JSONModel
	*/
	selfRegisterModels.prototype.createCompleteRegModel = function () {
		return new JSONModel(this._completeReg);
	};
		return selfRegisterModels;
});