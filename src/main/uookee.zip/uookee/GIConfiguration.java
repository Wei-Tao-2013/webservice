package com.gi.uookee;

import com.gi.uookee.config.JwtFilter;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.web.servlet.FilterRegistrationBean;
import org.springframework.context.annotation.Bean;


@SpringBootApplication(scanBasePackages={GIConfiguration.GISERVICE})
//@ImportResource("classpath:mongo-config.xml")
public class GIConfiguration {

	private static final Logger logger = LoggerFactory.getLogger(GIConfiguration.class);

	static final String GISERVICE = "com.gi.uookee";

	@Value("${encrypted.tokenSecret}")
	private String tokenSecret;

	@Bean
	@SuppressWarnings("rawtypes")
	public FilterRegistrationBean jwtFilter() {
		final FilterRegistrationBean registrationBean = new FilterRegistrationBean();
		
		JwtFilter jwtFilter = new JwtFilter();
		jwtFilter.setTokenSecret(tokenSecret);
		registrationBean.setFilter(jwtFilter);
		registrationBean.addUrlPatterns("/gi/*");
		return registrationBean;
	}

	public static void main(String[] args) {

		SpringApplication.run(GIConfiguration.class, args);
		
	}

}
