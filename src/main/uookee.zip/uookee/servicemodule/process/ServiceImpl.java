package com.gi.uookee.servicemodule.process;

import com.gi.uookee.common.model.Request;
import com.gi.uookee.common.model.Response;
import com.gi.uookee.common.process.ServiceManage;
import com.gi.uookee.servicemodule.service.ServiceAPI;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

@Component
public class ServiceImpl implements ServiceAPI {

    private static final Logger logger = LoggerFactory.getLogger(ServiceImpl.class);

    @Autowired @Qualifier("generalServiceManage")
    private ServiceManage serviceManage;
   
    @Override
	public Response draftAService(Request request) {
        return serviceManage.draftAService(request);
	}

	@Override
	public Response registerAService(Request request) {
		return serviceManage.registerAService(request);
	}

	@Override
	public Response loadServices(String userId, String serviceStatus) {
    	return serviceManage.loadServices(userId,serviceStatus);
	}
    
}