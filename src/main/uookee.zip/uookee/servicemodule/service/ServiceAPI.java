package com.gi.uookee.servicemodule.service;

import com.gi.uookee.common.model.Request;
import com.gi.uookee.common.model.Response;

public interface ServiceAPI{

    Response draftAService(Request request);
    Response registerAService(Request request);
    Response loadServices(String userId,String serviceStatus);
    
   
}