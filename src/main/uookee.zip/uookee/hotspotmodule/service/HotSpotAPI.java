package com.gi.uookee.hotspotmodule.service;

import com.gi.uookee.common.model.Request;
import com.gi.uookee.common.model.Response;

public interface HotSpotAPI{

    Response toggleHotSpotList(Request request);
    Response loadHotSpotService(Request request);
   
}