package com.gi.uookee.hotspotmodule.process;

import com.gi.uookee.common.model.Request;
import com.gi.uookee.common.model.Response;
import com.gi.uookee.common.process.HotSpotManage;

import com.gi.uookee.hotspotmodule.service.HotSpotAPI;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

@Component
public class HotSpotImpl implements HotSpotAPI {

    private static final Logger logger = LoggerFactory.getLogger(HotSpotImpl.class);

    @Autowired @Qualifier("hotSpotManage")
    private HotSpotManage hotSpotManage;
   
    @Override
	public Response toggleHotSpotList(Request request) {
        return hotSpotManage.toggleHotSpotList(request.getUserId(), request.getServiceIdList());
	}

	@Override
	public Response loadHotSpotService(Request request) {
		return hotSpotManage.loadHotSpotService(request.getUserId());
		
	}

}