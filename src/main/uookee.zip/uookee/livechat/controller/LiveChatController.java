package com.gi.uookee.livechat.controller;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.messaging.handler.annotation.DestinationVariable;
import org.springframework.messaging.handler.annotation.MessageMapping;
import org.springframework.messaging.handler.annotation.SendTo;
import org.springframework.messaging.simp.SimpMessagingTemplate;
import org.springframework.stereotype.Controller;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;

@Controller
public class LiveChatController {
    
    private SimpMessagingTemplate template;

    @Autowired
    LiveChatController(SimpMessagingTemplate template){
        this.template = template;
    }

    @MessageMapping("/send/message")
    public void onReceivedMesage(String message){
        this.template.convertAndSend("/chat",  new SimpleDateFormat("HH:mm:ss").format(new Date())+"- "+message);
    }

    @MessageMapping("/{serviceId}/{userId}")  // send mapping always combind serviceid and client id this as a vendor 
    private void sendMessagetoUser(String message, @DestinationVariable String userId) throws IOException {
        this.template.convertAndSend("/privateRoom/" + userId,  new SimpleDateFormat("HH:mm:ss").format(new Date())+"- "+message);
    }
    
    @MessageMapping("/{serviceId}/{userId}")  // send mapping always combind serviceid and client id this as a user 
    private void sendMessagetoVendor(String message, @DestinationVariable String serviceId) throws IOException {
        this.template.convertAndSend("/privateRoom/" + serviceId,  new SimpleDateFormat("HH:mm:ss").format(new Date())+"- "+message);
    }
    

    /*
    @MessageMapping("/hello")  // sending message mapping
    @SendTo("/topic/greetings")  //subsribing topic  // for vendor should listion all clients  , for user should subsribed all service 
    public Greeting greeting(HelloMessage message) throws Exception {
        return new Greeting("Hello, " + HtmlUtils.htmlEscape(message.getName()) + "!");
    }

    */

}
