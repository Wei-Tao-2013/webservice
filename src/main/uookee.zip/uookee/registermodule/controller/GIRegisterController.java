package com.gi.uookee.registermodule.controller;

import com.gi.uookee.common.model.Request;
import com.gi.uookee.common.model.Response;
import com.gi.uookee.common.utils.GIutils;
import com.gi.uookee.registermodule.service.RegisterAccountAPI;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
@CrossOrigin
public class GIRegisterController {
  
    @Autowired 
    private RegisterAccountAPI registerAPI;
    private static final Logger logger = LoggerFactory.getLogger(GIRegisterController.class);

    @RequestMapping(value = "/sayHello/{callName}/{message}", method = RequestMethod.GET,headers="Accept=text/plain")
    public @ResponseBody String sayHello(@PathVariable("callName") String callName,@PathVariable("message") String message) throws Throwable  {
		return "hello bro "+ callName+" ---> "  +message;  
    }


    @RequestMapping(value = "/getMessageInfo/{callName}/{message}", method = RequestMethod.GET,headers="Accept=text/plain")
    public @ResponseBody Response getMessageInfo(@PathVariable("callName") String callName,@PathVariable("message") String message) throws Throwable  {
      Response response = new Response();
      response.setAppInfo(callName);
      response.setAppCode(message);
      return response;
    }

    @RequestMapping(value="/gi/postTest",method = RequestMethod.POST,headers="Accept=application/json")
    public @ResponseBody Response postTest(@RequestBody Request request) throws Throwable  {		
       Response response = new Response();
       response.setAppInfo(request.getAppInfo());
       return response;
    }


    
    @RequestMapping(value="/gi/weixinRegister",method = RequestMethod.POST,headers="Accept=application/json")
    public @ResponseBody Response register(@RequestBody Request request) throws Throwable  {		
         return registerAPI.weixinRegister(request);
    }

    @RequestMapping(value="/weixinSignAccount",method = RequestMethod.POST,headers="Accept=application/json")
    public @ResponseBody Response signAccount(@RequestBody Request request) throws Throwable  {		
         return registerAPI.weixinSignAccount(request);
    }

    @RequestMapping(value="/gi/weixinSignOut",method = RequestMethod.POST,headers="Accept=application/json")
    public @ResponseBody Response signOutTest(@RequestBody Request request) throws Throwable  {		
         return registerAPI.weixinSignOut(request);
    }

    @RequestMapping(value="/gi/weixinProfileUpdate",method = RequestMethod.POST,headers="Accept=application/json")
    public @ResponseBody Response weixinProfileUpdate(@RequestBody Request request) throws Throwable  {		
      logger.debug("controrll request is {}", GIutils.converToJson(request));
      return registerAPI.weixinProfileUpdate(request);
    }

    @RequestMapping(value="/gi/refreshToken",method = RequestMethod.POST,headers="Accept=application/json")
    public @ResponseBody Response refreshToken(@RequestBody Request request) throws Throwable  {		
         return registerAPI.refreshToken(request);
    }

    @RequestMapping(value="/refreshToken",method = RequestMethod.POST,headers="Accept=application/json")
    public @ResponseBody Response devrefreshToken(@RequestBody Request request) throws Throwable  {		
         return registerAPI.refreshToken(request);
    }


  


}
