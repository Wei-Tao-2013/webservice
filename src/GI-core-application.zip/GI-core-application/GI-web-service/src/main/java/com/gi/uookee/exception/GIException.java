package com.gi.uookee.exception;

public class GIException extends Exception {

	/** For serialization. */
	private static final long serialVersionUID = -7321749619071144888L;
	
	
	public GIException() {
		super();
	}
	
	public GIException(final String message) {		
		super(message);
	}


	public GIException(final String message,Throwable cause){

		super(message,cause);
	}


}
