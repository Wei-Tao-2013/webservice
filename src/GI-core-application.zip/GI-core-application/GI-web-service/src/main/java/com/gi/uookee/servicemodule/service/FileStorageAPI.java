package com.gi.uookee.servicemodule.service;

import java.util.Map;

import com.gi.uookee.common.model.FileData;
import com.gi.uookee.common.model.Request;
import com.gi.uookee.common.model.Response;
import com.gi.uookee.exception.GIException;

import org.bson.types.Binary;
import org.springframework.core.io.InputStreamResource;
import org.springframework.core.io.Resource;
import org.springframework.http.ResponseEntity;
import org.springframework.web.multipart.MultipartFile;

public interface FileStorageAPI{

    Response storeFile(String request,MultipartFile file) throws GIException;
    
    Response loadFileAsResource(String serviceId) throws GIException;

    FileData getFile(String fileId);

    Response deleteFile(String fileId);
    
   
}