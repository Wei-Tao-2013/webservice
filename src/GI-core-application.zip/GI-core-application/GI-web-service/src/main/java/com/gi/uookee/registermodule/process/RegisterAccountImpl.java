package com.gi.uookee.registermodule.process;

import com.gi.uookee.common.model.Request;
import com.gi.uookee.common.model.Response;

import com.gi.uookee.common.process.AccountRegister;
import com.gi.uookee.common.process.JWToken;
import com.gi.uookee.registermodule.service.RegisterAccountAPI;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

@Component
public class RegisterAccountImpl implements RegisterAccountAPI {
    private static final Logger logger = LoggerFactory.getLogger(RegisterAccountImpl.class);

    @Autowired @Qualifier("weixinAccount")
    private AccountRegister weiXinAccountRegister;
    @Autowired
    private JWToken jwtoken;

    @Override
	public Response weixinRegister(Request request) {
       return  weiXinAccountRegister.register(request);
	}

	@Override
	public Response weixinSignAccount(Request request) {
        return  weiXinAccountRegister.signAccount(request);
    }

    @Override
	public Response weixinSignOut(Request request) {
        return weiXinAccountRegister.signOut(request);
    }

    @Override
	public Response refreshToken(Request request) {
       return jwtoken.generateToken(request.getTokenSeed());
    }

	@Override
	public Response weixinProfileUpdate(Request request) {
        return weiXinAccountRegister.profileUpdate(request);
	}
    
}