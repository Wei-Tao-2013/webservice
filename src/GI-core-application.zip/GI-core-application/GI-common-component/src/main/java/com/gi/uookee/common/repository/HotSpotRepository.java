package com.gi.uookee.common.repository;

import java.util.List;

import com.gi.uookee.common.model.HotSpot;

import org.springframework.data.mongodb.repository.MongoRepository;
public interface HotSpotRepository extends MongoRepository<HotSpot, String>, HotSpotRepositoryCustom{
    public HotSpot findByHotSpotId(String hotSpotId);
    public List<HotSpot> findByUserId(String UserId);
   
}