package com.gi.uookee.common.model;

import java.time.LocalDateTime;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.index.Indexed;
import org.springframework.data.mongodb.core.mapping.Document;

import lombok.Data;
import lombok.NoArgsConstructor;

@Document
@Data @NoArgsConstructor

public class Job {
   
    private @Id String jobId;
    @Indexed
    private String userId;  // User.userId
    private Address address;
    private Contact contact;
    private String serviceType;  // value is ServiceType.typeId
    private LocalDateTime submitTime; // the time of a Quote sent out
    private String jobTitle;
    private String jobStatus; // draft,submit,reqSent,quotoRec,orderConfirmed
    private String jobDesc;
    private LocalDateTime updatedTime;
   
}