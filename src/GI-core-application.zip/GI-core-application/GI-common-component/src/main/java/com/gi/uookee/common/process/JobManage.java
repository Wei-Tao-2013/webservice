package com.gi.uookee.common.process;

import java.time.LocalDateTime;
import java.util.List;

import com.gi.uookee.common.model.Job;
import com.gi.uookee.common.model.Request;
import com.gi.uookee.common.model.Response;
import com.gi.uookee.common.model.Service;
import com.gi.uookee.common.repository.JobRepository;

import com.gi.uookee.common.utils.AppConsts;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

public class JobManage {
  private static final Logger logger = LoggerFactory.getLogger(ServiceManage.class);

  @Autowired
  JobRepository jobRepository;

  private List<Job> jobList;
  private LocalDateTime localDateTime = LocalDateTime.now();
  
  public Response createAJob(Request request){
    Job job = new Job();
    Response response = new Response();
    job = request.getJob();
    job.setSubmitTime(localDateTime);
    job.setJobStatus("JOBCREATED");
    jobRepository.save(job);
    response.setAppInfo("JOBCREATED");
    response.setAppStatus(AppConsts.RETURN_TRUE);
    return response;
  }

  public Response dropAJob(Request request){
    Job job = new Job();
    Response response = new Response();
    job = request.getJob();
    job.setUpdatedTime(localDateTime);
    job.setJobStatus("JOBCANCELED");
    jobRepository.save(job);
    response.setAppInfo("JOBCANCELED");
    response.setAppStatus(AppConsts.RETURN_TRUE);
    return response;

  }


  public Response updateAJob(Request request){
    Service service = new Service();
    Job job = new Job();
    Response response = new Response();
    job = request.getJob();
    jobRepository.save(job);
    response.setAppInfo("JOBUPDATED");
    response.setAppStatus(AppConsts.RETURN_TRUE);
    return response; 
  }


  public Response loadServicesByJob(Job job){

    Response response = new Response();
    response.setAppInfo("SERVICESLOADED");
    response.setAppStatus(AppConsts.RETURN_TRUE);
    //response.setServices(serviceRepository.findByUserId(userId));
    return response;

  }

  
}