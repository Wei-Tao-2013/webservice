package com.gi.uookee.common.account;

public interface AccountRegister{

    public String loginAccount(Account account);

    public String registerAccount();

    public String signOutAccount();
}