package com.gi.uookee.common.account;

public class WeiXinAccountRegister implements AccountRegister{

   public String loginAccount(Account account){
    
    return "success";
   }

   public String registerAccount(){

    return "success";
   }

   public String signOutAccount(){

    return "success";
   }
}