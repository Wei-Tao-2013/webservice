package com.gi.uookee.common.role;

import com.gi.uookee.common.model.Contact;

public abstract class Vendor{
 Contact contact;
 
}