package com.gi.uookee.common.role;

public interface Role{

    
}