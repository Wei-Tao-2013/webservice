package com.gi.uookee.common.model;

import lombok.Data;

@Data
public class ServiceType {

  private String typeId;
  private String typeName;

}