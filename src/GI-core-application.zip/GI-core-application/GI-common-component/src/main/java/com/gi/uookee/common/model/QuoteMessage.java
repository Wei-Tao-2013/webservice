package com.gi.uookee.common.model;

import java.time.LocalDateTime;



import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import org.springframework.data.mongodb.core.mapping.Document;

@Getter @Setter @NoArgsConstructor
@Document
public class QuoteMessage{
  
    private String  message;
    private String  messageSender; // service.serviceId or user.userId
    private LocalDateTime sendTime;
  
    public QuoteMessage(String message,String messageSender){
        LocalDateTime localDateTime = LocalDateTime.now();
        this.message = message;
        this.messageSender = messageSender;
        this.sendTime = localDateTime;
	}
    
}

