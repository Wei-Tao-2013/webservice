package com.gi.uookee.common.model;

import lombok.Data;

@Data
public class Contact{
 private String phoneNumber;
 private String mobilePhone;
 
}