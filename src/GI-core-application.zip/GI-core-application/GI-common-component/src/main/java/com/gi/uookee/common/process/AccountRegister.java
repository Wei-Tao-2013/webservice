package com.gi.uookee.common.process;

import java.util.List;
import com.gi.uookee.common.model.Request;
import com.gi.uookee.common.model.Response;
import com.gi.uookee.common.model.User;
import com.gi.uookee.common.repository.UserRepository;
import com.gi.uookee.common.utils.AppConsts;
import com.gi.uookee.common.utils.GIutils;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

public abstract class AccountRegister {

    private static final Logger logger = LoggerFactory.getLogger(AccountRegister.class);

    @Autowired
    UserRepository userRepository;

    public abstract Response register(Request request);
    public abstract Response signAccount(Request request);
    public abstract Response signOut(Request request);

    public Response profileUpdate(Request request){
        Response response = new Response(); 
        User requestUser = request.getUser();
        logger.debug("request {} ", GIutils.converToJson(request) );
        logger.debug("Useris {} ", GIutils.converToJson(requestUser)  );
        if (requestUser != null){

          logger.debug("User email address is {} ", requestUser.getPrimaryEmail());

          List<User> userList = userRepository.findByPrimaryEmail(requestUser.getPrimaryEmail());
          if(userList.isEmpty()){
            response.setAppCode(AppConsts.REG_USERNOTFOUND);
          }else{
            User existUser = (User)userList.get(0);
            requestUser.setUserId(existUser.getUserId());
            userRepository.save(requestUser);
            response.setAppCode(AppConsts.REG_USEUPDATED);
          }
        }else{
            response.setAppCode(AppConsts.REG_USERNOTFOUND);
        }
        request.setAppStatus(AppConsts.RETURN_TRUE);
        return response ;
    }

}