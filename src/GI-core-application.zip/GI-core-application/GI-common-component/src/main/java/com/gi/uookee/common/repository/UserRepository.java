package com.gi.uookee.common.repository;
import java.util.List;

import com.gi.uookee.common.model.User;
import org.springframework.data.mongodb.repository.MongoRepository;
public interface UserRepository extends MongoRepository<User, String>, UserRepositoryCustom {

    public List<User> findByPrimaryEmail(String primaryEmail); 
      
}