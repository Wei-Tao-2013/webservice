package com.gi.uookee.common.utils;

import java.io.Serializable;

public class AppConsts implements Serializable {
	/** For serialization. */
	private static final long serialVersionUID = 7452102852294401775L;

	/**System Exceptions**/
	public static final String ERROR__EXCETPION ="0999"; 

	/**Business errors**/
	public static final String ERROR_CODE_LoginIDNotFound="0090";
	
	/**Application Status Setting**/
	public static final String RETURN_TRUE="TRUE";
	public static final String RETURN_FALSE="FALSE";
	public static final String RETURN_UNKNOW="UNKNOW";
	
	//00 means register process 
	public static final String REG_REGISTERSUCESS="00-001";
	public static final String REG_USEREXIST="00-002";
	public static final String REG_ACCEXIST="00-003";
	public static final String REG_REGSTIERFAILED="00-004";
	public static final String REG_CCOUNTNOTFOUND="00-005";
	public static final String REG_SINGINSUCESS="00-006";
	public static final String REG_SINGOUT="00-007";
	public static final String REG_USERNOTFOUND="00-008";
	public static final String REG_USEUPDATED="00-009";
	//01 service register process

	public static final String SEV_DRAFTSUCESS="01-001";
	public static final String SEV_WAITFORAPPROVAL="01-002";
	
	//99 application level process
	public static final String APP_REFRESHTOKEN="01-001";

	/**Common explanation **/
	public static final String CALL_MESSAGE ="";
	
	/**status list**/
	public static final String REJECTED = "Rejected";
	public static final String COMPLETED = "Completed";

	public static enum accountType {WECHAT,APPACC,WEBACC,OTHERACC};
	//public static enum appStatus {TRUE,FALSE,UNKNOWN};
	public static enum accountStatus {CREATED,SIGNIN,SINGOUT,SUSPEND,BLOCKED,OTHERS};
	public static enum registerInfo {REGISTERSUCESS,USEREXIST,ACCEXIST,REGSTIERFAILED,ACCOUNTNOTFOUND,SINGINSUCESS,SINGOUT};
	public static enum userRole {CUSTOMER,VENDOR,GI_ADMIN}
	public static enum gender{MALE,FEMALE,UNKNOWN}
	
}