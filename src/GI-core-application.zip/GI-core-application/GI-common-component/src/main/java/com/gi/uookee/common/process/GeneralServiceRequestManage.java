package com.gi.uookee.common.process;

import com.gi.uookee.common.model.Request;
import com.gi.uookee.common.model.Response;

public class GeneralServiceRequestManage implements ServiceRequestManage {



 public Response acceptAServiceRequest(Request request){

    return null;
 }
   

 public Response acceptAServiceQuoto(Request request){

    return null;
 }


}