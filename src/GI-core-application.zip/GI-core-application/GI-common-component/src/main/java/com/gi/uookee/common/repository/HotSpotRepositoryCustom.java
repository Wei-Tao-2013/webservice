package com.gi.uookee.common.repository;

import java.util.List;

import com.gi.uookee.common.model.Service;

public interface HotSpotRepositoryCustom{
    public List<Service> loadHotSpotServicesByUser(String userId);
   
}