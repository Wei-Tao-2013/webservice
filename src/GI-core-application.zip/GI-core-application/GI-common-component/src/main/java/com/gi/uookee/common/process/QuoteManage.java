package com.gi.uookee.common.process;

import java.time.LocalDateTime;
import java.util.List;

import com.gi.uookee.common.model.Request;
import com.gi.uookee.common.model.Response;
import com.gi.uookee.common.model.Service;
import com.gi.uookee.common.repository.ServiceRepository;
import com.gi.uookee.common.utils.AppConsts;
import com.gi.uookee.common.utils.GIutils;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

public abstract class QuoteManage {
  private static final Logger logger = LoggerFactory.getLogger(ServiceManage.class);

  private ServiceRequestManage serviceRequestManage;
  
  @Autowired
  ServiceRepository serviceRepository;

  private List<Service> serviceList;
  
  public  abstract Response testFunction();
  
  private LocalDateTime localDateTime = LocalDateTime.now();
  
  public Response draftAService(Request request){
    Service service = new Service();
    Response response = new Response();
    service = request.getService();
    
    service.setStatus("DRAFT");
    service.setUpdatedTime(localDateTime);
    serviceRepository.save(service);

    response.setAppInfo("DRAFT");
    response.setAppStatus(AppConsts.RETURN_TRUE);
    return response;

  }

  public Response loadServices(String userId){

    Response response = new Response();
    response.setAppInfo("SERVICESLOADED");
    response.setAppStatus(AppConsts.RETURN_TRUE);
    response.setServices(serviceRepository.findByUserId(userId));
    return response;

  }

  public Response registerAService(Request request){
    
    Service service = new Service();
    Response response = new Response();
    service = request.getService(); 
    service.setUpdatedTime(localDateTime);
    service.setStatus("FORAPPROVAL");  // waitting for approval
    serviceRepository.save(service);
    /*
    //this.loadServices(request.getService().getUserId());
    //List<Service> aService = this.serviceList.stream().filter(sers->sers.getServiceCode().equalsIgnoreCase(serviceCode)).collect(Collectors.toList());
    if (aService.isEmpty()){
      serviceRepository.save(service);
    }else{
      // update existing service 
      Service existService = (Service)aService.get(0);
      logger.debug("existService" + GIutils.converToJson(existService));
      if (existService.getStatus().equalsIgnoreCase("DRAFT")){
        service.setServiceId(existService.getServiceId());
        serviceRepository.save(service);
      }else{
        response.setAppInfo("EXISTNOTDRAFT"); // the service has been in process can't be updated at this stage
        response.setAppInfo(AppConsts.RETURN_TRUE);
      }
    }
    */
    response.setAppInfo("FORAPPROVAL");
    response.setAppStatus(AppConsts.RETURN_TRUE);
    return response; 
  }


  public Response approvalAService(Request request){

    return null;
  }

  Response rejectAService(Request request){

    return null;
  }

  Response blockAService(Request request){

    return null;
  }

   
  Response acceptAServiceRequest(Request request){

   return  serviceRequestManage.acceptAServiceRequest(request);
  }

  Response acceptAServiceQuoto(Request request){

    return  serviceRequestManage.acceptAServiceQuoto(request);
  }
  
}