package com.gi.uookee.common.repository;

import java.util.List;

import com.gi.uookee.common.model.Account;
import com.gi.uookee.common.model.User;
public interface UserRepositoryCustom{

    public List<User> findByNestedAccountId(String accountId);
    public void updateNestedAccount(Account account);
}