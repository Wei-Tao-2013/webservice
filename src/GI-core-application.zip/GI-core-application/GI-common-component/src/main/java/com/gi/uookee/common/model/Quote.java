package com.gi.uookee.common.model;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.index.Indexed;
import org.springframework.data.mongodb.core.mapping.Document;

import lombok.Data;
import lombok.NoArgsConstructor;

@Document
@Data @NoArgsConstructor

public class Quote {
   
    private @Id String QuoteId;
    @Indexed
    private String userId;  // User.userId
    @Indexed
    private String serviceId; // Service.serviceId
    @Indexed
    private String jobId;// Job.jobId;
    private String serviceType;  // value is ServiceType.typeId
    private LocalDateTime reqTime;
    private LocalDateTime quoTime;
    private LocalDateTime expiredTime;
    private String quoteStatus; // requestSent, quoteReceived,expired
    private List<QuoteMessage> message = new ArrayList<QuoteMessage>(); 

    public Quote addMessage(QuoteMessage message) {
        this.message.add(message);
        return this;
    }
   
}