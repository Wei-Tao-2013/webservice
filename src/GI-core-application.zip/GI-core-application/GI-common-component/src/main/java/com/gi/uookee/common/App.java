package com.gi.uookee.common;

public class App 
{
    public static void main( String[] args )
    {
       
    }
}
