package com.gi.uookee.common.model;

import java.util.List;

import lombok.Data;

@Data
public class Request implements java.io.Serializable {
   /** For serialization. */	
    private static final long serialVersionUID = -8980734683931860246L;	
	private String appErr;
	private String appInfo;
	private String appStatus;
	private String referralId;
	private String referralType; // vendorType or service
	private String tokenSeed;
	///user info
	private User user;
	/// account info
	private Account account;
    ////wechat info
	private String weixinCode;
	private String rawData;
	private RawData rawDataobj;
	private String encryptedData; 
	private String signature;
	private String iv;
	// Service info
	private String  serviceId;
	private Service service;
	private String userId;
	private String serviceStatus; 
	private String fileId;

	// Job info
	private Job job;
	// hotspot
	private List<String> serviceIdList;
  
}