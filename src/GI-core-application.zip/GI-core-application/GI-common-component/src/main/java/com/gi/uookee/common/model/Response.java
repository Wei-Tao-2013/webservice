package com.gi.uookee.common.model;

import java.util.List;

import lombok.Data;

@Data
public class Response implements java.io.Serializable {

	/** For serialization. */
    private static final long serialVersionUID = -8980734683931860246L;
    private String appErr;
	private String appInfo;
	private String appStatus;
    
	private String appCode;
	private User user;
	private Account account;
	private List<Service> services;
	private String token;
	private String serviceId;
	//for file upload response
	private UploadFileResponse uploadFileResponse;
	private List<Photo>  photoList ;
	private List<String>  FileIdList ;
	private String fileId;

	// for hotSpot
	private List<HotSpot> hotSpotList;
}