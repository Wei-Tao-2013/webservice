package com.gi.uookee.common.process;

import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;

import com.gi.uookee.common.model.Photo;
import com.gi.uookee.common.model.Request;
import com.gi.uookee.common.model.Response;
import com.gi.uookee.common.model.Service;
import com.gi.uookee.common.repository.ServiceRepository;
import com.gi.uookee.common.utils.AppConsts;
import com.gi.uookee.common.utils.GIutils;

import org.bson.types.Binary;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;

public abstract class ServiceManage {
  private static final Logger logger = LoggerFactory.getLogger(ServiceManage.class);

  private ServiceRequestManage serviceRequestManage;
  
  @Autowired
  ServiceRepository serviceRepository;
 
  @Autowired @Qualifier("fileStore")
  FileStore fileStore;

  private LocalDateTime localDateTime = LocalDateTime.now();
  
  public Response draftAService(Request request){
    Service service = new Service();
    Response response = new Response();

    service = request.getService();
    String serviceId = service.getServiceId();
    Service existService = serviceRepository.findByServiceId(serviceId);
   
    if (existService !=null) {
      List<Photo> photoList = existService.getServicePhoto();
      GIutils.copyProperties(service, existService);

      existService.setServicePhoto(photoList);
      existService.setStatus("DRAFT");
      existService.setUpdatedTime(localDateTime);
      logger.debug("draft existService is "+ GIutils.converToJson(existService));
      serviceRepository.save(existService);    
      serviceId = existService.getServiceId();
    }else{
      service.setStatus("DRAFT");
      service.setUpdatedTime(localDateTime);
      serviceRepository.save(service);
      serviceId= service.getServiceId();
    }

    response.setAppInfo("DRAFT");
    response.setAppStatus(AppConsts.RETURN_TRUE);
    response.setServiceId(serviceId);
    return response;
  }

  public Response loadServices(String userId, String serviceStatus){
    Response response = new Response();
    response.setAppInfo("SERVICESLOADED");
    response.setAppStatus(AppConsts.RETURN_TRUE);
    if ("ALL".equalsIgnoreCase(serviceStatus)){
      response.setServices(serviceRepository.findByUserId(userId));
    }else {
      response.setServices(serviceRepository.findByUserId(userId)
      .stream()
      .filter(o->o.getStatus().equalsIgnoreCase(serviceStatus))
      .collect((Collectors.toList())));
    }
    
    return response;
  }

  public Response registerAService(Request request){
    
    Service service = new Service();
    Response response = new Response();
    service = request.getService(); 
    String serviceId = service.getServiceId();

    Service existService = serviceRepository.findByServiceId(serviceId);
    if (existService !=null) {
      List<Photo> photoList = existService.getServicePhoto();
      GIutils.copyProperties(service, existService);
      existService.setServicePhoto(photoList);
      
      existService.setStatus("FORAPPROVAL");
      existService.setUpdatedTime(localDateTime);
      logger.debug("for approval  existService is "+ GIutils.converToJson(existService));
      serviceRepository.save(existService);    
      serviceId = existService.getServiceId();
    }else{
      service.setStatus("FORAPPROVAL");
      service.setUpdatedTime(localDateTime);
      serviceRepository.save(service);
      serviceId= service.getServiceId();
    }

    response.setServiceId(serviceId);
    /*
    //this.loadServices(request.getService().getUserId());
    //List<Service> aService = this.serviceList.stream().filter(sers->sers.getServiceCode().equalsIgnoreCase(serviceCode)).collect(Collectors.toList());
    if (aService.isEmpty()){
      serviceRepository.save(service);
    }else{
      // update existing service 
      Service existService = (Service)aService.get(0);
      logger.debug("existService" + GIutils.converToJson(existService));
      if (existService.getStatus().equalsIgnoreCase("DRAFT")){
        service.setServiceId(existService.getServiceId());
        serviceRepository.save(service);
      }else{
        response.setAppInfo("EXISTNOTDRAFT"); // the service has been in process can't be updated at this stage
        response.setAppInfo(AppConsts.RETURN_TRUE);
      }
    }
    */
    response.setAppInfo("FORAPPROVAL");
    response.setAppStatus(AppConsts.RETURN_TRUE);
    return response; 
  }


  public abstract Response storeImage(Request request, String fileName, Binary data);

  public abstract Response getImages(String serviceId);

  public abstract void deleteImage(String fileId);

  public Response approvalAService(Request request){
    return null;
  }

  Response rejectAService(Request request){
    return null;
  }

  Response blockAService(Request request){
    return null;
  }
   
  Response acceptAServiceRequest(Request request){
   return  serviceRequestManage.acceptAServiceRequest(request);
  }

  Response acceptAServiceQuoto(Request request){
    return  serviceRequestManage.acceptAServiceQuoto(request);
  }


  
}