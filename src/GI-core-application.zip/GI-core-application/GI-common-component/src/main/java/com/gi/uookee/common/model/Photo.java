package com.gi.uookee.common.model;

import java.io.File;
import java.time.LocalDateTime;

import org.bson.types.Binary;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.index.Indexed;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data  @NoArgsConstructor
public class Photo{
   @Id
   private String  photoId;
   private String photoUrl;
   private String photoName;
   private LocalDateTime  uploadTime;
   private LocalDateTime  updateTime;
   
   private Binary fileData;
   private String status; // disabled, available 
   @Indexed
   private String fileId;  // FileData.fileId
}