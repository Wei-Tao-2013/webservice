package com.gi.uookee.common.repository;

public interface ServiceRepositoryCustom{
    public void deleteNestedPhoto(String fileId);
}