package com.gi.uookee.common.process;

import com.gi.uookee.common.model.Request;
import com.gi.uookee.common.model.Response;

public interface ServiceRequestManage {

    /* response a quoto to the request*/
    public Response acceptAServiceRequest(Request request);
   
    /* generate a order to the request*/
    public Response acceptAServiceQuoto(Request request);

}