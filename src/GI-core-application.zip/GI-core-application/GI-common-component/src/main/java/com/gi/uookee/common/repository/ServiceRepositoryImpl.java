package com.gi.uookee.common.repository;

import java.util.List;
import com.gi.uookee.common.model.Account;
import com.gi.uookee.common.model.Photo;
import com.gi.uookee.common.model.Service;
import com.gi.uookee.common.model.User;
import com.mongodb.BasicDBObject;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;

public class ServiceRepositoryImpl implements ServiceRepositoryCustom{
   
  private static final Logger logger = LoggerFactory.getLogger(ServiceRepositoryImpl.class);

  @Autowired
  private MongoTemplate mongoTemplate;

  @Override
  public void deleteNestedPhoto(String fileId){
      Query query = Query.query(Criteria
          .where("servicePhoto")
          .elemMatch(
          Criteria.where("fileId").is(fileId)
        )
      );
      Update update = 
        new Update().pull("servicePhoto", 
        new BasicDBObject("fileId", fileId));
      mongoTemplate.updateMulti(query, update, Service.class);
  }
 
} 