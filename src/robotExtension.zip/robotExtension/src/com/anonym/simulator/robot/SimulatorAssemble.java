package com.anonym.simulator.robot;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.Optional;
import com.anonym.simulator.robot.exception.SimulatorException;
import com.anonym.simulator.robot.simulator.FacingDirection;
import com.anonym.simulator.robot.simulator.Matrix;
import com.anonym.simulator.robot.simulator.Location;
import com.anonym.simulator.robot.simulator.Robot;
import com.anonym.simulator.robot.SimulatorConstants.robotCommand;


public class SimulatorAssemble {

    private Matrix playTable;
    private Robot robot;
    private  robotCommand command;

    private Map<String,Robot> robotMap = new HashMap<String,Robot>();
  
    public SimulatorAssemble(Matrix playTable, Robot robot) {
        this.playTable = playTable;
        this.robot = robot;
        //this.robotList.add(robot);
    }


   

    
	/**
	 * Read txt file from resources
	 *
	 * @param input command string
	 * @throws com.anonym.simulator.robot.exception.SimulatorException
	 *
	 */
   public String readCommandFile(String input) throws SimulatorException {
		String[] inputArray = input.split(" ");
		String result ="";
		if (inputArray.length < 2) { //Invalid command name for reading file, use READ <filename.txt>
			throw new SimulatorException(SimulatorConstants.ERROR_INVALID_READ_COMMAND); 		
		} else {
			try {
				String fileName = inputArray[1];
				String[] fileNameAr = fileName.split("\\.");
				String fileType = fileNameAr.length == 2 ? fileNameAr[1] : "";

				if (!"txt".equals(fileType)) { //Not support file type, only support txt file.
					throw new SimulatorException(SimulatorConstants.ERROR_UNSUPPORT_FILE);
				} else {
					StringBuffer commandSetStr = readFile(fileName);
					if (commandSetStr.toString().length() == 0) { //empty files.
						throw new SimulatorException(SimulatorConstants.ERROR_EMETYP_FILE);
					
					} else {
						result = commandSetStr.toString();
					}
				}

			} catch (NullPointerException | IOException Ex) { // can't find a file
				throw new SimulatorException(SimulatorConstants.ERROR_FILE_NOT_FOUND);
			}
			return result;
		}		
    }
   
   /**
	 * Read txt file from resources provide App client for message printing out
	 *
	 * @param input command string
	 */
   
   public String callReadCommandFile(String inputString){
	   String result ="";
	   try {
         result = readCommandFile(inputString);
       } catch (SimulatorException e) {
           System.out.println(SimulatorConstants.SIMULATOR_INFO_OUTPOUT +  e.getMessage());
       }
	   return result;
   }
    
   /**
  	 * Take an action as per string command provide App client for message printing out
  	 *
  	 * @param input command string
  	 */
	public void callSimulator(String command) {
	   try {
           String outputVal = takeAction(command);
           if(outputVal != null && outputVal.length()>0)
           	System.out.println(SimulatorConstants.SIMULATOR_INFO_OUTPOUT  + outputVal);	      
       } catch (SimulatorException e) {
           System.out.println(SimulatorConstants.SIMULATOR_INFO_OUTPOUT + e.getMessage());
       }		   
	}
    
    /**
     * Take an action as per string command.
     *
     * @param inputString command string
     * @return string value of the executed command
     * @throws com.anonym.simulator.robot.exception.SimulatorException
     *
     */
    public String takeAction(String inputString) throws SimulatorException  {
    	if (inputString.trim().length() ==0) return ">"; 
    
    	String[] args = inputString.split(" ");
    
    	try {
        	command = robotCommand.valueOf(args[0].toUpperCase());
        } catch (IllegalArgumentException e) {
            throw new SimulatorException(SimulatorConstants.ERROR_INVALID_COMMAND + " "+ args[0]);
        }
   
        if (command == robotCommand.PLACE && args.length != 2) {
            throw new SimulatorException(SimulatorConstants.ERROR_INVALID_COMMAND + " "+args[0]);
        }
        
        return this.moveSimulator(args);
    }
    

    /**
     * Places the robot on the play table with position and facing NORTH, SOUTH, EAST or WEST
     *
     * @param Location Robot location
     * @return true if placed successfully
     * @throws SimulatorException
     */
    private boolean setRobotLocation(Location location) throws SimulatorException {
        // validate the position
        if (!playTable.isInMatrix(location) || playTable.isOcuupied(this.robotMap, location))
            return false;
        // set validate location to the robot
        robot.setLocation(location);
        return true;
    }
     
    
    /**
     * Read command list from a file 
     * 
     * @param String file name
     * @return StringBuffer as output of file
     * @throws IOException
     */
    private  StringBuffer readFile(String fileName) throws IOException {
    	StringBuffer stringBuffer = new StringBuffer();
		InputStream inputStream = this.getClass().getClassLoader()
				.getResourceAsStream(fileName);
		BufferedReader r = new BufferedReader(new InputStreamReader(inputStream));
		StringBuilder stringBuilder = new StringBuilder();
		String line;
		String assembleString = null;
	
		while ((line = r.readLine()) != null) {
			stringBuilder.append(line).append(";");
		}
		
		assembleString = stringBuilder.toString();
	
		return stringBuffer.append(assembleString);
	 }
   
    /**
     * Actions of robot on play table with command of PLACE MOVE RIGHT LEFT REPROT
     * 
     * @param String[]  Commands
     * @return String Command results information
     * @throws SimulatorException
     */
    private String moveSimulator(String[] args) throws SimulatorException  {
        // validate PLACE params
        String[] params;
        int x = 0;
        int y = 0;
      //  String robotName ="";
        FacingDirection commandDirection = null;
        if (command == robotCommand.PLACE) {
            params = args[1].split(",");
            try {
                x = Integer.parseInt(params[0]);
                y = Integer.parseInt(params[1]);
                
                commandDirection = FacingDirection.valueOf(params[2].toUpperCase());
                if (params.length ==4  && String.valueOf(params[3]).trim() !=""){
                    this.robot.setRobotName(String.valueOf(params[3]).trim()) ;
                }else {
                	
                    this.robot.setRobotName("Robot_"+ this.robotMap.size());
                }
                

            } catch (Exception e) {
            	// Invalid command with x,y of location."
                throw new SimulatorException(SimulatorConstants.ERROR_INVALID_FORMAT_LOC); 
            }

        }

        String result ="";
        if  (robot.getLocation() == null && command != robotCommand.PLACE){ 
        	//Set location for robot first with command PLACE X,Y,NORTH|EAST|WEST|SOUTH.
        	 throw new SimulatorException(SimulatorConstants.ERROR_NOT_INIT_LOC); 
        }
      
        switch (command) {
            case PLACE:
            	setRobotLocation(new Location(x, y, commandDirection));
                break;
            case MOVE:
                Location newLoc = robot.getLocation().getNewLocation();
                if (playTable.isInMatrix(newLoc) &&  !playTable.isOcuupied(this.robotMap, newLoc))
                	robot.move();
                break;
            case LEFT:
            	robot.trunLeft();
                break;
            case RIGHT:
            	robot.trunRight();
                break;
            case REPORT:
            	result = report();
                break;
            case MAP:
                 result = map();
                 break;
            default:
                throw new SimulatorException(SimulatorConstants.ERROR_INVALID_COMMAND);
        }
        
        Robot newRobot = new Robot();
    	newRobot.setLocation(this.robot.getLocation());
    
        this.robotMap.put(robot.getRobotName(),newRobot);
    
        
        return result;
    }

    /**
     * Report info for the robot of  X,Y and Facing direction 
     */
    private String report() {
        if (robot.getLocation()== null)
            return "";
        return  robot.getRobotName()+" is located : "+robot.getLocation().getX() + "," + robot.getLocation().getY() + "," + robot.getLocation().getFacing().toString();
    }

    private String map() {

        return playTable.drawMatrix(this.robotMap);


    }


	
}
