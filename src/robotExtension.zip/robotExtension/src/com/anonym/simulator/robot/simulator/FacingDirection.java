package com.anonym.simulator.robot.simulator;

import java.util.HashMap;
import java.util.Map;

public enum FacingDirection {

	NORTH(0), EAST(1), SOUTH(2), WEST(3);

	private static Map<Integer, FacingDirection> mapDirection = new HashMap<Integer, FacingDirection>();
	
	private static FacingDirection valueOf(int facingDirectionIndex) {
		return mapDirection.get(facingDirectionIndex);
	}

	static {
    	for (FacingDirection facingDirection : FacingDirection.values()) {
    		mapDirection.put(facingDirection.directionIndex, facingDirection);
		}
	}

	private int directionIndex;

	private FacingDirection(int direction) {
		this.directionIndex = direction;
	}
	
	/**
	 * Returns turning left of the current facing
	 */
	public FacingDirection leftDirection() {
		return trunDireticon(-1);
	}

	/**
	 * Returns turning right of the current facing
	 */
	public FacingDirection rightDirection() {
		return trunDireticon(1);
	}

	private FacingDirection trunDireticon(int step) {
		int index = 0;

		if ((this.directionIndex + step) < 0) {
			index = mapDirection.size() - 1;
		} else {
			index = (this.directionIndex + step) % mapDirection.size();
		}

		return FacingDirection.valueOf(index);
	}

}
