package com.anonym.simulator.robot;

import java.io.IOException;
import java.util.Arrays;
import java.util.List;
import java.util.Scanner;

import com.anonym.simulator.robot.exception.SimulatorException;
import com.anonym.simulator.robot.simulator.Matrix;
import com.anonym.simulator.robot.simulator.Robot;

/**
 * entry point of robot simulator
 *
 */
public class RobotApp {

	private static final String EXIT_COMMAND = "EXIT";
	
	public static void main(String[] args) throws IOException, SimulatorException {
		
		Scanner br = new Scanner(System.in);
		
		//print out application info at the beginning.
		System.out.println("");
		System.out.println("*************************************");
		System.out.println("*                                   *");
		System.out.println("*      The Toy Robot Simulator      *");
		System.out.println("*                                   *");
		System.out.println("*************************************");
		System.out.println("");
		
		System.out.println("Tell the Robot your first command");
		System.out.println("Start with placing the Robot on the palytable - PLACE X, Y, FACING or ");
		System.out.println("You can read existing file with Command as \'READ simulator-commands.txt\'."); 
		System.out.println("The Robot can read in commands of the following form (case insensitive): ");
		System.out.println("\'PLACE X,Y,NORTH|SOUTH|EAST|WEST\', MOVE, LEFT, RIGHT, REPORT , or READ <fileName.txt> ");
		System.out.println("\'"+ EXIT_COMMAND + "\' to exit.");
		System.out.println("");

	    //Set up simulator for App assembly.
		Matrix playTable = new Matrix(4, 4);
		Robot robot = new Robot();
		SimulatorAssemble simulator = new SimulatorAssemble(playTable, robot);
		
		while (true) {
			
			System.out.print(">");
			String input = br.nextLine();
			
			//Exit from command line application
			if (input.length() == EXIT_COMMAND.length()
				&& input.toUpperCase().equals(EXIT_COMMAND)) {
				System.out.println(SimulatorConstants.SIMULATOR_INFO_OUTPOUT + "Exiting...Bye!!!");
				br.close();
				System.exit(1);
			}
			
			// Response from command line from command or txt file
			if (input.toUpperCase().indexOf("READ") == 0 ){
				System.out.println("------------------Start to read file-----------");
			    // read commands from a file
    			String result = simulator.callReadCommandFile(input);
    			if (!(result ==null || result.length() == 0 )){
	        		String[] arrayStrSource = result.toString().split(";");
		    		List<String> listSource = Arrays.asList(arrayStrSource);
					
	        		listSource.forEach(item -> {
						System.out.println(">" + item);
						simulator.callSimulator(item);
					});
    			}else{
    				//system reminder
    				System.out.println(SimulatorConstants.SIMULATOR_INFO_OUTPOUT + "Here is a sample file can be used, please type \'read simulator-commands.txt\'");
    			}
				}else{
					// read commands from command line
				
				
        			simulator.callSimulator(input) ;  
        	}
    
		}
		
	  }
	
}
