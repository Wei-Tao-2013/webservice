package com.anonym.simulator.robot.simulator;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class Matrix {
	
	private int x;
	private int y;
	
	public Matrix(int x, int y) {
	    this.x = x;
	    this.y = y;
	}
	
	/**
	 * validate if robot is on the table
	 * @return true /false
	 */
	public boolean isInMatrix(Location location) {
			
	    return !(location.getX() > this.x || location.getX() < 0 || location.getY() > this.y || location.getY() < 0 );
	}
	
	public boolean isOcuupied(Map<String,Robot> hashRobot,Location location) {
		
		List<Robot> result = hashRobot.values().stream().filter(robot->robot.getLocation().getX() == location.getX() && robot.getLocation().getY() == location.getY()).collect(Collectors.toList());		
		
		
		return !result.isEmpty();
	}

	public String drawMatrix(Map<String,Robot> hashRobot){
	  StringBuilder strBuilder = new StringBuilder();
	  strBuilder.append("\n");
	  List<Integer> xList = new ArrayList<Integer>();
	  List<Integer> yList = new ArrayList<Integer>();
	  
	  strBuilder.append(hashRobot.toString());
	  strBuilder.append("\n");
	
	  strBuilder.append("\n");
	  for (int i = 0; i < this.x+1; i++)
		 xList.add(i);

	  for (int j = this.y; j>-1; j--)
		  yList.add(j);
	  
	   xList.stream().forEach(xItem->strBuilder.append("   "+xItem));
	   strBuilder.append("\n");
    
	   yList.stream().forEach(yItem->{
	   strBuilder.append(yItem+" ");
			  xList.stream().forEach(
				  xItem->{
        			 int strLen = strBuilder.length();
        			 
        			 boolean noRobot = hashRobot.values().stream().filter(robot->robot.getLocation().getX() == xItem.intValue() && robot.getLocation().getY() == yItem.intValue()).collect(Collectors.toList()).isEmpty();
					
        			  if (noRobot) {
        				  strBuilder.append("[ ] ");  
        			  }else {
        					strBuilder.append("[*] ");
        				  
        			  }
        		/*	 hashRobot.forEach((k,v)->{
                         if ( v.getLocation().getX() == xItem.intValue() && v.getLocation().getY() == yItem.intValue()){

							strBuilder.append("[*] ");
						 }
                        
					 });
					 if (strLen ==strBuilder.length())
					    strBuilder.append("[ ] ");*/
					
					});
			  strBuilder.append("\n");
			}
	   );
	  
	  return strBuilder.toString();

	}

}
