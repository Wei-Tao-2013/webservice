package com.anonym.simulator.robot.simulator;

import com.anonym.simulator.robot.exception.SimulatorException;

public class Robot {

	private Location location;
	private String robotName;

	public Robot() {
	}

	public Robot(Location location) {
		this.location = location;
	}

	/**
	 * Set the robot location
	 * @return true /false
	 */
	public boolean setLocation(Location location) {
		if (location == null)
			return false;

		this.location = location;
		return true;
	}

	/**
	 * Move the robot one step
	 * @return true /false
	 */
	public boolean move() throws SimulatorException {
		 if (location.getNewLocation() == null)
	            return false;
	        this.location = location.getNewLocation();
	        return true;
	
	}
	
	public Location getLocation() {
		return this.location;
	}

	/**
	 * Turn the robot to LEFT
	 * @return true
	 */
	public boolean trunLeft() {
		 if (this.location.getFacing() == null)
	          return false;
	        this.location.setFacing(this.location.getFacing().leftDirection());
	        return true;
	}

	/**
	 * Turn the robot to RIGHT
	 * @return true
	 */
	public boolean trunRight() {
		 if (this.location.getFacing() == null)
	          return false;
	        this.location.setFacing(this.location.getFacing().rightDirection());
	        return true;
	}

	/**
	 * @return the robotName
	 */
	public String getRobotName() {
		return robotName;
	}

	/**
	 * @param robotName the robotName to set
	 */
	public void setRobotName(String robotName) {
		this.robotName = robotName;
	}

	public String getRobotRandomName(){

		return "randomName";
	}

}
