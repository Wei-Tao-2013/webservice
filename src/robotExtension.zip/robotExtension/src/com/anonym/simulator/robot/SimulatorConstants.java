package com.anonym.simulator.robot;

import java.io.Serializable;

public class SimulatorConstants implements Serializable {
	
	/** For serialization. */
	private static final long serialVersionUID = -7394564440527179215L;
	
	public static enum robotCommand {PLACE,MOVE,LEFT,RIGHT,REPORT,READ,MAP};
	
	public static final String SIMULATOR_INFO_OUTPOUT = "[Simulator App Info]>>> ";
	
	// read file message
	public static final String ERROR_INVALID_READ_COMMAND ="Invalid command name for reading file, use READ <filename.txt>."; 
	public static final String ERROR_UNSUPPORT_FILE = "Not support file type, only support txt file.";	
	public static final String ERROR_EMETYP_FILE = "Empty files.";
	public static final String ERROR_FILE_NOT_FOUND = "Can't find txt file name.";
	
	//read command line
	public static final String ERROR_INVALID_COMMAND =  "Invalid command";
	public static final String ERROR_INVALID_FORMAT_LOC = "Invalid command with x,y of location.";
	public static final String ERROR_NOT_INIT_LOC= "Set location for robot first with command PLACE X,Y,NORTH|EAST|WEST|SOUTH.";
	
	//
	public static final String ERROR_ROBOT_NOT_INIT = "Robot direction has not been initialized.";
	
	
	
}
