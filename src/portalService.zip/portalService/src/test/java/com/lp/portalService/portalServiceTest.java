package com.lp.portalService;

import static org.junit.Assert.assertEquals;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.HashMap;
import java.util.Iterator;

import org.apache.commons.httpclient.HttpClient;
import org.apache.commons.httpclient.methods.PostMethod;
import org.apache.commons.httpclient.methods.StringRequestEntity;
import org.apache.commons.lang.StringUtils;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.junit.Before;
import org.junit.Ignore;
import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.Assert;
import org.springframework.context.ApplicationContext;

public class portalServiceTest {
	ApplicationContext appContext;
	StringBuffer checkEmailJsonStr = null;
	StringBuffer checkCustomerNumberJsonStr = null;
	StringBuffer checkWorkEmailJsonStr = null;
	StringBuffer checkRegisterCustomerJsonStr = null;
	StringBuffer checkinitialiseUserJsonStr = null;
	StringBuffer checkVerifyinitialiseUserJsonStr = null;
	JSONObject jsonObject =null;

	private final String DOMAIN_URL = "https://portaldva.leaseplan.com.au"; // http://lpausap1003.ap.leaseplancorp.net:58000
	private final String CHECK_EMAIL = DOMAIN_URL
			+ "/portalService/checkEmail/";
	private final String CHECK_CUSTOMER_NUMBER = DOMAIN_URL
			+ "/portalService/checkCustomerNumber/";
	private final String VALIDATE_WORK_EMAIL = DOMAIN_URL
			+ "/portalService/validateWorkEmail/";
	private final String REGISTER_CUSTOMER = DOMAIN_URL
			+ "/portalService/registerCustomer/";
	private final String INITIALISE_USER = DOMAIN_URL
			+ "/portalService/initialiseUser/";
	private final String VERIFY_INITIAL_USER = DOMAIN_URL
			+ "/portalService/verifyInitialUser/";

	@Before
	public void setUp() throws Exception {
		checkEmailJsonStr = assembleJsonObject("checkEmail.json");
		checkCustomerNumberJsonStr = assembleJsonObject("checkCustomerNumber.json");
		checkWorkEmailJsonStr = assembleJsonObject("validateWorkEmail.json");
		checkRegisterCustomerJsonStr = assembleJsonObject("registerCustomer.json");
		checkinitialiseUserJsonStr = assembleJsonObject("initialiseUser.json");
		checkVerifyinitialiseUserJsonStr = assembleJsonObject("verifyInitialUser.json");
		jsonObject =  new JSONObject(checkinitialiseUserJsonStr.toString());
	}
	

	public void testDemo() {
		System.out.println(checkinitialiseUserJsonStr.toString());
		
		try {
			
		//	jsonObject =  new JSONObject(checkinitialiseUserJsonStr.toString());

			JSONArray initialiseUser = (JSONArray) jsonObject
					.get("initialiseUser");
			Iterator<Object> iteratorinitialiseUsers = initialiseUser
					.iterator();
			while (iteratorinitialiseUsers.hasNext()) {
				JSONObject next = (JSONObject) iteratorinitialiseUsers.next();
				System.out.println("object string is " + next.toString());

			}
		} catch (Exception e) {

		}

	}

    
	public void testInitialiseUser() {
		System.out.println("starting test initialiseUser....");
		HttpClient httpClient = new HttpClient();
		try {
			JSONArray initialiseUser = (JSONArray) jsonObject
					.get("initialiseUsers");
			Iterator<Object> iteratorinitialiseUsers = initialiseUser
					.iterator();
			try {
				while (iteratorinitialiseUsers.hasNext()) {
					JSONObject next = (JSONObject) iteratorinitialiseUsers.next();
					
				StringRequestEntity stringEntity = new StringRequestEntity(
						next.toString(), "application/json", "UTF-8");
				PostMethod postMethod = new PostMethod(INITIALISE_USER);
				postMethod.setRequestEntity(stringEntity);
				int status = httpClient.executeMethod(postMethod);
				HashMap<String, String> map = this.buildHashMap(postMethod);
				System.out.println("-->" + map.get("returnCRM"));
				postMethod.releaseConnection();
				assertEquals("testInitialiseUser", 200, status);
				assertEquals("testInitialiseUser", "true", map.get("returnCRM"));
				assertEquals("testInitialiseUser", "created", map.get("returnUME"));
				assertEquals("testInitialiseUser", "Validation email sent", map.get("errReason"));
				}
			} catch (IllegalStateException ex) {
				ex.printStackTrace();
			} catch (IOException e) {
				e.printStackTrace();
			}
		} catch (JSONException e) {
			e.printStackTrace();
		} finally {
			httpClient = null;
		}
		
	}
  
	/**
	 * test case for failing to verification of initial user
	 */
	//@Test
	public void testVerifyInitialUser() {
		System.out.println("starting test verifyInitialiseUser....................................................................................");
		HttpClient httpClient = new HttpClient();
		try {
			JSONArray verifyInitialUser = (JSONArray) jsonObject
					.get("verifyInitialUsers");
			Iterator<Object> iteratorVerifyInitialUser = verifyInitialUser
					.iterator();
			try {
				while (iteratorVerifyInitialUser.hasNext()) {
					JSONObject next = (JSONObject) iteratorVerifyInitialUser.next();
				StringRequestEntity stringEntity = new StringRequestEntity(
						next.toString(), "application/json", "UTF-8");
				PostMethod postMethod = new PostMethod(VERIFY_INITIAL_USER);
				postMethod.setRequestEntity(stringEntity);
				int status = httpClient.executeMethod(postMethod);
				HashMap<String, String> map = this.buildHashMap(postMethod);
				postMethod.releaseConnection();
				assertEquals("testVerifyInitialUser", "false", map.get("returnCRM"));
				assertEquals("testVerifyInitialUser", 200, status);
				}
			} catch (IllegalStateException ex) {
				ex.printStackTrace();
			} catch (IOException e) {
				e.printStackTrace();
			}
		} catch (JSONException e) {
			e.printStackTrace();
		} finally {
			httpClient = null;
		}
	}

  //  @Test
	public void testCheckEmail() {
		// System.out.println(checkEmailJsonStr);
    	System.out.println("starting test testCheckEmail.............................................................................");
		HttpClient httpClient = new HttpClient();
		
		try {
			JSONArray verifyCheckEmails = (JSONArray) jsonObject
					.get("checkEmails");
			Iterator<Object> iteratorVerifyCheckEmails = verifyCheckEmails
					.iterator();
			try {
				while (iteratorVerifyCheckEmails.hasNext()) {
					JSONObject next = (JSONObject) iteratorVerifyCheckEmails.next();
				
				StringRequestEntity stringEntity = new StringRequestEntity(
						next.toString(), "application/json", "UTF-8");
				PostMethod postMethod = new PostMethod(CHECK_EMAIL);
				postMethod.setRequestEntity(stringEntity);
				int status = httpClient.executeMethod(postMethod);
				HashMap<String, String> map = this.buildHashMap(postMethod);
				// System.out.println("-->" + map.get("returnCRM"));
				postMethod.releaseConnection();
				
				assertEquals("testCheckEmail", "0", map.get("errCode"));
				assertEquals("testCheckEmail", "true", map.get("returnCRM"));
				assertEquals("testCheckEmail", 200, status);
				}
			} catch (IllegalStateException ex) {
				ex.printStackTrace();
			} catch (IOException e) {
				e.printStackTrace();
			}
		} catch (JSONException e) {
			e.printStackTrace();
		} finally {
			httpClient = null;
		}
	}

 //   @Test
	public void testCheckCustomerNumber() {
		System.out.println("starting test testCheckCustomerNumber.............................................................................");
		HttpClient httpClient = new HttpClient();
		try {
			JSONArray verifyCheckCustomerNumber = (JSONArray) jsonObject
					.get("checkCustomerNumbers");
			Iterator<Object> iteratorVerify = verifyCheckCustomerNumber
					.iterator();
			try {
				while (iteratorVerify.hasNext()) {
					JSONObject next = (JSONObject) iteratorVerify.next();
				StringRequestEntity stringEntity = new StringRequestEntity(
						next.toString(), "application/json", "UTF-8");
				PostMethod postMethod = new PostMethod(CHECK_CUSTOMER_NUMBER);
				postMethod.setRequestEntity(stringEntity);
				int status = httpClient.executeMethod(postMethod);
				HashMap<String, String> map = this.buildHashMap(postMethod);
				// System.out.println("-->" + map.get("returnCRM"));
				postMethod.releaseConnection();
				assertEquals("testCheckEmail", "3", map.get("errCode"));
				assertEquals("testCheckEmail", "false", map.get("returnCRM"));
				assertEquals("testCheckCustomerNumber", 200, status);
				}
			} catch (IllegalStateException ex) {
				ex.printStackTrace();
			} catch (IOException e) {
				e.printStackTrace();
			}
		} catch (JSONException e) {
			e.printStackTrace();
		} finally {
			httpClient = null;
		}
	}
   
    /**
     * check verify workemail sending 
     */
  //  @Test
	public void testValidateWorkEmail() {
		System.out.println("starting test testValidateWorkEmail.............................................................................");
		System.out.println(checkWorkEmailJsonStr);
		HttpClient httpClient = new HttpClient();
		try {
			JSONArray verifyValidateWorkEmail = (JSONArray) jsonObject
					.get("validateWorkEmails");
			Iterator<Object> iteratorVerify = verifyValidateWorkEmail
					.iterator();
			try {
				while (iteratorVerify.hasNext()) {
					JSONObject next = (JSONObject) iteratorVerify.next();
				StringRequestEntity stringEntity = new StringRequestEntity(
						next.toString(), "application/json", "UTF-8");
				PostMethod postMethod = new PostMethod(VALIDATE_WORK_EMAIL);
				postMethod.setRequestEntity(stringEntity);
				int status = httpClient.executeMethod(postMethod);
				HashMap<String, String> map = this.buildHashMap(postMethod);
				// System.out.println("-->" + map.get("returnCRM"));
				postMethod.releaseConnection();
				
				assertEquals("testValidateWorkEmail", "Validation email sent", map.get("errReason"));
				assertEquals("testValidateWorkEmail", "true", map.get("returnCRM"));
				assertEquals("testValidateWorkEmail", 200, status);
				}
			} catch (IllegalStateException ex) {
				ex.printStackTrace();
			} catch (IOException e) {
				e.printStackTrace();
			}
		} catch (JSONException e) {
			e.printStackTrace();
		} finally {
			httpClient = null;
		}
	}


	public void testRegisterCustomer() {
		System.out.println(checkRegisterCustomerJsonStr);
		HttpClient httpClient = new HttpClient();
		try {
			String json = this.checkRegisterCustomerJsonStr.toString();
			JSONObject jsonObject = new JSONObject(json);
			try {
				StringRequestEntity stringEntity = new StringRequestEntity(
						jsonObject.toString(), "application/json", "UTF-8");
				PostMethod postMethod = new PostMethod(REGISTER_CUSTOMER);
				postMethod.setRequestEntity(stringEntity);
				int status = httpClient.executeMethod(postMethod);
				HashMap<String, String> map = this.buildHashMap(postMethod);
				// System.out.println("-->" + map.get("returnCRM"));
				postMethod.releaseConnection();
				assertEquals("testRegisterCustomer", 200, status);
			} catch (IllegalStateException ex) {
				ex.printStackTrace();
			} catch (IOException e) {
				e.printStackTrace();
			}
		} catch (JSONException e) {
			e.printStackTrace();
		} finally {
			httpClient = null;
		}
	}


	public void testPerformace() {
		System.out.println("pefermance testing " + checkEmailJsonStr);
		long startTime = System.currentTimeMillis();
		for (int i = 0; i < 1; i++) {
			// testCheckEmail();
		}
		long finishTime = System.currentTimeMillis();
		long timeSpan = finishTime - startTime;
		System.out.println("That took: " + timeSpan + " ms start from "
				+ startTime + " end by " + finishTime);
		// HttpClient httpClient =
	}

	private HashMap<String, String> buildHashMap(PostMethod postMethod)
			throws IOException {
		BufferedInputStream bufferedInputStream = new BufferedInputStream(
				postMethod.getResponseBodyAsStream());
		byte[] contents = new byte[1024];
		int bytesRead = 0;
		String strFileContents = "";
		while ((bytesRead = bufferedInputStream.read(contents)) != -1) {
			strFileContents = new String(contents, 0, bytesRead);
		}
		strFileContents = strFileContents.replaceAll("null", "\"\"");
		HashMap<String, String> map = new HashMap<String, String>();
		JSONObject jObject = new JSONObject(strFileContents);
		Iterator<?> keys = jObject.keys();
		while (keys.hasNext()) {
			String key = (String) keys.next();
			String value = jObject.getString(key);
			if (StringUtils.isEmpty(value)) {
				value = null;
			}
			map.put(key, value);
		}
		return map;

	}

	private StringBuffer assembleJsonObject(String checkResource) {
		StringBuffer stringBuffer = new StringBuffer();
		InputStream inputStream = this.getClass().getClassLoader()
				.getResourceAsStream(checkResource);
		BufferedReader r = new BufferedReader(
				new InputStreamReader(inputStream));
		StringBuilder stringBuilder = new StringBuilder();
		String line;
		String jsonString = null;
		try {
			while ((line = r.readLine()) != null) {
				stringBuilder.append(line);
			}
			jsonString = stringBuilder.toString();
		} catch (Exception e) {
			e.getStackTrace();
		}
		return stringBuffer.append(jsonString);
	}
	
	
}
