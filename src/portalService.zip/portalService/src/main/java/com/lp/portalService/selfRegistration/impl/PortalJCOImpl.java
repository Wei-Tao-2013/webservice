package com.lp.portalService.selfRegistration.impl;

import com.lp.connector.SAPConnector;
import com.lp.connector.exception.ConnectorException;
import com.lp.connector.impl.SAPConnectorImpl;
import com.lp.connector.model.Address;
import com.lp.connector.model.SAPConnectorRequest;
import com.lp.connector.model.SAPConnectorResponse;
import com.lp.portalService.model.CustomerData;
import com.lp.portalService.model.RegistrationRequest;
import com.lp.portalService.model.RegistrationResponse;
import com.lp.portalService.selfRegistration.PortalJCO;
import com.lp.portalService.utils.PortalServiceUtils;
import com.sap.tc.logging.Location;
import com.sap.tc.logging.Severity;
import com.sap.tc.logging.SimpleLogger;

import org.springframework.stereotype.Repository;

@Repository
public class PortalJCOImpl implements PortalJCO {
	
	private static final Location loc = Location.getLocation(PortalJCOImpl.class);
	
	public PortalJCOImpl() {
	
	}
    
	/* (non-Javadoc)
	 * @see com.lp.portalService.selfRegistration.PortalJCO#testJcoCall(com.lp.portalService.model.RegistrationRequest)
	 */
	@Override
	public RegistrationResponse testJcoCall(RegistrationRequest registrationReq)
			throws ConnectorException {
		RegistrationResponse RegResponse = new RegistrationResponse();
		SAPConnector sapConnector = new SAPConnectorImpl();
		SAPConnectorRequest sapReq = new SAPConnectorRequest();
		SAPConnectorResponse sapResponse = new SAPConnectorResponse();
		sapReq = (SAPConnectorRequest) PortalServiceUtils.copyProperties(registrationReq, sapReq);
		sapResponse = sapConnector.callCustomerValidationTest(sapReq);
		// /convert sapResponse to RegisterResponse
		RegResponse.setCustomerNumber(sapResponse.getCustomerNumber());
		RegResponse.setEmailAddress(sapResponse.getEmailAddress());
		RegResponse.setReturnCRM(sapResponse.getReturnCRM());
		RegResponse.setCustomerTxt(sapResponse.getCustomerTxt());
		return RegResponse;
	}
    
	/* (non-Javadoc)
	 * @see com.lp.portalService.selfRegistration.PortalJCO#callCustomerValidation(com.lp.portalService.model.RegistrationRequest)
	 */
	@Override
	public RegistrationResponse callCustomerValidation(
			RegistrationRequest registrationReq) throws ConnectorException {
		SAPConnector sapConnector = new SAPConnectorImpl();
		SAPConnectorRequest sapReq = new SAPConnectorRequest();
		sapReq = (SAPConnectorRequest) PortalServiceUtils.copyProperties(registrationReq, sapReq);
		/*System.out.println("Call callCustomerValidation from PortalJCOImpl with Json request " + PortalServiceUtils.converToJson(sapReq));*/
		SimpleLogger.trace(Severity.INFO, loc,  "Call callCustomerValidation from PortalJCOImpl with Json request" + PortalServiceUtils.converToJson(sapReq));
		SAPConnectorResponse sapResponse = sapConnector
				.callCustomerValidation(sapReq);
		// /convert sapResponse to RegisterResponse
		SimpleLogger.trace(Severity.INFO, loc,  "Response from callCustomerValidation to PortalJCOImpl with Json data" + PortalServiceUtils.converToJson(sapResponse));
		RegistrationResponse RegResponse = convertJcoResponse(sapResponse);
		CustomerData customerData = new CustomerData();
		customerData  =  (CustomerData) PortalServiceUtils.copyProperties(sapResponse.getCustomerData(), customerData);
		RegResponse.setCustomerData(customerData);
		return RegResponse;
	}
	
	

	
	/* (non-Javadoc)
	 * @see com.lp.portalService.selfRegistration.PortalJCO#callMandatoryIndicator(com.lp.portalService.model.RegistrationRequest)
	 */
	@Override
	public RegistrationResponse callMandatoryIndicator(
			RegistrationRequest registrationReq) throws ConnectorException {
		SAPConnector sapConnector = new SAPConnectorImpl();
		SAPConnectorRequest sapReq = new SAPConnectorRequest();
		sapReq = (SAPConnectorRequest) PortalServiceUtils.copyProperties(registrationReq, sapReq);
		/*System.out.println("Call callCustomerValidation from PortalJCOImpl with Json request " + PortalServiceUtils.converToJson(sapReq));*/
		SimpleLogger.trace(Severity.INFO, loc,  "Call callMandatoryIndicator from PortalJCOImpl with Json request" + PortalServiceUtils.converToJson(sapReq));
		SAPConnectorResponse sapResponse = sapConnector.callMandatoryIndicator(sapReq);
		// /convert sapResponse to RegisterResponse
		SimpleLogger.trace(Severity.INFO, loc,  "Response from callMandatoryIndicator to PortalJCOImpl with Json data" + PortalServiceUtils.converToJson(sapResponse));
		RegistrationResponse RegResponse = convertJcoResponse(sapResponse);
		return RegResponse;
	}
	


	/* (non-Javadoc)
	 * @see com.lp.portalService.selfRegistration.PortalJCO#callCustomerRegistration(com.lp.portalService.model.RegistrationRequest)
	 */
	@Override
	public RegistrationResponse callCustomerRegistration(
			RegistrationRequest registrationReq) throws ConnectorException {
		// TODO Auto-generated method stub
		SAPConnector sapConnector = new SAPConnectorImpl();
		SAPConnectorRequest sapReq = new SAPConnectorRequest();
		sapReq = (SAPConnectorRequest) PortalServiceUtils.copyProperties(registrationReq, sapReq);
		com.lp.connector.model.Address addr = new Address();
		addr = (com.lp.connector.model.Address) PortalServiceUtils.copyProperties(registrationReq.getResiAddress(), addr);
		sapReq.setResiAddress(addr);
		SimpleLogger.trace(Severity.INFO, loc,
				"Call callCustomerRegistration from PortalJCOImpl with Json request"
						+ PortalServiceUtils.converToJson(sapReq));
		SAPConnectorResponse sapResponse = sapConnector.callCustomerRegistration(sapReq);
		// /convert sapResponse to RegisterResponse
		SimpleLogger.trace(Severity.INFO, loc,
				"Response from callCustomerRegistration to PortalJCOImpl with Json data"
						+ PortalServiceUtils.converToJson(sapResponse));
		RegistrationResponse RegResponse = convertJcoResponse(sapResponse);
	
		return RegResponse;
	}

	/* (non-Javadoc)
	 * @see com.lp.portalService.selfRegistration.PortalJCO#callWorkEamilValiation(com.lp.portalService.model.RegistrationRequest)
	 */
	@Override
	public RegistrationResponse callWorkEamilValiation(
			RegistrationRequest registrationReq) throws ConnectorException {
		// TODO Auto-generated method stub
		SAPConnector sapConnector = new SAPConnectorImpl();
		SAPConnectorRequest sapReq = new SAPConnectorRequest();
		if ("true".equalsIgnoreCase(registrationReq.getVerIndicator())){
			registrationReq.setVerIndicator("X");
		}else{
			registrationReq.setVerIndicator("");
		}
		sapReq = (SAPConnectorRequest) PortalServiceUtils.copyProperties(registrationReq, sapReq);
		SimpleLogger.trace(Severity.INFO, loc,  "Call callWorkEamilValiation from PortalJCOImpl with Json request" + PortalServiceUtils.converToJson(sapReq));
		SAPConnectorResponse sapResponse = sapConnector.callWorkEamilValiation(sapReq);
		// /convert sapResponse to RegisterResponse
		SimpleLogger.trace(Severity.INFO, loc,  "Response from callWorkEamilValiation to PortalJCOImpl with Json data" + PortalServiceUtils.converToJson(sapResponse));
		RegistrationResponse RegResponse = convertJcoResponse(sapResponse);
		CustomerData customerData = new CustomerData();
		customerData  =  (CustomerData) PortalServiceUtils.copyProperties(sapResponse.getCustomerData(), customerData);
		RegResponse.setCustomerData(customerData);
		return RegResponse;
	}
	
	
	/* (non-Javadoc)
	 * @see com.lp.portalService.selfRegistration.PortalJCO#callInitEmailVerification(com.lp.portalService.model.RegistrationRequest)
	 */
	@Override
	public  RegistrationResponse callInitEmailVerification(RegistrationRequest registrationReq) throws ConnectorException {

		// TODO Auto-generated method stub
		SAPConnector sapConnector = new SAPConnectorImpl();
		SAPConnectorRequest sapReq = new SAPConnectorRequest();
		sapReq = (SAPConnectorRequest) PortalServiceUtils.copyProperties(registrationReq, sapReq);
	/*	System.out.println("Call callInitEmailVerification from PortalJCOImpl with Json request " + PortalServiceUtils.converToJson(sapReq));*/
		SimpleLogger.trace(Severity.INFO, loc,  "Call callInitEmailVerification from PortalJCOImpl with Json request" + PortalServiceUtils.converToJson(sapReq));
		SAPConnectorResponse sapResponse = sapConnector.callInitEmailVerification(sapReq);
		// /convert sapResponse to RegisterResponse
	/*	System.out.println("Response from callInitEmailVerification to PortalJCOImpl with Json data " + PortalServiceUtils.converToJson(sapResponse));*/
		SimpleLogger.trace(Severity.INFO, loc,  "Response from callInitEmailVerification to PortalJCOImpl with Json data" + PortalServiceUtils.converToJson(sapResponse));
		RegistrationResponse RegResponse = convertJcoResponse(sapResponse);
		return RegResponse;
	}
	
	
	/* (non-Javadoc)
	 * @see com.lp.portalService.selfRegistration.PortalJCO#callVerifyToken(com.lp.portalService.model.RegistrationRequest)
	 */
	@Override
	public RegistrationResponse callVerifyToken(
			RegistrationRequest registrationReq) throws ConnectorException {
		// TODO Auto-generated method stub
		SAPConnectorRequest sapReq = new SAPConnectorRequest();
		sapReq = (SAPConnectorRequest) PortalServiceUtils.copyProperties(registrationReq, sapReq);
		SimpleLogger.trace(Severity.INFO, loc,  "Call callInitEmailVerification from PortalJCOImpl with Json request" + PortalServiceUtils.converToJson(sapReq));
	//	SAPConnectorResponse sapResponse = sapConnector.callInitEmailVerification(sapReq);
		SAPConnectorResponse sapResponse = new SAPConnectorResponse();
		sapResponse.setCustomerUID("Demo User");
		// /convert sapResponse to RegisterResponse
		SimpleLogger.trace(Severity.INFO, loc,  "Response from callInitEmailVerification to PortalJCOImpl with Json data" + PortalServiceUtils.converToJson(sapResponse));
		RegistrationResponse RegResponse = convertJcoResponse(sapResponse);
		return RegResponse;
		
	}
	
	
	public RegistrationResponse callAddressCheck(
			RegistrationRequest registrationReq) throws ConnectorException {

		// TODO Auto-generated method stub
		SAPConnector sapConnector = new SAPConnectorImpl();
		SAPConnectorRequest sapReq = new SAPConnectorRequest();
		if ("true".equalsIgnoreCase(registrationReq.getGoogleIndicator())){
			registrationReq.setGoogleIndicator("X");
		}else{
			registrationReq.setGoogleIndicator("");
		}
		sapReq = (SAPConnectorRequest) PortalServiceUtils.copyProperties(registrationReq, sapReq);
		SimpleLogger.trace(Severity.INFO, loc,  "Call callAddressCheck from PortalJCOImpl with Json request" + PortalServiceUtils.converToJson(sapReq));
		com.lp.connector.model.Address addr = new Address();
		addr = (com.lp.connector.model.Address) PortalServiceUtils.copyProperties(registrationReq.getResiAddress(), addr);
		sapReq.setResiAddress(addr);
		SAPConnectorResponse sapResponse = sapConnector.callAddressCheck(sapReq);
		// /convert sapResponse to RegisterResponse
		SimpleLogger.trace(Severity.INFO, loc,  "Response from callAddressCheck to PortalJCOImpl with Json data" + PortalServiceUtils.converToJson(sapResponse));
		RegistrationResponse RegResponse = convertJcoResponse(sapResponse);
		return RegResponse;
		
	}
	
	
	@Override
	public RegistrationResponse callVerifyEmailActivation(
			RegistrationRequest registrationReq) throws ConnectorException {
	
		// TODO Auto-generated method stub
		SAPConnector sapConnector = new SAPConnectorImpl();
		SAPConnectorRequest sapReq = new SAPConnectorRequest();
		sapReq = (SAPConnectorRequest) PortalServiceUtils.copyProperties(registrationReq, sapReq);
	/*	System.out.println("Call callInitEmailVerification from PortalJCOImpl with Json request " + PortalServiceUtils.converToJson(sapReq));*/
		SimpleLogger.trace(Severity.INFO, loc,  "Call callVerifyEmailActivation from PortalJCOImpl with Json request" + PortalServiceUtils.converToJson(sapReq));
		SAPConnectorResponse sapResponse = sapConnector.callVerifyEmailActivation(sapReq);
	
		sapResponse.setCustomerUID("Demo User");
		// /convert sapResponse to RegisterResponse
	/*	System.out.println("Response from callInitEmailVerification to PortalJCOImpl with Json data " + PortalServiceUtils.converToJson(sapResponse));*/
		SimpleLogger.trace(Severity.INFO, loc,  "Response from callVerifyEmailActivation to PortalJCOImpl with Json data" + PortalServiceUtils.converToJson(sapResponse));
		RegistrationResponse RegResponse = convertJcoResponse(sapResponse);
		return RegResponse;
		
	}
	
	
	@Override
	public RegistrationResponse callUpdatePassword(
			RegistrationRequest registrationReq) throws ConnectorException {
	
		// TODO Auto-generated method stub
		SAPConnectorRequest sapReq = new SAPConnectorRequest();
		sapReq = (SAPConnectorRequest) PortalServiceUtils.copyProperties(registrationReq, sapReq);
	/*	System.out.println("Call callInitEmailVerification from PortalJCOImpl with Json request " + PortalServiceUtils.converToJson(sapReq));*/
		SimpleLogger.trace(Severity.INFO, loc,  "Call callInitEmailVerification from PortalJCOImpl with Json request" + PortalServiceUtils.converToJson(sapReq));
	//	SAPConnectorResponse sapResponse = sapConnector.callInitEmailVerification(sapReq);
		SAPConnectorResponse sapResponse = new SAPConnectorResponse();
		sapResponse.setCustomerUID("Demo User");
		// /convert sapResponse to RegisterResponse
	/*	System.out.println("Response from callInitEmailVerification to PortalJCOImpl with Json data " + PortalServiceUtils.converToJson(sapResponse));*/
		SimpleLogger.trace(Severity.INFO, loc,  "Response from callInitEmailVerification to PortalJCOImpl with Json data" + PortalServiceUtils.converToJson(sapResponse));
		RegistrationResponse RegResponse = convertJcoResponse(sapResponse);
		return RegResponse;
		
	}
	

	/**
	 * convert response from java connector object to web service response
	 * @param sapResponse
	 * @return RegResponse
	 */
	private RegistrationResponse convertJcoResponse(SAPConnectorResponse sapResponse) {
		RegistrationResponse RegResponse = new RegistrationResponse();
		RegResponse = (RegistrationResponse) PortalServiceUtils.copyProperties(sapResponse, RegResponse);
		return RegResponse;
	}
	
		

}