package com.lp.portalService.service;

import com.lp.portalService.model.RegistrationRequest;
import com.lp.portalService.model.RegistrationResponse;

public interface PortalDetailsResponse {
	
	RegistrationResponse checkEmail(
			RegistrationRequest registrationRequest);
	
	
	RegistrationResponse checkCustomerNumber(
			RegistrationRequest registrationRequest);
	

	RegistrationResponse validateWorkEmail(
			RegistrationRequest registrationRequest);
	
	RegistrationResponse registerCustomer(
			RegistrationRequest registrationRequest);
	
	
	RegistrationResponse testJcoconnection(
			RegistrationRequest registrationRequest);
	
	RegistrationResponse initialiseUser(
			RegistrationRequest registrationRequest);
	
	RegistrationResponse verifyInitialUser(
			RegistrationRequest registrationRequest);
	
	RegistrationResponse verifyToken(
			RegistrationRequest registrationRequest);
	
	RegistrationResponse verifyAddress(
			RegistrationRequest registrationRequest);
	
	RegistrationResponse updatePassword(
			RegistrationRequest registrationRequest);
	
	RegistrationResponse verifyEmailActivation(
			RegistrationRequest registrationRequest);
	
	RegistrationResponse  registerEncryptSession(RegistrationRequest registrationRequest);
    
    String getEncryptSession();
    
    void killSession();
    
    void switchGoogleAPI(String indicator);
    
    RegistrationResponse  checkEncryptSession(RegistrationRequest registrationRequest);
    RegistrationResponse  checkCompleteRegisterPermission(RegistrationRequest registrationRequest);
    
    
    String getGoogleGeoTest(String request);
    
    RegistrationResponse sendVerifyEmail();
    
	
}
