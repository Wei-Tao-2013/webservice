package com.lp.portalService.utils;

import java.io.Serializable;

public class AppConstants implements Serializable {
	
	/** For serialization. */
	private static final long serialVersionUID = -3378732900839934764L;

	/**System Exceptions**/
	public static final String ERROR_CODE_JCO_EXCETPION ="0999"; 
	public static final String ERROR_CODE_UserAlreadyExistsException ="0998"; 
	public static final String ERROR_CODE_UserAccountAlreadyExistsException ="0997"; 
	public static final String ERROR_CODE_UMException ="0996"; 
	public static final String ERROR_CODE_UMRuntimeException ="0995"; 
	public static final String ERROR_CODE_NoSuchRoleException ="0994"; 
	public static final String ERROR_CODE_NoSuchUserException ="0993"; 
	public static final String ERROR_CODE_NoSuchUserAccountException ="0992"; 
	public static final String ERROR_CODE_AttributeValueAlreadyExistsException ="0991";
	
	/**Business errors**/
	public static final String ERROR_CODE_LoginIDNotFound="0090";
	public static final String ERROR_CODE_SESSIONLOST="0089";
	public static final String ERROR_CODE_INCORRECT_ENCRYPTPWD ="0088";
	public static final String ERROR_CODE_PERMISSION_DENY="0087";
	public static final String ERROR_CODE_INCORRECT_PWD ="0086";
	public static final String ERROR_CODE_DUPLIATED_USER ="0085";
	
	/**Application Status Setting**/
	public static final String RETURN_UME_TRUE="true";
	public static final String RETURN_UME_FALSE="false";
	public static final String RETURN_CRM_TRUE="true";
	public static final String RETURN_CRM_FALSE="false";
	public static final String RETURN_TRUE="true";
	public static final String RETURN_FALSE="false";
	public static final String RETURN_UME_REGISTERD  = "registered"; //
	public static final String RETURN_UME_CREATED ="created";

	/**Common explanation **/
	public static final String CALL_LEASEPLAN ="LeasePlan Online has encountered an internal error, please try again later or call 132 572.";
	public static final String MSG_USER_EXISTS = "User already exists ,please try again later or call 132 572.";
	public static final String MSG_SESSION_LOST ="Session lost or expired.";
	public static final String MSG_PWD_INCORRECT ="Encrypt password in session is incorrect";
	public static final String MSG_DENY ="Permission deny.";
	public static final String MSG_NO_USER_EXISTS = "User account can't be found on portal, please try again later or call 132 572.";
	public static final String MSG_NO_GROUP_FOUND = "User group can't be found on portal, please try again later or call 132 572.";
	public static final String MSG_NO_LOGON_ID ="UME Logon id can't be found in portal.";
	public static final String MSG_NO_ROLE_FOUND = "User role can't be found on portal, please try again later or call 132 572.";
	public static final String MSG_LOGON_PWD_INCORRECT = "Password failed.";
	public static final String MSG_LOGON_PWD_LOCKED ="Password is locked";
	public static final String MSG_LOGON_PWD_EXPIRED = "Password expired";
	public static final String MSG_LOGON_DUPLICATED_USER = "This user has been already registered.";
	
	/**status list**/
	public static final String REJECTED = "Rejected";
	public static final String COMPLETED = "Completed";
	
	/**roles&role type list in portal**/
	public static final String SELF_INIT_ROLE ="pcd:portal_content/leaseplan_online/anonymous/roles/self_init_role";  // initialise register 
	public static final String SELF_CONTINUING_COMPLETE_ROLE = "pcd:portal_content/leaseplan_online/anonymous/roles/self_completed_role"; // completed register
	public static final String SELF_INIT_ROLE_TYPE = "initialiseRole"; // initialise register role type
	public static final String SELF_COMPLETED_ROLE_TYPE = "completedRole"; // completed register role type
	public static final String DRIVER_QUOTE = "DriverQuote";   // driver quote;
	public static final String DRIVER_GENERAL = "DriverGeneral"; // driver general;
	public static final String DRIVER ="Driver";
	
	/**groups&group type list in portal**/
	public static final String SELF_INIT_GROUP ="SelfRegistrationInitial";  // initialise register 
	public static final String SELF_CONTINUING_COMPLETE_GROUP = "SelfRegistrationVerified"; // completed register
	public static final String SELF_PENDING_GROUP  ="SelfRegistrationPending"; //manual approval pending stage  
	public static final String SELF_APPROVAL_GROUP  ="SelfRegistrationApproval"; //manual approval pending stage 
	
	public static final String SELF_INIT_GROUP_TYPE = "initialiseGroup"; // initialise register group type
	public static final String SELF_COMPLETED_GROUP_TYPE = "verifiedGroup"; // completed register group type
	public static final String SELF_PENDING_GROUP_TYPE = "pendingGroup"; // manual approval pending stage group type
	public static final String SELF_APPROVAL_GROUP_TYPE = "approvalGroup"; // Approval stage group type
	public static final String SELF_OTHER_GROUP_TYPE = "otherGroup"; // manual approval pending stage group type
	
	/**CRM Return status***/
	public static final String CRM_STATUS_APPROVAL = "COMPLETE"; //creating driver approval 
	public static final String CRM_STATUS_PENDING = "PENDING"; // creating driver pending
	public static final String CRM_STATUS_REJECJ = "ERROR"; // creating driver rejected
	
	/**redirect link list**/
	public static final String INITIAL_LINK = "initial link"; // initial link for initialise register
	public static final String COMPLETED_LINK = "completed link"; // completed link for completed register
		
}