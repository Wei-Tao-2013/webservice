package com.lp.portalService.service.impl;

import java.io.IOException;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.Proxy;
import java.net.SocketAddress;
import java.net.UnknownHostException;

import javax.servlet.http.HttpSession;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Cookie;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.maps.GeoApiContext;
import com.google.maps.GeocodingApi;
import com.google.maps.errors.ApiException;
import com.google.maps.model.GeocodingResult;
import com.lp.connector.exception.ConnectorException;
import com.lp.portalService.model.RegistrationRequest;
import com.lp.portalService.model.RegistrationResponse;
import com.lp.portalService.selfRegistration.PortalJCO;
import com.lp.portalService.selfRegistration.PortalUME;
import com.lp.portalService.service.PortalDetailsResponse;
import com.lp.portalService.utils.AppConstants;
import com.lp.portalService.utils.AppData;
import com.lp.portalService.utils.PortalServiceUtils;
import com.sap.security.api.IUserMaint;
import com.sap.security.api.UMException;
import com.sap.tc.logging.Category;
import com.sap.tc.logging.Location;
import com.sap.tc.logging.Severity;
import com.sap.tc.logging.SimpleLogger;

@Component
public class PortalDetailsResponseImpl implements PortalDetailsResponse {

	private static final Location loc = Location.getLocation(PortalDetailsResponseImpl.class);

	@Autowired
	private PortalUME portalUMEImpl;
	@Autowired
	private PortalJCO portalJCOImpl;
	@Autowired 
	private HttpSession httpSession;
	@Autowired 
	private HttpServletResponse httpResponse;
	@Autowired 
	private HttpServletRequest httpRequest;
	
	 
	/* (non-Javadoc)
	 * @see com.lp.portalService.service.PortalDetailsResponse#checkEmail(com.lp.portalService.model.RegistrationRequest)
	 */
	public RegistrationResponse checkEmail(final RegistrationRequest registrationRequest){
		
		//secure registerCustomer service on portal 
				RegistrationResponse RegResponseSecure = checkEncryptSession(registrationRequest);
				if (AppConstants.RETURN_UME_FALSE.equals(RegResponseSecure.getReturnUME())){
					RegResponseSecure.setReturnCRM(AppConstants.RETURN_CRM_FALSE);	
					return RegResponseSecure;
				}
        // secure end  this solution  would be changed accordingly if web service moves out from portal
		RegistrationResponse RegResponse;
		try {
			RegResponse = portalJCOImpl.callCustomerValidation(registrationRequest);
			RegResponse.setGoogleAPI(AppData.googleAPI);
		} catch (ConnectorException e) {
			// TODO Auto-generated catch block
			  SimpleLogger.log(Severity.ERROR, Category.SYS_SERVER, loc, "PortalDetailsResponseImpl.checkEmail",   "Call PortalJcoImpl with request of " + PortalServiceUtils.converToJson(registrationRequest)); 
              SimpleLogger.traceThrowable(Severity.ERROR, loc, "", e);
              RegResponse = new RegistrationResponse();
              RegResponse.setErrCode(AppConstants.ERROR_CODE_JCO_EXCETPION);
              RegResponse.setErrReason(AppConstants.CALL_LEASEPLAN);
		}
		return  RegResponse;
	}
    
	public RegistrationResponse sendVerifyEmail(){
		/*
		if (!PortalServiceUtils.checkIpBlock(httpRequest.getRemoteAddr())){
			RegistrationResponse RegResponseBlock = new RegistrationResponse();
			RegResponseBlock.setReturnUME(AppConstants.RETURN_UME_FALSE);
			RegResponseBlock.setErrReason("This Ip is blocked for a while ,please try again, IP is  " + httpRequest.getRemoteAddr());
			return RegResponseBlock;
		};*/
	  
		RegistrationResponse RegResponse = new RegistrationResponse();
		RegistrationRequest registrationReq= new RegistrationRequest();
		
		String emailAddress = null;
		IUserMaint userMaint = null;
	    int sentEmailNumber = 0;
		try {
			Cookie[] cookies = httpRequest.getCookies();
			if (cookies != null) {
			  for (Cookie cookie : cookies) {
			    if (cookie.getName().equals("selfRegLogonId")) {
			    //do something
			     emailAddress = cookie.getValue();
			     }
			   }
			 }
			if (emailAddress != null ){
				registrationReq.setEmailAddress(emailAddress);
				RegistrationResponse RegResponseEncrypt = portalUMEImpl.getEncryptPwd(emailAddress);
				String initialSession =  (httpSession.getAttribute("encryptSessionInitial") != null) ? httpSession.getAttribute("encryptSessionInitial").toString() : "";
				if (initialSession.equals(RegResponseEncrypt.getToken())) {  // verify Token
					// retrieve info as per emailAddress 
					userMaint = portalUMEImpl.getUserInfo(emailAddress);
					if (userMaint != null ){
						sentEmailNumber = userMaint.getAttribute("com.lp.selfReg", "numEmailSent")== null? 0 : Integer.parseInt(userMaint.getAttribute("com.lp.selfReg", "numEmailSent")[0]);
						
						if (sentEmailNumber < AppData.maxNumberEmailSent){
						registrationReq.setFirstName(userMaint.getFirstName());
						registrationReq.setLastName(userMaint.getLastName());
						registrationReq.setVerIndicator(""); // no verification need
						RegResponse = portalJCOImpl.callInitEmailVerification(registrationReq);
						if (AppConstants.RETURN_CRM_TRUE.equalsIgnoreCase(RegResponse.getReturnCRM())){
							userMaint.removeAttributeValue("com.lp.selfReg", "numEmailSent", String.valueOf(sentEmailNumber));
							userMaint.addAttributeValue("com.lp.selfReg", "numEmailSent", String.valueOf(sentEmailNumber+1));
							try {
								userMaint.save();
								userMaint.commit();
							} catch (UMException e) {
								// TODO Auto-generated catch block
							    SimpleLogger.log(Severity.ERROR, Category.SYS_SERVER, loc, "PortalDetailsResponseImpl.sendVerifyEmail",   "With request of logon id " +  emailAddress); 
								SimpleLogger.traceThrowable(Severity.ERROR, loc, "", e);
							}
						
							
							httpSession.setAttribute("encryptSessionInitial", "done"); // clear session in case user re send email multiple times unless user sign in portal again
							RegResponse.setReturnUME(AppConstants.RETURN_UME_TRUE);
							RegResponse.setErrReason("The verification email has been sent out.");
							}
						}else {
							// send verify email exceed maximum
							SimpleLogger.trace(Severity.ERROR,loc,"sendVerifyEmail:: can not find user info as request of logon id "+ emailAddress); 
							RegResponse.setErrReason("The number of verify email sent has been exceed the maximum ");
							RegResponse.setReturnUME(AppConstants.RETURN_UME_FALSE);
							return RegResponse;
						}
					}else{
						// can't find user info on portal 
						SimpleLogger.trace(Severity.ERROR,loc,"sendVerifyEmail:: can not find user info as request of logon id "+ emailAddress); 
						RegResponse.setErrReason("Can not find user info as request of logon id "+ emailAddress);
						RegResponse.setReturnUME(AppConstants.RETURN_UME_FALSE);
						return RegResponse;
					} 
				}else {
					// user session is clear
					if ("done".equalsIgnoreCase(initialSession)){
						SimpleLogger.trace(Severity.INFO,loc,"sendVerifyEmail:: user's request session could be remove as email has been sent already as request of logon id "+ emailAddress +" Token is"+RegResponseEncrypt.getToken() +
							"initial session value is "+initialSession ); 
						RegResponse.setErrReason("The email has been sent already as request of logon id "+ emailAddress );
					}else {
						// user account is not correct as token is wrong
						SimpleLogger.trace(Severity.ERROR,loc,"sendVerifyEmail:: user's request session could be wrong as token is incorrect as request of logon id "+ emailAddress +" Token is"+RegResponseEncrypt.getToken() +
								"initial session value is "+initialSession ); 
						RegResponse.setErrReason("User's request session could be wrong as logon id "+ emailAddress +" you may sign in again to try." );
					}
				
					RegResponse.setReturnUME(AppConstants.RETURN_UME_FALSE);
					return RegResponse;
				
				}
			} else {
			  //can't find email info in cookie as issuse of setting cookie or  service be called without sign in. 
				SimpleLogger.trace(Severity.ERROR,loc,"sendVerifyEmail:: can't find email info in cookie as issuse of setting cookie or service be called without sign in.");  
				RegResponse.setErrReason(" Can't find email info,please sign in first." );
				RegResponse.setReturnUME(AppConstants.RETURN_UME_FALSE);
				return RegResponse;
			}
			} catch (ConnectorException e) {
				// TODO Auto-generated catch block
				  SimpleLogger.log(Severity.ERROR, Category.SYS_SERVER, loc, "PortalDetailsResponseImpl.sendVerifyEmail",   "With request of logon id " +  emailAddress); 
	              SimpleLogger.traceThrowable(Severity.ERROR, loc, "", e);
	         //     RegResponse = new RegistrationResponse();
	              RegResponse.setErrCode(AppConstants.ERROR_CODE_JCO_EXCETPION);
	          	  RegResponse.setReturnUME(AppConstants.RETURN_UME_FALSE);
	              RegResponse.setErrReason(AppConstants.CALL_LEASEPLAN);
			}
		return RegResponse;
	}
	

	/* (non-Javadoc)
	 * @see com.lp.portalService.service.PortalDetailsResponse#checkCustomerNumber(com.lp.portalService.model.RegistrationRequest)
	 */
	public RegistrationResponse checkCustomerNumber(final RegistrationRequest registrationRequest){
		
	  //Secure registerCustomer service on portal 
		RegistrationResponse RegResponseSecure = checkEncryptSession(registrationRequest);
		if (AppConstants.RETURN_UME_FALSE.equals(RegResponseSecure.getReturnUME())){
			RegResponseSecure.setReturnCRM(AppConstants.RETURN_CRM_FALSE);	
			return RegResponseSecure;
		}
	  // Secure end  this solution  would be changed accordingly if web service moves out from portal
				
		RegistrationResponse RegResponse;
		RegistrationResponse RegResponseMandatory;
		try {
			RegResponse = portalJCOImpl.callCustomerValidation(registrationRequest);
			RegResponseMandatory = portalJCOImpl.callMandatoryIndicator(registrationRequest);
			RegResponse.setMandatory(RegResponseMandatory.getMandatory());
		//	RegResponse.setMandatory("true");
			RegResponse.setGoogleAPI(AppData.googleAPI);
			SimpleLogger.trace(Severity.INFO, loc,  "Call checkCustomerNumber retrives googleAPI " + PortalServiceUtils.converToJson(AppData.googleAPI));
		        
		} catch (ConnectorException e) {
			// TODO Auto-generated catch block
			  SimpleLogger.log(Severity.ERROR, Category.SYS_SERVER, loc, "PortalDetailsResponseImpl.checkCustomerNumber",   "Call PortalJcoImpl with request of " + PortalServiceUtils.converToJson(registrationRequest)); 
              SimpleLogger.traceThrowable(Severity.ERROR, loc, "", e);
              RegResponse = new RegistrationResponse();
              RegResponse.setErrCode(AppConstants.ERROR_CODE_JCO_EXCETPION);
              RegResponse.setErrReason(AppConstants.CALL_LEASEPLAN);
		}
		return  RegResponse;
	}
	
	
	/* (non-Javadoc)
	 * @see com.lp.portalService.service.PortalDetailsResponse#validateWorkEmail(com.lp.portalService.model.RegistrationRequest)
	 */
	public RegistrationResponse validateWorkEmail(final RegistrationRequest registrationRequest){
		
		//secure registerCustomer service on portal 
		RegistrationResponse RegResponseSecure = checkEncryptSession(registrationRequest);
		if (AppConstants.RETURN_UME_FALSE.equals(RegResponseSecure.getReturnUME())){
			RegResponseSecure.setReturnCRM(AppConstants.RETURN_CRM_FALSE);	
			return RegResponseSecure;
		}
	   // secure end  this solution  would be changed accordingly if web service moves out from portal
		RegistrationResponse RegResponse;
		RegistrationResponse RegResponseMandatory;
		try {
			RegResponse = portalJCOImpl.callWorkEamilValiation(registrationRequest);
			RegResponseMandatory = portalJCOImpl.callMandatoryIndicator(registrationRequest);
			RegResponse.setMandatory(RegResponseMandatory.getMandatory());
		//	RegResponse.setMandatory("true");
			RegResponse.setGoogleAPI(AppData.googleAPI);
			
			SimpleLogger.trace(Severity.INFO, loc,  "Call validateWorkEmail retrives googleAPI " + PortalServiceUtils.converToJson(AppData.googleAPI));
			
		} catch (ConnectorException e) {
			// TODO Auto-generated catch block
			  SimpleLogger.log(Severity.ERROR, Category.SYS_SERVER, loc, "PortalDetailsResponseImpl.validateWorkEmail",   "Call PortalJcoImpl with request of " + PortalServiceUtils.converToJson(registrationRequest)); 
              SimpleLogger.traceThrowable(Severity.ERROR, loc, "", e);
              RegResponse = new RegistrationResponse();
              RegResponse.setErrCode(AppConstants.ERROR_CODE_JCO_EXCETPION);
              RegResponse.setErrReason(AppConstants.CALL_LEASEPLAN);
              
		}
		return  RegResponse;
	}

	/* (non-Javadoc)
	 * @see com.lp.portalService.service.PortalDetailsResponse#registerCustomer(com.lp.portalService.model.RegistrationRequest)
	 */
	public RegistrationResponse registerCustomer(final RegistrationRequest registrationRequest){
		RegistrationResponse RegResponse, RegResponseSecure;
		try {
			//secure registerCustomer service on portal 
			RegResponseSecure = checkEncryptSession(registrationRequest);
			if (AppConstants.RETURN_UME_FALSE.equals(RegResponseSecure.getReturnUME())){
				RegResponseSecure.setReturnCRM(AppConstants.RETURN_CRM_FALSE);	
				return RegResponseSecure;
			}
		   // secure end  this solution  would be changed accordingly if web service moves out from portal
			RegResponse = portalJCOImpl.callCustomerRegistration(registrationRequest);
			//call UME to assign pending role for this user
			if  (AppConstants.CRM_STATUS_PENDING.equalsIgnoreCase(RegResponse.getAppStatus())){
				RegistrationResponse	RegResponseUME = portalUMEImpl.assignPendingGroup(registrationRequest.getEmailAddress());
				if (AppConstants.RETURN_UME_TRUE.equalsIgnoreCase(RegResponseUME.getReturnUME())){
					RegResponse.setReturnUME(AppConstants.RETURN_UME_TRUE);
				}else{
					return RegResponseUME;
				}
			}else if  (AppConstants.CRM_STATUS_APPROVAL.equalsIgnoreCase(RegResponse.getAppStatus())){  //	//call UME to assign approval role for this user
				RegistrationResponse	RegResponseUME = portalUMEImpl.assignApprovalGroup(registrationRequest.getEmailAddress());
				if (AppConstants.RETURN_UME_TRUE.equalsIgnoreCase(RegResponseUME.getReturnUME())){
					RegResponse.setReturnUME(AppConstants.RETURN_UME_TRUE);
				}else{
					return RegResponseUME;
				}
			}else{
				RegResponse.setReturnUME(AppConstants.RETURN_UME_TRUE);
			}
			
		} catch (ConnectorException ec) {
			// TODO Auto-generated catch block
			  SimpleLogger.log(Severity.ERROR, Category.SYS_SERVER, loc, "PortalDetailsResponseImpl.registerCustomer",   "Call PortalJcoImpl with request of " + PortalServiceUtils.converToJson(registrationRequest)); 
              SimpleLogger.traceThrowable(Severity.ERROR, loc, "", ec);
              RegResponse = new RegistrationResponse();
              RegResponse.setErrCode(AppConstants.ERROR_CODE_JCO_EXCETPION);
              RegResponse.setErrReason(AppConstants.CALL_LEASEPLAN);
		}
		return  RegResponse;
	}
	
	
	/* (non-Javadoc)
	 * @see com.lp.portalService.service.PortalDetailsResponse#registerCustomer(com.lp.portalService.model.RegistrationRequest)
	 */
	public RegistrationResponse verifyToken(final RegistrationRequest registrationRequest){
		RegistrationResponse RegResponse;
		try {
			RegResponse = portalJCOImpl.callVerifyToken(registrationRequest);
		} catch (ConnectorException ec) {
			// TODO Auto-generated catch block
			  SimpleLogger.log(Severity.ERROR, Category.SYS_SERVER, loc, "PortalDetailsResponseImpl.registerCustomer",   "Call PortalJcoImpl with request of " + PortalServiceUtils.converToJson(registrationRequest)); 
              SimpleLogger.traceThrowable(Severity.ERROR, loc, "", ec);
              RegResponse = new RegistrationResponse();
              RegResponse.setErrCode(AppConstants.ERROR_CODE_JCO_EXCETPION);
              RegResponse.setErrReason(AppConstants.CALL_LEASEPLAN);
		}
		return  RegResponse;
	}
	
	

	public RegistrationResponse verifyAddress(final RegistrationRequest registrationRequest){
		//secure registerCustomer service on portal 
		RegistrationResponse RegResponseSecure = checkEncryptSession(registrationRequest);
		if (AppConstants.RETURN_UME_FALSE.equals(RegResponseSecure.getReturnUME())){
			RegResponseSecure.setReturnCRM(AppConstants.RETURN_CRM_FALSE);	
			return RegResponseSecure;
		}
        // secure end  this solution  would be changed accordingly if web service moves out from portal
		RegistrationResponse RegResponse;
		try {
			RegResponse = portalJCOImpl.callAddressCheck(registrationRequest);
		} catch (ConnectorException ec) {
			// TODO Auto-generated catch block
			  SimpleLogger.log(Severity.ERROR, Category.SYS_SERVER, loc, "PortalDetailsResponseImpl.verifyAddress",   "Call PortalJcoImpl with request of " + PortalServiceUtils.converToJson(registrationRequest)); 
              SimpleLogger.traceThrowable(Severity.ERROR, loc, "", ec);
              RegResponse = new RegistrationResponse();
              RegResponse.setErrCode(AppConstants.ERROR_CODE_JCO_EXCETPION);
              RegResponse.setErrReason(AppConstants.CALL_LEASEPLAN);
		}
		return  RegResponse;
	}
	
	

	/* (non-Javadoc)
	 * @see com.lp.portalService.service.PortalDetailsResponse#updatePassword(com.lp.portalService.model.RegistrationRequest)
	 */
	public RegistrationResponse updatePassword(final RegistrationRequest registrationRequest){
		RegistrationResponse RegResponse;
		try {
			RegResponse = portalJCOImpl.callUpdatePassword(registrationRequest);
		} catch (ConnectorException ec) {
			// TODO Auto-generated catch block
			  SimpleLogger.log(Severity.ERROR, Category.SYS_SERVER, loc, "PortalDetailsResponseImpl.updatePassword",   "Call PortalJcoImpl with request of " + PortalServiceUtils.converToJson(registrationRequest)); 
              SimpleLogger.traceThrowable(Severity.ERROR, loc, "", ec);
              RegResponse = new RegistrationResponse();
              RegResponse.setErrCode(AppConstants.ERROR_CODE_JCO_EXCETPION);
              RegResponse.setErrReason(AppConstants.CALL_LEASEPLAN);
		}
		return  RegResponse;
	}
	
	/* (non-Javadoc)
	 * @see com.lp.portalService.service.PortalDetailsResponse#verifyEmailActivation(com.lp.portalService.model.RegistrationRequest)
	 */
	public RegistrationResponse verifyEmailActivation(final RegistrationRequest registrationRequest){
		RegistrationResponse RegResponse;
		try {
			RegResponse = portalJCOImpl.callVerifyEmailActivation(registrationRequest);
		} catch (ConnectorException ec) {
			// TODO Auto-generated catch block
			  SimpleLogger.log(Severity.ERROR, Category.SYS_SERVER, loc, "PortalDetailsResponseImpl.verifyEmailActivation",   "Call PortalJcoImpl with request of " + PortalServiceUtils.converToJson(registrationRequest)); 
              SimpleLogger.traceThrowable(Severity.ERROR, loc, "", ec);
              RegResponse = new RegistrationResponse();
              RegResponse.setErrCode(AppConstants.ERROR_CODE_JCO_EXCETPION);
              RegResponse.setErrReason(AppConstants.CALL_LEASEPLAN);
		}
		return  RegResponse;

	}
	
	/* (non-Javadoc)
	 * @see com.lp.portalService.service.PortalDetailsResponse#initialiseUser(com.lp.portalService.model.RegistrationRequest)
	 */
	public RegistrationResponse initialiseUser(final RegistrationRequest registrationRequest){
	 	
	   /*  String ip = httpRequest.getHeader("x-forwarded-for");
	       if ( null == ip || ip.length() == 0 || "unknown".equalsIgnoreCase(ip))
	       {
	                   ip =httpRequest.getHeader("Proxy-Client-IP");         
	       }
	       if ( null == ip || ip.length() == 0 || "unknown".equalsIgnoreCase(ip))
	       {
	                   ip = httpRequest.getHeader("WL-Proxy-Client-IP");
	       }
	       if ( null == ip || ip.length() == 0 || "unknown".equalsIgnoreCase(ip))
	       {
	                   ip = httpRequest.getRemoteAddr();
	       }
	    
	   	SimpleLogger.trace(Severity.INFO,loc,"initialiseUser request :"+  ip );   
	 	
	 	if (!PortalServiceUtils.checkIpBlock(ip)){
			RegistrationResponse RegResponseBlock = new RegistrationResponse();
			RegResponseBlock.setReturnUME(AppConstants.RETURN_UME_FALSE);
			RegResponseBlock.setErrReason("This Ip is blocked for a while ,please try again, IP is  " + ip);
			return RegResponseBlock;
		};*/
		
		RegistrationResponse RegResponse;
		try {
			RegResponse = portalUMEImpl.initPortalUser(registrationRequest);
		
		} catch (ConnectorException e) {
			// TODO Auto-generated catch block
			  SimpleLogger.log(Severity.ERROR, Category.SYS_SERVER, loc, "PortalDetailsResponseImpl.initialiseUser",   "Call PortalJcoImpl with request of " + PortalServiceUtils.converToJson(registrationRequest)); 
              SimpleLogger.traceThrowable(Severity.ERROR, loc, "", e);
              RegResponse = new RegistrationResponse();
              RegResponse.setErrCode(AppConstants.ERROR_CODE_JCO_EXCETPION);
              RegResponse.setErrReason(AppConstants.CALL_LEASEPLAN);
     	}
		return  RegResponse;
	}
	
	
	/* (non-Javadoc)
	 * @see com.lp.portalService.service.PortalDetailsResponse#verifyInitialUser(com.lp.portalService.model.RegistrationRequest)
	 */
	public RegistrationResponse verifyInitialUser(final RegistrationRequest registrationRequest){
		RegistrationResponse RegResponse;
		try {
			RegResponse = portalUMEImpl.VerifyInitPortalUser(registrationRequest);
		} catch (ConnectorException e) {
			// TODO Auto-generated catch block
			  SimpleLogger.log(Severity.ERROR, Category.SYS_SERVER, loc, "PortalDetailsResponseImpl.initialiseUser",   "Call PortalJcoImpl with request of " + PortalServiceUtils.converToJson(registrationRequest)); 
              SimpleLogger.traceThrowable(Severity.ERROR, loc, "", e);
              RegResponse = new RegistrationResponse();
              RegResponse.setErrCode(AppConstants.ERROR_CODE_JCO_EXCETPION);
              RegResponse.setErrReason(AppConstants.CALL_LEASEPLAN);
     	}
		return  RegResponse;
	}
	
	/* (non-Javadoc)
	 * @see com.lp.portalService.service.PortalDetailsResponse#testJcoconnection(com.lp.portalService.model.RegistrationRequest)
	 */
	public RegistrationResponse testJcoconnection(final RegistrationRequest registrationRequest){
		RegistrationResponse RegResponse;
		try {
			RegResponse = portalUMEImpl.initPortalUser(registrationRequest);
		} catch (ConnectorException e) {
			// TODO Auto-generated catch block
			  SimpleLogger.log(Severity.ERROR, Category.SYS_SERVER, loc, "PortalDetailsResponseImpl.initialiseUser",   "Call PortalJcoImpl with request of " + PortalServiceUtils.converToJson(registrationRequest)); 
              SimpleLogger.traceThrowable(Severity.ERROR, loc, "", e);
              RegResponse = new RegistrationResponse();
              RegResponse.setErrCode(AppConstants.ERROR_CODE_JCO_EXCETPION);
              RegResponse.setErrReason(AppConstants.CALL_LEASEPLAN);
     	}
		return  RegResponse;
	}
	
	/* (non-Javadoc)
	 * @see com.lp.portalService.service.PortalDetailsResponse#RegisterEncryptSession(com.lp.portalService.model.RegistrationRequest)
	 */
	public RegistrationResponse  registerEncryptSession(final RegistrationRequest registrationRequest){
		
		RegistrationResponse RegResponse;
		try {
			RegResponse = portalUMEImpl.getEncryptPwd(registrationRequest.getEmailAddress());
		} catch (ConnectorException e) {
			// TODO Auto-generated catch block
			  SimpleLogger.log(Severity.ERROR, Category.SYS_SERVER, loc, "PortalDetailsResponseImpl.registerEncryptSession",   "Call PortalJcoImpl with request of " + PortalServiceUtils.converToJson(registrationRequest)); 
              SimpleLogger.traceThrowable(Severity.ERROR, loc, "", e);
              RegResponse = new RegistrationResponse();
              RegResponse.setErrCode(AppConstants.ERROR_CODE_JCO_EXCETPION);
              RegResponse.setErrReason(AppConstants.CALL_LEASEPLAN);
              return RegResponse;
     	}
		httpSession.setAttribute("encryptSession", RegResponse.getToken());
		return  RegResponse;
	}
	
  	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.lp.portalService.service.PortalDetailsResponse#getEncryptSession()
	 */
	public String getEncryptSession() {
		return (httpSession.getAttribute("encryptSession") != null) ? httpSession.getAttribute("encryptSession").toString() : null;
	}
	
	public void killSession() {
		httpSession.setAttribute("encryptSession", null);
	}
	
	public void switchGoogleAPI(String indicator) {
		AppData.googleAPI = indicator;
	}
   
	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.lp.portalService.service.PortalDetailsResponse#checkEncryptSession
	 * (com.lp.portalService.model.RegistrationRequest)
	 */
	public RegistrationResponse checkEncryptSession(
			RegistrationRequest registrationRequest) {
		RegistrationResponse RegResponse = new RegistrationResponse();
		String sessionValue = getEncryptSession();
		if (sessionValue == null) {
			RegResponse.setReturnUME(AppConstants.RETURN_UME_FALSE);
			RegResponse.setErrCode(AppConstants.ERROR_CODE_SESSIONLOST);
			RegResponse.setErrReason(AppConstants.MSG_SESSION_LOST);
		} else {
			try {
				RegResponse = portalUMEImpl.getEncryptPwd(registrationRequest
						.getEmailAddress());
				RegResponse.setGroupType(portalUMEImpl.checkGroup(registrationRequest
						.getEmailAddress()));
				
				
			} catch (ConnectorException e) {
				// TODO Auto-generated catch block
				SimpleLogger.log(
						Severity.ERROR,
						Category.SYS_SERVER,
						loc,
						"PortalDetailsResponseImpl.checkEncryptSession",
						"Call PortalJcoImpl with request of "
								+ PortalServiceUtils
										.converToJson(registrationRequest));
				SimpleLogger.traceThrowable(Severity.ERROR, loc, "", e);
				RegResponse = new RegistrationResponse();
				RegResponse.setErrCode(AppConstants.ERROR_CODE_JCO_EXCETPION);
				RegResponse.setErrReason(AppConstants.CALL_LEASEPLAN);
				RegResponse.setReturnUME(AppConstants.RETURN_UME_FALSE);
				return RegResponse;
			}
			
			if (sessionValue.equals(RegResponse.getToken())) {
				SimpleLogger.trace(Severity.INFO,loc," sessionValue is  :"+ sessionValue + " Token is " +  RegResponse.getToken());        
				RegResponse.setReturnUME(AppConstants.RETURN_UME_TRUE);
			} else {
				SimpleLogger.trace(Severity.INFO,loc," failed sessionValue is  :"+ sessionValue + " Token is " +  RegResponse.getToken()); 
				RegResponse.setReturnUME(AppConstants.RETURN_UME_FALSE);
				RegResponse.setErrCode(AppConstants.ERROR_CODE_INCORRECT_ENCRYPTPWD);
				RegResponse.setErrReason(AppConstants.MSG_PWD_INCORRECT);
			}
		}
		return RegResponse;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.lp.portalService.service.PortalDetailsResponse#
	 * checkCompleteRegisterPermission
	 * (com.lp.portalService.model.RegistrationRequest)
	 */
	public RegistrationResponse checkCompleteRegisterPermission(
			RegistrationRequest registrationRequest) {
		RegistrationResponse RegResponse = new RegistrationResponse();
		String logonId = registrationRequest.getEmailAddress();
		String groupType = portalUMEImpl.checkGroup(logonId);
		SimpleLogger.trace(Severity.INFO,loc,"checkCompleteRegisterPermission groupType is  :"+ groupType );   
		if (groupType.equalsIgnoreCase(AppConstants.SELF_COMPLETED_GROUP_TYPE)
				|| groupType
						.equalsIgnoreCase(AppConstants.SELF_PENDING_GROUP_TYPE) ) {
			//additional check for pending group
			if (groupType.equalsIgnoreCase(AppConstants.SELF_PENDING_GROUP_TYPE)){
			    if (portalUMEImpl.checkDriverGroup(logonId)){
			    	RegistrationResponse RegResponseUME;
					try {
						RegResponseUME = portalUMEImpl.assignApprovalGroup(logonId);
						if (AppConstants.RETURN_UME_TRUE.equalsIgnoreCase(RegResponseUME.getReturnUME())){
							portalUMEImpl.removeGroup(logonId, AppConstants.SELF_PENDING_GROUP);
							groupType = AppConstants.SELF_APPROVAL_GROUP_TYPE;
						}
					} catch (ConnectorException ec) {
						  SimpleLogger.log(Severity.ERROR, Category.SYS_SERVER, loc, "PortalDetailsResponseImpl.checkCompleteRegisterPermission",   "Call PortalJcoImpl with request of " + PortalServiceUtils.converToJson(registrationRequest)); 
			              SimpleLogger.traceThrowable(Severity.ERROR, loc, "", ec);
			   
					}
			    }
			  }
			//end additional check
	    	}
			// login validation
			
			if (groupType.equalsIgnoreCase(AppConstants.SELF_COMPLETED_GROUP_TYPE)
					|| groupType
					.equalsIgnoreCase(AppConstants.SELF_PENDING_GROUP_TYPE)){
			try {
				RegResponse = portalUMEImpl.validateAccount(
						registrationRequest.getEmailAddress(),
						registrationRequest.getPassword());
				if (AppConstants.RETURN_UME_TRUE.equals(RegResponse.getReturnUME())){ // if pass validation ,set encryptSession with token 
					httpSession.setAttribute("encryptSession", RegResponse.getToken());
				}
				
			} catch (ConnectorException e) {
				// TODO Auto-generated catch block
				SimpleLogger
						.log(Severity.ERROR,
								Category.SYS_SERVER,
								loc,
								"PortalDetailsResponseImpl.checkCompleteRegisterPermission",
								"Call PortalJcoImpl with request of "
										+ PortalServiceUtils
												.converToJson(registrationRequest));
				SimpleLogger.traceThrowable(Severity.ERROR, loc, "", e);
				RegResponse = new RegistrationResponse();
				RegResponse.setErrCode(AppConstants.ERROR_CODE_JCO_EXCETPION);
				RegResponse.setErrReason(AppConstants.CALL_LEASEPLAN);
				return RegResponse;
			}

		} else {
			RegResponse.setErrCode(AppConstants.ERROR_CODE_PERMISSION_DENY);
			RegResponse.setErrReason(AppConstants.MSG_DENY);
			RegResponse.setReturnUME(AppConstants.RETURN_UME_FALSE);
			RegResponse.setGroupType(groupType);
			//as initial group will set up cookie for providing possibility recording email sending information
		   if (groupType.equalsIgnoreCase(AppConstants.SELF_INIT_GROUP_TYPE)){
		    //set logon id cookie
			   Cookie logonIdCookie = new Cookie("selfRegLogonId", logonId);
			   	//setting max age to be 30 mins
			   logonIdCookie.setMaxAge(30*60);
			   logonIdCookie.setPath("/");
			   httpResponse.addCookie(logonIdCookie);  
			   
			   //set session for security
			   RegistrationResponse RegResponseValidateAccount = new RegistrationResponse();
			   try {
				   RegResponseValidateAccount = portalUMEImpl.validateAccount(logonId,registrationRequest.getPassword());
				if (AppConstants.RETURN_UME_TRUE.equals(RegResponseValidateAccount.getReturnUME())){ // if pass validation ,set encryptSession with token 
					httpSession.setAttribute("encryptSessionInitial", RegResponseValidateAccount.getToken());
				}
			   
				} catch (ConnectorException e) {
					SimpleLogger.log(Severity.ERROR,Category.SYS_SERVER,
							loc,
							"PortalDetailsResponseImpl.checkCompleteRegisterPermission.checkAccountValidation-initial","Call PortalJcoImpl with request of "+ PortalServiceUtils
											.converToJson(registrationRequest));
						SimpleLogger.traceThrowable(Severity.ERROR, loc, "", e);;
				}
				
		   }		
			//ending 
			//as approval group first login set department as "Driver" for indicator as user login 
            if (groupType.equalsIgnoreCase(AppConstants.SELF_APPROVAL_GROUP_TYPE)){
            	RegistrationResponse RegResponseValidateAccount = new RegistrationResponse();
            	try {
            		
            		RegResponseValidateAccount = portalUMEImpl.validateAccount(logonId,registrationRequest.getPassword());
				} catch (ConnectorException e) {
					SimpleLogger.log(Severity.ERROR,Category.SYS_SERVER,
							loc,
							"PortalDetailsResponseImpl.checkCompleteRegisterPermission.checkAccountValidation-Approval","Call PortalJcoImpl with request of "+ PortalServiceUtils
											.converToJson(registrationRequest));
						SimpleLogger.traceThrowable(Severity.ERROR, loc, "", e);
				}
				if (AppConstants.RETURN_UME_TRUE.equals(RegResponseValidateAccount.getReturnUME())){ // if pass validation, update Department value as indicator
					//httpSession.setAttribute("encryptSession", RegResponse.getToken());
					portalUMEImpl.updateUserDepartment(logonId);
				}
	        
            }
		}
		
		RegResponse.setGroupType(groupType);
		return RegResponse;
	}
	
	
	public String getGoogleGeoTest(String request){
		
		SocketAddress addr = new
				InetSocketAddress("lpautmg0001.ap.leaseplancorp.net", 8080);
				Proxy proxy = new Proxy(Proxy.Type.HTTP, addr);
		   GeoApiContext context = new GeoApiContext.Builder().proxy(proxy)
	       .apiKey("AIzaSyB-W0s81dBYgPLFIhPLrI7wv-vmJJPYTbg")
	      .build();
	 	   InetAddress Ip = null;
		   
		   try {
			Ip = InetAddress.getLocalHost();
				SimpleLogger.trace(Severity.INFO,loc,"getGoogleGeoTest ip is  :"+Ip );     
		
		   } catch (UnknownHostException e1) {
		
			SimpleLogger.traceThrowable(Severity.ERROR, loc, "", e1);
		}
	      GeocodingResult[] results;
	      
	      String trn = "";
		try {
			results = GeocodingApi.geocode(context,
					    request).await();
		
			Gson gson = new GsonBuilder().setPrettyPrinting().create();
		//	System.out.println(gson.toJson(results[0].addressComponents));
		     
    		trn =gson.toJson(results[0].addressComponents);
		} catch (ApiException | InterruptedException | IOException e) {
			// TODO Auto-generated catch block
		//	e.printStackTrace();
		//	ApiException.from(status, errorMessage)
			SimpleLogger.traceThrowable(Severity.ERROR, loc, "", e);
		}
	   	return trn;
	}
   
}
