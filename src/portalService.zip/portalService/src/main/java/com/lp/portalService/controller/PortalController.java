/**
 * <h1>Portal Service Controller</h1>
 * Handle request from self registration Presentation layer or any other possibilities request to portal service.There are 4 services exposed to public as phase 1.
 * <p>
 * Service handler -- https://domain/portalService/checkEmail 
 *  @param 	json {"emailAddress":""} 
 *  @return json {"customerUID": null,"emailAddress": null,"customerNumber": null,"customerDesc": null,"customerDescLong": null,"customerDescName": "","returnCRM": null,"customerTxt": null,
 *  		"errReason": null,"errCode": null,"appstatus": null}
 *	a) check if the given email domain has a single customer number. If so, also return description of
 *     customer number. i.e pre-populate user screens with the name of the Customer Number.
 *  b) Check if the given email address has a registration in progress, or has already
 *     completed registration.
 * <P>
 * Service handler-- https://domain/portalService/checkCustomerNumber
 * @param   json {"emailAddress":"","customerNumber":""} 
 * @return  json {"customerUID": null,"emailAddress": null,"customerNumber": null,"customerDesc": null,"customerDescLong": null,"customerDescName": "","returnCRM": null,"customerTxt": null,
 *  		"errReason": null,"errCode": null,"appstatus": null} 
 * a) The provided email address is eligible to register against the customer number
 *    in the case where a customer might have a restricted domain.
 * b) Also return the customer number description of the provided CN regardless of whether or
 *    not the customer email is eligible to register against that customer.
 * <P>       
 * Service handler -- https://domain/portalService/registerCustomer
 * <P>
 * Service handler -- https://domain/portalService/validateWorkEmail
 * 
 * @author taowe
 * @version 1.0
 * @since  10-Nov-2016 
 * 
 */

package com.lp.portalService.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.lp.portalService.model.RegistrationRequest;
import com.lp.portalService.model.RegistrationResponse;
import com.lp.portalService.service.PortalDetailsResponse;
import com.lp.portalService.utils.AppData;


@Controller
@CrossOrigin
public class PortalController {
	
	@Autowired 
	private PortalDetailsResponse portalDetailsResponse;

	@RequestMapping(value = "/checkEmail", method = RequestMethod.POST,headers="Accept=application/json")
    public @ResponseBody RegistrationResponse checkEmail(@RequestBody RegistrationRequest registrationRequest) throws Throwable  {		
	     	RegistrationResponse regResponse = portalDetailsResponse.checkEmail(registrationRequest);                			
			return regResponse;
	}
	
	@RequestMapping(value = "/checkCustomerNumber", method = RequestMethod.POST,headers="Accept=application/json")
    public @ResponseBody RegistrationResponse checkCustomerNumber(@RequestBody RegistrationRequest registrationRequest) throws Throwable  {		
	        RegistrationResponse regResponse = portalDetailsResponse.checkCustomerNumber(registrationRequest);                			
			return regResponse;
	}
	
	@RequestMapping(value = "/validateWorkEmail", method = RequestMethod.POST,headers="Accept=application/json")
    public @ResponseBody RegistrationResponse validateWorkEmailr(@RequestBody RegistrationRequest registrationRequest) throws Throwable  {		
	     	RegistrationResponse regResponse = portalDetailsResponse.validateWorkEmail(registrationRequest);                			
			return regResponse;
	}
	
	@RequestMapping(value = "/registerCustomer", method = RequestMethod.POST,headers="Accept=application/json")
    public @ResponseBody RegistrationResponse registerCustomer(@RequestBody RegistrationRequest registrationRequest) throws Throwable  {		
	     	RegistrationResponse regResponse = portalDetailsResponse.registerCustomer(registrationRequest);                			
			return regResponse;
	}
	
	@RequestMapping(value = "/initialiseUser", method = RequestMethod.POST,headers="Accept=application/json")
    public @ResponseBody RegistrationResponse initialiseUser(@RequestBody RegistrationRequest registrationRequest) throws Throwable  {		
		
	     	RegistrationResponse regResponse = portalDetailsResponse.initialiseUser(registrationRequest);                			
			return regResponse;
	}
	
	@RequestMapping(value = "/verifyInitialUser", method = RequestMethod.POST,headers="Accept=application/json")
    public @ResponseBody RegistrationResponse verifyInitialUser(@RequestBody RegistrationRequest registrationRequest) throws Throwable  {
	     	RegistrationResponse regResponse = portalDetailsResponse.verifyInitialUser(registrationRequest);                			
			return regResponse;
	}
	
	//register Session as per login id 
	@RequestMapping(value = "/registerSession", method = RequestMethod.POST,headers="Accept=application/json")
	public @ResponseBody RegistrationResponse registerSession(@RequestBody RegistrationRequest registrationRequest) throws Throwable  {		
	     	RegistrationResponse regResponse = portalDetailsResponse.registerEncryptSession(registrationRequest);                			
			return regResponse;
	}
	//return UME = true pass/
	//return UME = false , with error code 0989 for session lost / 0988 for failed to validate token
	@RequestMapping(value = "/checkEncryptToken", method = RequestMethod.POST,headers="Accept=application/json")
	public @ResponseBody RegistrationResponse checkEncrptToken(@RequestBody RegistrationRequest registrationRequest) throws Throwable  {		
	     	RegistrationResponse regResponse = portalDetailsResponse.checkEncryptSession(registrationRequest);                			
			return regResponse;
	}
	
	//check if login user has permission to go complete register as per user's existing role assigned on portal 
	@RequestMapping(value = "/checkCompleteRegisterPermission", method = RequestMethod.POST,headers="Accept=application/json")
	public @ResponseBody RegistrationResponse checkCompleteRegisterPermission(@RequestBody RegistrationRequest registrationRequest) throws Throwable  {		
	     	RegistrationResponse regResponse = portalDetailsResponse.checkCompleteRegisterPermission(registrationRequest);                			
			return regResponse;
	}
	
	///password resetting
	@RequestMapping(value = "/verifyToken", method = RequestMethod.POST,headers="Accept=application/json")
    public @ResponseBody RegistrationResponse verifyToken(@RequestBody RegistrationRequest registrationRequest) throws Throwable  {		
	     	RegistrationResponse regResponse = portalDetailsResponse.verifyToken(registrationRequest);                			
			return regResponse;
	}

	///address check
	@RequestMapping(value = "/verifyAddress", method = RequestMethod.POST,headers="Accept=application/json")
    public @ResponseBody RegistrationResponse verifyAddress(@RequestBody RegistrationRequest registrationRequest) throws Throwable  {		
	     	RegistrationResponse regResponse = portalDetailsResponse.verifyAddress(registrationRequest);                			
			return regResponse;
	}
	
	@RequestMapping(value = "/updatePassword", method = RequestMethod.POST,headers="Accept=application/json")
    public @ResponseBody RegistrationResponse updatePassword(@RequestBody RegistrationRequest registrationRequest) throws Throwable  {		
	     	RegistrationResponse regResponse = portalDetailsResponse.updatePassword(registrationRequest);    
	     	return regResponse;
	}

	@RequestMapping(value = "/verifyEmailActivation", method = RequestMethod.POST,headers="Accept=application/json")
    public @ResponseBody RegistrationResponse verifyEmailActivation(@RequestBody RegistrationRequest registrationRequest) throws Throwable  {		
	     	RegistrationResponse regResponse = portalDetailsResponse.verifyEmailActivation(registrationRequest);    
	     	return regResponse;
	}
	
	
	@RequestMapping(value = "/setGoogleAPI/{callName}", method = RequestMethod.GET,headers="Accept=text/plain")
    public @ResponseBody String switchGoogleAPI(@PathVariable("callName") String callName) throws Throwable  {
		portalDetailsResponse.switchGoogleAPI(callName);
		return "GOOGLE GEO API IS SWHITCH TO "+ AppData.googleAPI +" TURE MEANS AVAILABLE FALSE MEANS DISABLED";  
	}
	

	@RequestMapping(value = "/sendVerifyEmail", method = RequestMethod.GET,headers="Accept=text/plain")
	public @ResponseBody String sendVerifyEmail() throws Throwable  {
	    RegistrationResponse regResponse = portalDetailsResponse.sendVerifyEmail(); 
	    String response =regResponse.getErrReason();	
		return response;
    }
	
	/*test only*/
	@RequestMapping(value = "/getGoogleAPI/{callName}",  method = RequestMethod.GET,headers="Accept=text/plain")
	public @ResponseBody String getGoogleAPI(@PathVariable("callName") String callName) throws Throwable  {	
	     	//RegistrationResponse regResponse = portalDetailsResponse.switchGoogleAPI(registrationRequest);    
		return AppData.googleAPI; 
	}
	
	/*test only*/
	@RequestMapping(value = "/sayhello/{callName}", method = RequestMethod.GET,headers="Accept=text/plain")
    public @ResponseBody String getSayHello(@PathVariable("callName") String callName) throws Throwable  {	
	  	return "Hello " +callName + " !";
	}
	
	/*test only*/
	@RequestMapping(value = "/testSession/{callName}", method = RequestMethod.GET,headers="Accept=text/plain")
    public @ResponseBody String testSession(@PathVariable("callName") String callName) throws Throwable  {
	   	
	    if ("killSession".equalsIgnoreCase(callName)){
	    	portalDetailsResponse.killSession();
	    }
		String sessionValue = portalDetailsResponse.getEncryptSession(); 
	  	return "Hello " +callName + ", I got your session as it is  " + sessionValue ;
	}
	
	/*test only*/
	@RequestMapping(value = "/registerSessionTest/{callName}", method = RequestMethod.GET,headers="Accept=text/plain")
	public @ResponseBody String registerSessionTest(@PathVariable("callName") String callName) throws Throwable  {
		RegistrationRequest req = new RegistrationRequest();
		req.setEmailAddress(callName);
	     	RegistrationResponse regResponse = portalDetailsResponse.registerEncryptSession(req);       
	     	String sessionValue = portalDetailsResponse.getEncryptSession(); 
      return "Hello " +callName + " your session is " + sessionValue ;
	}
	
	/*test only*/
	@RequestMapping(value = "/getGoogleGeoTest/{callName}", method = RequestMethod.GET,headers="Accept=text/plain")
	public @ResponseBody String getGoogleGeoTest(@PathVariable("callName") String callName) throws Throwable  {
	  String rtn = portalDetailsResponse.getGoogleGeoTest("callName");       
      return "Hello " +callName + " result " + rtn ;
	}
	
}
