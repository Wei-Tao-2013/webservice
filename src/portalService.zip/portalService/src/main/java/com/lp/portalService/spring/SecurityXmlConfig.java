package com.lp.portalService.spring;

import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.ImportResource;

/*@Configuration
@ImportResource({ "classpath:webSecurityConfig.xml" })
@ComponentScan("com.lp.portalService.spring")*/
public class SecurityXmlConfig {

	public SecurityXmlConfig() {
        super();
    }

}
