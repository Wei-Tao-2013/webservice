/**
 * 
 */
/**
 * @author taowe
 *
 */
package com.lp.connector.impl;