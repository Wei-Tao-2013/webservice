package com.lp.connector;

import com.lp.connector.exception.ConnectorException;
import com.lp.connector.model.SAPConnectorRequest;
import com.lp.connector.model.SAPConnectorResponse;
import com.sap.security.api.AttributeValueAlreadyExistsException;
import com.sap.security.api.NoSuchRoleException;
import com.sap.security.api.NoSuchUserAccountException;
import com.sap.security.api.NoSuchUserException;
import com.sap.security.api.UMException;
import com.sap.security.api.UMRuntimeException;
import com.sap.security.api.UserAccountAlreadyExistsException;
import com.sap.security.api.UserAlreadyExistsException;

public interface SAPConnector {

	public abstract SAPConnectorResponse callCustomerValidation(
			SAPConnectorRequest SAPConnectData) throws ConnectorException;
	
	public abstract SAPConnectorResponse callMandatoryIndicator(
			SAPConnectorRequest SAPConnectData) throws ConnectorException;
	
	public abstract SAPConnectorResponse callAddressCheck(
			SAPConnectorRequest SAPConnectData) throws ConnectorException;

	public abstract SAPConnectorResponse callCustomerRegistration(
			SAPConnectorRequest SAPConnectData) throws ConnectorException;

	public abstract SAPConnectorResponse callWorkEamilValiation(
			SAPConnectorRequest SAPConnectData) throws ConnectorException;
	
	public abstract SAPConnectorResponse callInitEmailVerification(
			SAPConnectorRequest SAPConnectData) throws ConnectorException;
	
	
	public abstract SAPConnectorResponse callVerifyToken(
			SAPConnectorRequest SAPConnectData) throws ConnectorException;
	
	
	public abstract SAPConnectorResponse callVerifyEmailActivation(
			SAPConnectorRequest SAPConnectData) throws ConnectorException;
	
	
	public abstract SAPConnectorResponse callUpdatePassword(
			SAPConnectorRequest SAPConnectData) throws ConnectorException;
	
	
	/*test only*/
	public abstract SAPConnectorResponse callCustomerValidationTest(
			SAPConnectorRequest SAPConnectData) throws ConnectorException;
}
