/**
 * 
 */
/**
 * @author taowe
 *
 */
package com.lp.connector.utils;