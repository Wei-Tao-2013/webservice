package com.anonym.simulator.robot;

import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;
import org.junit.Assert;
import org.junit.Test;
import com.anonym.simulator.robot.simulator.Location;
import com.anonym.simulator.robot.simulator.Matrix;


public class MatrixTest {
	
	    @Test
	    public void testIsInMatrix() throws Exception {
	        Matrix matrix = new Matrix(4, 5);
	        Location mockLocation = mock(Location.class);
	        
	        when(mockLocation.getX()).thenReturn(4);
	        when(mockLocation.getY()).thenReturn(5);

	        Assert.assertTrue(matrix.isInMatrix(mockLocation));

	        when(mockLocation.getX()).thenReturn(-1);
	        when(mockLocation.getY()).thenReturn(-1);
	        Assert.assertFalse(matrix.isInMatrix(mockLocation));
	        
	        when(mockLocation.getX()).thenReturn(0);
	        when(mockLocation.getY()).thenReturn(0);
	        Assert.assertTrue(matrix.isInMatrix(mockLocation));
	        
	        when(mockLocation.getX()).thenReturn(5);
	        when(mockLocation.getY()).thenReturn(4);
	        Assert.assertFalse(matrix.isInMatrix(mockLocation));
	        
	    }
	 

}
