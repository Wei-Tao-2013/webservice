package com.anonym.simulator.robot;

import org.junit.Assert;
import org.junit.Test;

import com.anonym.simulator.robot.simulator.FacingDirection;


public class FacingDirectionTest {

    @Test
    public void testFacingTurning() throws Exception {
    	FacingDirection direction = FacingDirection.NORTH;
        direction = direction.rightDirection();
        Assert.assertEquals(direction, FacingDirection.EAST);

        direction = direction.rightDirection();
        Assert.assertEquals(direction, FacingDirection.SOUTH);

        direction = direction.rightDirection();
        Assert.assertEquals(direction, FacingDirection.WEST);

        direction = direction.rightDirection();
        Assert.assertEquals(direction, FacingDirection.NORTH);
       
        direction = direction.leftDirection();
        Assert.assertEquals(direction, FacingDirection.WEST);

        direction = direction.leftDirection();
        Assert.assertEquals(direction, FacingDirection.SOUTH);

        direction = direction.leftDirection();
        Assert.assertEquals(direction, FacingDirection.EAST);

        direction = direction.leftDirection();
        Assert.assertEquals(direction, FacingDirection.NORTH);
    }
}
