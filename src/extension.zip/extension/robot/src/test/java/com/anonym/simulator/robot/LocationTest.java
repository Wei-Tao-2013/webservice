package com.anonym.simulator.robot;

import static org.hamcrest.CoreMatchers.containsString;
import static org.junit.Assert.assertThat;
import static org.junit.Assert.fail;

import org.junit.Assert;
import org.junit.Test;

import com.anonym.simulator.robot.exception.SimulatorException;
import com.anonym.simulator.robot.simulator.FacingDirection;
import com.anonym.simulator.robot.simulator.Location;

public class LocationTest {
	
	@Test
    public void testNewLocation() throws Exception {
        Location location = new Location(0, 0, FacingDirection.NORTH);
        Assert.assertEquals(location.getX(), 0);
        Assert.assertEquals(location.getY(), 0);
        Assert.assertEquals(location.getFacing(), FacingDirection.NORTH);
    }

    @Test
    public void testGetNextLocation() throws Exception {
        Location location = new Location(0, 0, FacingDirection.EAST);
        Location nextLocation = location.getNewLocation(); // move one step
        Assert.assertEquals(nextLocation.getX(), 1);
        Assert.assertEquals(nextLocation.getY(), 0);
        Assert.assertEquals(nextLocation.getFacing(), FacingDirection.EAST);
        nextLocation = nextLocation.getNewLocation(); // move one step
        Assert.assertNotEquals(nextLocation.getX(), 1);
        Assert.assertNotEquals(nextLocation.getY(), 1);
        Assert.assertNotEquals(nextLocation.getFacing(), FacingDirection.NORTH);

    }
    
    @Test
    public void testChangeFacing() throws Exception {
        Location location = new Location(0, 0, FacingDirection.WEST);
        location.setFacing(FacingDirection.NORTH);
        Assert.assertEquals(location.getFacing(), FacingDirection.NORTH);
        location.setFacing(FacingDirection.EAST);
        Assert.assertEquals(location.getFacing(), FacingDirection.EAST);
   
    }
    
    @Test
    public void testSimulatorException() throws Exception {
    	try{
    		Location location = new Location(0, 0, null);
    		location.getNewLocation(); 
    		fail("expecting SimulatorException");
    	}catch (SimulatorException e) {
    	      assertThat(e.getMessage(), containsString(SimulatorConstants.ERROR_ROBOT_NOT_INIT));
        }
    	
    }
    
   
   
    
    
}
