package com.anonym.simulator.robot;
import org.junit.Assert;
import org.junit.Test;
import com.anonym.simulator.robot.exception.SimulatorException;
import com.anonym.simulator.robot.simulator.FacingDirection;
import com.anonym.simulator.robot.simulator.Location;
import com.anonym.simulator.robot.simulator.Robot;

public class RobotTest {
	
    @Test
    public void testMove() throws SimulatorException {
        Robot robot = new Robot(new Location(0, 0, FacingDirection.EAST));
        Assert.assertTrue(robot.move());
        Assert.assertEquals(1, robot.getLocation().getX());
        Assert.assertEquals(0, robot.getLocation().getY());
        Assert.assertEquals(FacingDirection.EAST, robot.getLocation().getFacing());
    }
    
    
    @Test 
    public void testTurnLeft() throws SimulatorException {

        Robot robot = new Robot(new Location(1, 1, FacingDirection.EAST));
        robot.trunLeft();
        Assert.assertEquals(1, robot.getLocation().getX());
        Assert.assertEquals(1, robot.getLocation().getY());
        Assert.assertEquals(FacingDirection.NORTH, robot.getLocation().getFacing());
        robot.trunLeft();
        Assert.assertEquals(1, robot.getLocation().getX());
        Assert.assertEquals(1, robot.getLocation().getY());
        Assert.assertEquals(FacingDirection.WEST, robot.getLocation().getFacing());
        
    }
    @Test
    public void testTurnRight() throws SimulatorException {
        Robot robot = new Robot(new Location(1, 1, FacingDirection.EAST));
        robot.trunRight();
        Assert.assertEquals(1, robot.getLocation().getX());
        Assert.assertEquals(1, robot.getLocation().getY());
        Assert.assertEquals(FacingDirection.SOUTH, robot.getLocation().getFacing());
        robot.trunRight();
        Assert.assertEquals(1, robot.getLocation().getX());
        Assert.assertEquals(1, robot.getLocation().getY());
        Assert.assertEquals(FacingDirection.WEST, robot.getLocation().getFacing());
      
    }
  
}