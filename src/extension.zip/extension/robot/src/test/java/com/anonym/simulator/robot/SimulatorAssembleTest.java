package com.anonym.simulator.robot;
import static org.hamcrest.CoreMatchers.containsString;
import static org.junit.Assert.assertThat;
import static org.junit.Assert.fail;
import org.junit.Assert;
import org.junit.Before;

import org.junit.Test;


import com.anonym.simulator.robot.exception.SimulatorException;
import com.anonym.simulator.robot.simulator.Matrix;
import com.anonym.simulator.robot.simulator.Robot;


public class SimulatorAssembleTest {

    final int MATRIX_WIDTH = 5;
    final int MATRIX_LENGTH = 5;
    Matrix playTable;
 	
    @Before
	public void setUp() throws Exception {
    	playTable = new Matrix(MATRIX_WIDTH, MATRIX_LENGTH);
	}
	
    
    @Test // test all cases of read file
    public void testReadFile()  throws SimulatorException {
        Robot toyRobot = new Robot();
     
        SimulatorAssemble simulator = new SimulatorAssemble(playTable, toyRobot);
        
        // test correct file
        String result = simulator.readCommandFile("READ simulator-commands.txt");
        Assert.assertTrue(result.length()>0);
       
        // test if Invalid command name for reading file
     	try{
            simulator.readCommandFile("READ");
        	 fail("expecting SimulatorException");
           	}catch (SimulatorException e) {
     	      assertThat(e.getMessage(), containsString(SimulatorConstants.ERROR_INVALID_READ_COMMAND));
         }
     	// test if read unsupport file
     	try{
            simulator.readCommandFile("READ simulator-unsupport-format.xml");
        	 fail("expecting SimulatorException");
           	}catch (SimulatorException e) {
     	      assertThat(e.getMessage(), containsString(SimulatorConstants.ERROR_UNSUPPORT_FILE));
         }
     	
     	//test if empty file
     	try{
            simulator.readCommandFile("READ empty-commands.txt");
        	 fail("expecting SimulatorException");
           	}catch (SimulatorException e) {
     	      assertThat(e.getMessage(), containsString(SimulatorConstants.ERROR_EMETYP_FILE));
         }
     	
     	//test if not not file
     	try{
            simulator.readCommandFile("READ not-found.txt");
        	 fail("expecting SimulatorException");
           	}catch (SimulatorException e) {
     	      assertThat(e.getMessage(), containsString(SimulatorConstants.ERROR_FILE_NOT_FOUND));
         }
    
    }

    @Test  // test method of takeAction
    public void testTakeAction()  throws SimulatorException {
        Robot toyRobot = new Robot();
     
        SimulatorAssemble simulator = new SimulatorAssemble(playTable, toyRobot);

        simulator.takeAction("PLACE 0,0,NORTH,Ella");
        Assert.assertTrue(simulator.takeAction("REPORT").contains("0,0,NORTH"));

        simulator.takeAction("PLACE 0,0,NORTH");
        Assert.assertTrue(simulator.takeAction("REPORT").contains("0,0,NORTH"));
      
        simulator.takeAction("MOVE");
        simulator.takeAction("RIGHT");
        simulator.takeAction("MOVE");
        simulator.takeAction("LEFT");
        simulator.takeAction("MOVE");
        Assert.assertTrue(simulator.takeAction("REPORT").contains("1,2,NORTH"));
      
        // if command makes it falling off the table will ignore the command
        for (int i = 0; i < 10; i++)
        simulator.takeAction("MOVE");
        Assert.assertTrue(simulator.takeAction("REPORT").contains("1,5,NORTH"));
        
        //turning it's facing
        for (int i = 0; i < 10; i++)
        simulator.takeAction("LEFT");
        Assert.assertTrue(simulator.takeAction("REPORT").contains("1,5,SOUTH") );
    }
    
    @Test // test all cases of invalid commands input
    public void testInvalidCommand() throws SimulatorException {
    	Robot toyRobot = new Robot();
    	SimulatorAssemble simulator = new SimulatorAssemble(playTable, toyRobot);
    
    	// test location if initialize
    	try{
         simulator.takeAction("MOVE");
     	 fail("expecting SimulatorException");
        	}catch (SimulatorException e) {
  	      assertThat(e.getMessage(), containsString(SimulatorConstants.ERROR_NOT_INIT_LOC));
        }
    	
     	// test if command incorrect
     	try{
            simulator.takeAction("RIGHTT");
        	 fail("expecting SimulatorException");
           	}catch (SimulatorException e) {
     	      assertThat(e.getMessage(), containsString(SimulatorConstants.ERROR_INVALID_COMMAND));
           }
     	
     	// test if place command incorrect
    	try{
            simulator.takeAction("PLACE 1,1,NORTH WEST");
        	 fail("expecting SimulatorException");
           	}catch (SimulatorException e) {
     	      assertThat(e.getMessage(), containsString(SimulatorConstants.ERROR_INVALID_COMMAND + " PLACE"));
           }
    	
     	// test if place command format incorrect
    	try{
            simulator.takeAction("PLACE 1,s,NORTH");
        	 fail("expecting SimulatorException");
           	}catch (SimulatorException e) {
     	      assertThat(e.getMessage(), containsString(SimulatorConstants.ERROR_INVALID_FORMAT_LOC));
           }
    	}
  
}
