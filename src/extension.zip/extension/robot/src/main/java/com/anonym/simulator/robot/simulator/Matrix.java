package com.anonym.simulator.robot.simulator;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Stream;

public class Matrix {
	
	private int x;
	private int y;
	
	public Matrix(int x, int y) {
	    this.x = x;
	    this.y = y;
	}
	
	/**
	 * validate if robot is on the table
	 * @return true /false
	 */
	public boolean isInMatrix(Location location) {
	    return !(location.getX() > this.x || location.getX() < 0 || location.getY() > this.y || location.getY() < 0 );
	}

	public String drawMatrix(Map<String,Robot> hashRobot){
	  StringBuilder strBuilder = new StringBuilder();
	  strBuilder.append("\n");
	  List<Integer> xList = new ArrayList<Integer>();
	  List<Integer> yList = new ArrayList<Integer>();
	  
	  //listRobot.stream().forEach(robot->strBuilder.append("  "+robot.getRobotName()));

	  //hashRobot.forEach(robot->strBuilder.append("  "+robot.getRobotName()));
	  strBuilder.append(hashRobot.toString());
	  strBuilder.append("\n");
	  hashRobot.forEach((k,v)->
		strBuilder.append(k + " x ->"+ v.getLocation().getX() + "  y ->" + v.getLocation().getX()) );

	


	  strBuilder.append("\n");
	  for (int i = 0; i < this.x+1; i++)
		 xList.add(i);

	  for (int j = this.y; j>-1; j--)
		  yList.add(j);
	   xList.stream().forEach(xItem->strBuilder.append("   "+xItem));
	   strBuilder.append("\n");
        //flag = 0;
	   yList.stream().forEach(yItem->{
	   strBuilder.append(yItem+" ");
			  xList.stream().forEach(
				  xItem->{
                   
				//	listRobot.stream().forEach(robot->{ 
				//		if (robot.getLocation().getX()== xItem.intValue() && robot.getLocation().getY()==yItem.intValue()){
				//			strBuilder.append("["+robot.getRobotName()+" ] ");
                      //m int flag = 1;
				//		}
					
				//	});
					 // Stream<Robot> robotStream= listRobot.stream().filter(robot->robot.getLocation().getX()== xItem.intValue() && robot.getLocation().getY()== yItem.intValue());
					 // robotStream.forEach(i->strBuilder.append("[ "+ i.getRobotName()+ "] "));
					 int strLen = strBuilder.length();
					 hashRobot.forEach((k,v)->{
                         if ( v.getLocation().getX() == xItem.intValue() && v.getLocation().getY() == yItem.intValue()){

							strBuilder.append("[*] ");
						 }
                        
					 });
					 if (strLen ==strBuilder.length())
					    strBuilder.append("[ ] ");
					
					});
			  strBuilder.append("\n");
			}
	   );
	  
	  return strBuilder.toString();

	}

}
