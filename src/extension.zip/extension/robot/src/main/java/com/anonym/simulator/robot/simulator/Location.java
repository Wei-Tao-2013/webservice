package com.anonym.simulator.robot.simulator;
import com.anonym.simulator.robot.SimulatorConstants;
import com.anonym.simulator.robot.exception.SimulatorException;

public class Location {
	
    private int x;
    private int y;
    private FacingDirection facing;
    
    public int getX() {
        return this.x;
    }

    public int getY() {
        return this.y;
    }
    
    public FacingDirection getFacing() {
        return this.facing;
    }
    
    public void setFacing(FacingDirection facing) {
    	this.facing = facing;
    }
    
   
    public Location(int x, int y, FacingDirection facingDirection) {
        this.x = x;
        this.y = y;
        this.facing = facingDirection;
    }
    
    
    /**
	 * Set Location
	 */
    public Location(Location Location) {
        this.x = Location.getX();
        this.y = Location.getY();
        this.facing = Location.getFacing();
    }
    
    /**
	 * Move the robot one step as per direction
	 * @return Location
	 */
    public Location getNewLocation() throws SimulatorException {
        if (this.facing == null)
        	//Robot direction has not been initialized
            throw new SimulatorException(SimulatorConstants.ERROR_ROBOT_NOT_INIT);
        
        Location newloc = new Location(this);
	        switch (this.facing) {
	        case NORTH:
	        	newloc.move(0, 1);
	            break;
	        case EAST:
	        	newloc.move(1, 0);
	            break;
	        case SOUTH:
	        	newloc.move(0, -1);
	            break;
	        case WEST:
	        	newloc.move(-1, 0);
	            break;
		    }
        return newloc;
   
    }
    /**
	 * Move the robot one step in Matrix
	 */ 
    private void move(int x, int y) {
        this.x = this.x + x;
        this.y = this.y + y;
    }
}
