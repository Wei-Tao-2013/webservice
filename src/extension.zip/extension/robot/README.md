Toy Robot Simulator
===================

Description
-----------

- The application is a simulation of a toy robot moving on a square tabletop,
  of dimensions 5 units x 5 units.
- There are no other obstructions on the table surface.
- The robot is free to roam around the surface of the table, but must be
  prevented from falling to destruction. Any movement that would result in the
  robot falling from the table must be prevented, however further valid
  movement commands must still be allowed.
  
  Create an application that can read in commands of the following (textual) form:

    PLACE X,Y,F
    MOVE
    LEFT
    RIGHT
    REPORT

- PLACE will put the toy robot on the table in position X,Y and facing NORTH,
  SOUTH, EAST or WEST.
- The origin (0,0) can be considered to be the SOUTH WEST most corner.
- The first valid command to the robot is a PLACE command, after that, any
  sequence of commands may be issued, in any order, including another PLACE
  command. The application should discard all commands in the sequence until
  a valid PLACE command has been executed.
- MOVE will move the toy robot one unit forward in the direction it is
  currently facing.
- LEFT and RIGHT will rotate the robot 90 degrees in the specified direction
  without changing the position of the robot.
- REPORT will announce the X,Y and F of the robot. This can be in any form,
  but standard output is sufficient.

- A robot that is not on the table can choose the ignore the MOVE, LEFT, RIGHT
  and REPORT commands.
- Input can be from a file, or from standard input, as the developer chooses.
- Provide test data to exercise the application.
- The application must be a command line application.

Constraints
-----------

- The toy robot must not fall off the table during movement. This also
  includes the initial placement of the toy robot.
- Any move that would cause the robot to fall must be ignored.  

### Example a

    PLACE 0,0,NORTH
    MOVE
    REPORT

Expected output:

    0,1,NORTH

### Example b

    PLACE 0,0,NORTH
    LEFT
    REPORT

Expected output:

    0,0,WEST

### Example c

    PLACE 1,2,EAST
    MOVE
    MOVE
    LEFT
    MOVE
    REPORT

Expected output

    3,3,NORTH
    

Environments
-----------

- Implemented and tested using Java 8

- Project dependencies and compiling managed by Maven

- Tests require JUnit and Mockito


Application Installation Instructions & Configuration
-----------

No installation needed. No changes will be made to your system.
To get the application, uppack it as follows:
tar -xvzf robot_rea.tar.gz.

To run the app on Development Enviroment , you'll need:

- cd its directory

- Compile: `mvn compile`

- Run: `mvn exec:java`

To run tests of the app, you'll need:

- Test: `mvn test`

[INFO] Scanning for projects...
[INFO] 
[INFO] Using the builder org.apache.maven.lifecycle.internal.builder.singlethreaded.SingleThreadedBuilder with a thread count of 1
[INFO]                                                                         
[INFO] ------------------------------------------------------------------------
[INFO] Building Robot Simulator 0.0.1-SNAPSHOT
[INFO] ------------------------------------------------------------------------
[INFO] 
[INFO] --- maven-resources-plugin:2.6:resources (default-resources) @ robot ---
[INFO] Using 'UTF-8' encoding to copy filtered resources.
[INFO] Copying 3 resources
[INFO] 
[INFO] --- maven-compiler-plugin:2.3.2:compile (default-compile) @ robot ---
[INFO] Nothing to compile - all classes are up to date
[INFO] 
[INFO] --- maven-resources-plugin:2.6:testResources (default-testResources) @ robot ---
[INFO] Using 'UTF-8' encoding to copy filtered resources.
[INFO] skip non existing resourceDirectory /Users/anonym/robot/src/test/resources
[INFO] 
[INFO] --- maven-compiler-plugin:2.3.2:testCompile (default-testCompile) @ robot ---
[INFO] Nothing to compile - all classes are up to date
[INFO] 
[INFO] --- maven-surefire-plugin:2.12.4:test (default-test) @ robot ---
[INFO] Surefire report directory: /Users/anonym/robot/target/surefire-reports

-------------------------------------------------------
 T E S T S
-------------------------------------------------------
Running com.anonym.simulator.robot.SimulatorAssembleTest
Tests run: 3, Failures: 0, Errors: 0, Skipped: 0, Time elapsed: 0.054 sec
Running com.anonym.simulator.robot.MatrixTest
Tests run: 1, Failures: 0, Errors: 0, Skipped: 0, Time elapsed: 0.357 sec
Running com.anonym.simulator.robot.RobotTest
Tests run: 3, Failures: 0, Errors: 0, Skipped: 0, Time elapsed: 0.001 sec
Running com.anonym.simulator.robot.LocationTest
Tests run: 4, Failures: 0, Errors: 0, Skipped: 0, Time elapsed: 0 sec
Running com.anonym.simulator.robot.FacingDirectionTest
Tests run: 1, Failures: 0, Errors: 0, Skipped: 0, Time elapsed: 0 sec

Results :

Tests run: 12, Failures: 0, Errors: 0, Skipped: 0

[INFO] ------------------------------------------------------------------------
[INFO] BUILD SUCCESS
[INFO] ------------------------------------------------------------------------
[INFO] Total time: 1.433 s
[INFO] Finished at: 2018-02-11T14:34:44+10:00
[INFO] Final Memory: 9M/491M
[INFO] ------------------------------------------------------------------------


To Deliver & Run on Production:

- Packaging: `mvn package`, compiled jar in *target/* folder
- Release robot-0.0.1-SNAPSHOT.jar to Prodction
- Run: java -cp  <Production_Envir_Path>/robot-0.0.1-SNAPSHOT.jar  com.anonym.simulator.robot.RobotApp

To Exit App:

>EXIT


Application Operating Instructions
-----------

- Run the app (refer to Application Installation Instructions & Configuration Section Above)

*************************************
*                                   *
*      The Toy Robot Simulator      *
*                                   *
*************************************

Tell the Robot your first command
Start with placing the Robot on the palytable - PLACE X, Y, FACING or 
You can read existing file with Command as 'READ simulator-commands.txt'.
The Robot can read in commands of the following form (case insensitive): 
'PLACE X,Y,NORTH|SOUTH|EAST|WEST', MOVE, LEFT, RIGHT, REPORT , or READ <fileName.txt> 
'EXIT' to exit.

>

There are two options to run this simulator   
- Type in commands in command prompt.   
- Provide a file with commands.   

To operate the robot by typing commands, start the app from the command prompt with no arguments provided and begin type in commands:
`````
>place 1,1,north
>move  
>report
[Simulator App Info]>>> 1,2,NORTH
>

```

To operate the robot using a file, create a file with commands, e.g. `simulator-commands.txt`, with the following contents:

```
PLACE 0,0,NORTH
MOVE
MOVE
REPORT
MOVE
LEFT
MOVE
RIGTH
MOVE
MOVE
REPORT
```

Then run the application providing it the file as the first argument:

```
>read simulator-commands.txt
------------------Start to read file-----------
>PLACE 0,0,NORTH
>MOVE
>REPORT
[Simulator App Info]>>> 0,1,NORTH
>MOVE
>LEFT
>MOVE
>RIGTH
[Simulator App Info]>>> Invalid command RIGTH
>MOVE
>MOVE
>REPORT
[Simulator App Info]>>> 0,2,WEST
>

```


